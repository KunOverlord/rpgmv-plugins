//=============================================================================
// KunAnimationPack.js
//=============================================================================
/*:
 * @filename KunAnimationPack.js
 * @plugindesc Extra animation packs for Kun Interactive Picture Animations. Includes former version (manual) format conversions.
 * @version 3.40
 * @author KUN
 * @target MC | MZ
 * 
 * @help
 * 
 * Use with KunAnimations Plugin to avoid overloading the plugin parameters
 * 
 * @param name
 * @type text
 * @text Pack Name
 * @desc define a tag or a name for this animation pack
 * 
 * @param scenes
 * @type struct<SceneV3>[]
 * @text Scenes
 * @desc Define the DataBase of Animation Scene Controllers (keep it clean and easy!!)
 * 
 * @param scenesv2
 * @type struct<SceneV2>[]
 * @text Scenes V2 (dirty)
 * @desc Won't be loaded by kunAnimations. Use this to parse and move the former scene format 
 * 
 * @param controllers
 * @type struct<SceneV2>[]
 * @text Scenes V1 (dirty)
 * @desc Won't be loaded by kunAnimations. Use this to parse and move the former scene format
 */

/*~struct~SceneV3:
 *
 * @param pictures
 * @type struct<Spritesheet>[]
 * @text SpriteSheets
 * @desc define here all pictures running this scene
 * 
 * @param cols
 * @parent pictures
 * @text Columns
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param rows
 * @parent pictures
 * @text Rows
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param fps
 * @parent pictures
 * @text Frames Per Second
 * @desc Default FPS for this frameset (leave to 0 to get master FPS as default)
 * @type number
 * @min 0
 * @default 0
 * 
 * @param framesets
 * @type struct<Animation>[]
 * @text Animations
 * @desc Animation Frameset Collection
 * @default []
 * 
 * @param hotspots
 * @type struct<Spot>[]
 * @text HotSpots
 * @desc Add the interactive spots here
 */

/*~struct~SceneV2:
 * @param pictures
 * @type struct<Spritesheet>[]
 * @text SpriteSheets
 * @desc define here all pictures running this scene
 * 
 * @param source
 * @parent pictures
 * @text Source Picture Pack
 * @desc DEPRECATED. Define in the SpriteSheet list
 * @type file[]
 * @require 1
 * @dir img/pictures/
 * 
 * @param cols
 * @text Columns
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param rows
 * @text Rows
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param fps
 * @text Frames Per Second
 * @desc Default FPS for this frameset (leave to 0 to get master FPS as default)
 * @type number
 * @min 0
 * @default 0
 * 
 * @param package
 * @text Animation Package
 * @desc DEPRECATED. Use SpriteSheet groups instead
 * @type text
 * 
 * @param framesets
 * @type struct<Animation>[]
 * @text Animations
 * @desc Animation Frameset Collection
 * @default []
 * 
 * @param hotspots
 * @type struct<Spot>[]
 * @text HotSpots
 * @desc Add the interactive spots here
 * 
 * @param soundProfile
 * @type text[]
 * @text Sound Set
 * @desc OBSOLETE: Use SpriteSheet instead
 * 
 * @param soundBankPrefix
 * @parent soundProfile
 * @type text[]
 * @text Sound Set (deprecated)
 * @desc OBSOLETE: Use SpriteSheet instead
 * 
 * @param soundLoop
 * @parent soundProfile
 * @text Sound Loop
 * @desc OBSOLETE: Use SpriteSheet instead
 * @type number
 * @min 0
 * @max 10
 * @default 4
 */

/*~struct~Spritesheet:
 * @param picture
 * @text Picture
 * @desc Select a base picture to create a scene. Match the spritesheet columns and rows with the scene.
 * @type file
 * @require 1
 * @dir img/pictures/
 * 
 * @param group
 * @text Animation Group
 * @type text
 * @desc Use Animation Groups to setup  Animation Stages
 * 
 * @param sound
 * @type text
 * @text Sound Profile
 * @desc Define a sound collection to play the animation sounds with
 * 
 * @param loop
 * @parent sound
 * @text Sound Loops
 * @desc Define how many loops are required to play a sound in the current scene
 * @type number
 * @min 0
 * @default 4
 */

/*~struct~Animation:
 * @param name
 * @text Name
 * @type text
 * @default animation
 * 
 * @param frames
 * @text Frames
 * @type number[]
 * @min 0
 * @desc List of frames to play in this animation
 * @default []
 * 
 * @param type
 * @text Animation Type
 * @type select
 * @option Forward (default)
 * @value forward
 * @option Reverse
 * @value reverse
 * @option Ping-Pong
 * @value ping-pong
 * @option Static
 * @value static
 * @default forward
 * 
 * @param fps
 * @text Frames Per Second
 * @desc Default FPS for this frameset (leave to 0 to get master FPS as default)
 * @type number
 * @min 0
 * @default 0
 * 
 * @param loops
 * @type number
 * @text Loops
 * @desc number of times the animation will play before switching to the next animation. Leave it to 0 for endless loops (no next animation)
 * @default 0
 * 
 * @param next
 * @text Next FrameSets
 * @type text[]
 * @desc Define the next frameset to call. If more than one specified, they will be randomly called
 * 
 * @param tags
 * @type text[]
 * @text Tags
 * @desc Tag animations to match filtering with interactive targets
 * 
 * @param offsetX
 * @text X Offset
 * @type number
 * @default 0
 * 
 * @param offsetY
 * @text Y Offset
 * @type number
 * @default 0
 * 
 * @param spots
 * @type struct<Touch>[]
 * @text Spots
 * @desc Interactive Spots to fire events
 * @default []
 * 
 * @param conditions
 * @type struct<Condition>[]
 * @text Conditions
 * @desc Enable this Animation when meeting these conditions
 * 
 * @param sounds
 * @text Sound Sets
 * @desc Type in a defined sound bank name to play a special sound set each time this frameset is started.
 * @type text[]
 * @default []
 */

/*~struct~Touch:
 * @param name
 * @text Name
 * @type text
 * @default touch
 * 
 * @param next
 * @text Next Animation
 * @desc Jump to Frameset on touched (allow mrandom options when more than 1)
 * @type text[]
 * @default []
 */

/*~struct~Spot:
 * @param name
 * @text Name
 * @type text
 * @default touch
 * 
 * @param x1
 * @text X1
 * @type number
 * @min 0
 * @desc X origin coordinate
 * 
 * @param y1
 * @text Y1
 * @type number
 * @min 0
 * @desc Y origin coordinate
 * 
 * @param x2
 * @text X2
 * @type number
 * @min 0
 * @desc X destination coordinate
 * 
 * @param y2
 * @text Y2
 * @type number
 * @min 0
 * @desc Y destination coordinate
 * 
 * @param tags
 * @text Tags
 * @type text[]
 * @desc Define tags to filter related animations
 * 
 * @param trigger
 * @text On Click
 * @type select
 * @option Instant Run
 * @value instant
 * @option Queue
 * @value queue
 * @option Set Frame
 * @value frame
 * @option Next Frame
 * @value next
 * @option Ignore
 * @value ignore
 * @default queue
 * 
 * @param sfx
 * @text Touch Audio SFX
 * @desc Define a specific sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param conditions
 * @type struct<Condition>[]
 * @text Conditions
 * @desc Enable this HotSpot when meeting these conditions
 * 
 * @param varId
 * @text Game Variable ID
 * @type variable
 * @min 0
 * @desc (Obsolete) Game Variable Mutator. Leave to 0 to not update variables. Use Actions instead.
 * @default 0
 * 
 * @param behavior
 * @parent varId
 * @text Update Behavior
 * @desc (Obsolete) How to modify the value on Game Variable ID. Use Actions instead
 * @type select
 * @option Add (default)
 * @value add
 * @option Substract
 * @value sub
 * @option Set
 * @value set
 * @default add
 * 
 * @param amount
 * @parent varId
 * @text Update Amount
 * @desc (Obsolete) Use Actions instead
 * @type number
 * @min 1
 * @default 1
 */

/*~struct~Action:
 * @param tag
 * @text Tag
 * @type text
 * @desc Set a tag for this action used for a filtered action selection
 * 
 * @param var
 * @type variable
 * @text Game Variable
 * @desc define a game variable to update with this action
 * @min 0
 * @default 0
 * 
 * @param op
 * @text Operator
 * @desc Operation type to run on the Game Variable
 * @type select
 * @option Add
 * @value add
 * @option Sub
 * @value sub
 * @option Set
 * @value set
 * @default set
 * 
 * @param val
 * @text Value
 * @desc Value to update the game variable with
 * @type number
 * @min 0
 */

/*~struct~Condition:
 * @param var
 * @type variable
 * @text Game Variable
 * @desc define a game variable to check for this condition
 * @min 0
 * @default 0
 * 
 * @param op
 * @text Operator
 * @desc Select the type of operation to cast over the value for this Game Variable
 * @type select
 * @option Greater
 * @value greater
 * @option Greater or equal
 * @value greater_equal
 * @option Equal
 * @value equal
 * @option Less or equal
 * @value less_equal
 * @option Less
 * @value less
 * @default equal
 * 
 * @param val
 * @type number
 * @text Value
 * @desc Operate with this value
 * @min 0
 * @default 0
 * 
 * @param target
 * @type boolean
 * @text Value as Variable
 * @desc Map value as a Game Variable which provides the real value. Value must be a valid Game Variable.
 * @default false
 * 
 * @param on
 * @type switch[]
 * @text Game Switch ON
 * @desc define which game switches must be ON for this condition
 *
 * @param off
 * @type switch[]
 * @text Game Switch OFF
 * @desc define which game switches must be OFF for this condition
 */
