//=============================================================================
// KunCommands.js
//=============================================================================
/*:
 * @filename KunCommands.js
 * @plugindesc Kun Command Utils
 * @version 1.55
 * @author KUN
 * 
 *
 * @help
 * 
 * KunCommands mapevent [eventVar] [mapVar]
 *      Exports the event map Id and event Id into the mapVar and eventVar game variables
 *      Use it from map events to capture their current map and event Id
 * 
 * KunCommands targetbattler [actorVar] [enemyVar]
 *      Exports the selected target in battle wether is party member or enemy from the troop.
 *      Use actorVar and enemyVar to export both involved battlers into their gameVariables
 * 
 * KunCommands partymenu [exportVar] [random|last|skip|disable|first] [left|middle|right] [window|dim|transparent|none]
 *      Displays a party selection menu to export the selected actor into exportVar
 *      Select a cancelType option from random|last|skip|disable|first
 *      Select a layout position from left|middle|right
 *      Select a window display type from window|dim|transparent
 * 
 * KunCommands partymember [exportVar] [random|member_id]
 *      Select a party member into exportVar
 *      Define which party member by member_id, or pick a random party member
 * 
 * KunCommands learn|learn_skill [actor_id] [skill1:skill2:skill3:...] [exportVar] [import] [random]
 *      Unlock a new skill for actor_id from the skill id list, from the first, to the last
 *      Use exportVar to export the skill ID added
 *      Use import tag to import actor_id from a gameVariable
 *      Use random tag to learn a random spell from the list provided
 * 
 * KunCommands loot [item1:item2:item3:...] [amount:amount:...]
 * KunCommands items [item1:item2:item3:...] [amount:amount:...]
 * KunCommands weapons [item1:item2:item3:...] [amount:amount:...]
 * KunCommands armors [item1:item2:item3:...] [amount:amount:...]
 *      Generate a loot of items, weapons or armors, given an amount to generate
 * 
 * KunCommands add_item [item1:item2:item3:...] [amount:amount:...] [exportVar] [import]
 *      Adds an item from the item_id list
 *      Randoms the amount among two values, or selecting one of the amounts if more than two
 *      Use exportVar to get the gained item id
 *      Use import tag to import the amount from a gameVariable (rather using it only with one amount value)
 * 
 * KunCommands varadd [exportVar] [value1:value2:value3...] [limit] [import]
 *      Updates exportVar increasing the value with oneof the given amounts
 *      Defines a limit to stop increasing
 *      Define the limit from a valid gameVariable using import
 * 
 * KunCommands varsub [exportVar] [value1:value2:value3...] [minimum] [import]
 *      Updates exportVar reducing the value with oneof the given amounts
 *      Defines a minimum to stop reducing
 *      Define the minimum from a valid gameVariable using import
 * 
 * KunCommands oneof [exportVar] [value1:value2:value3...]
 *      Exports into exportVar one ofthe values providen
 * 
 * KunCommands rate [exportVar] [value/range] [import]
 *      Exports into exportVar the percentage of value/range
 *      Imports value and range from gameVariables
 * 
 * KunCommands varmenu [gameVar] [option:option:option:...] [random|last|skip|disable|first] [left|middle|right] [window|dim|transparent|none]
 *      ℹ Displays a Value Menu to set into gameVar from the options provided separated by semicolon (:)
 *      ℹ USE UNDERSCORE BAR (_) TO SET SPACES!
 *      ℹ Add [VALUE] at the beginning of EVERY option, so the menu selection will set gameVar to VALUE.
 *      ℹ If no [VALUE] is present within an option, it will set gameVar to the corresponding index of the selected option in the option list.
 *      Select a cancelType option from random|last|skip|disable|first
 *      Select a layout position from left|middle|right
 *      Select a window display type from window|dim|transparent
 * 
 * KunCommands jumpto [alias1:alias2:label3:...] [drop]
 *      Jumps to the first label found, sorted by priority, looking into the aliases first
 *      Use it with a default fallback label at the end
 *      Drops the label alias if found
 * 
 * KunCommands jumptovar [gameVar] [value]label:[value]label:[value]label:... [random]
 *      Parses the [value]label list into a set of LABELS associated to VALUES
 *      When the gameVar value is one of the VALUES in the list, it will jump into the associated LABEL
 *      If random is defined and the list provides more than one label, it will return a random label
 * 
 * KunCommands droplabel [alias]
 *      Remove a label alias
 * 
 * KunCommands alias [alias] [label:label:label:...]
 * KunCommands label [alias] [label:label:label:...]
 * KunCommands labelalias [alias] [label:label:label:...]
 * KunCommands savelabel [alias] [label:label:label:...]
 *      Set a label alias
 *      Pick a randomly selected label from the list if more than one label is provided
 * 
 * KunCommands sublabel [label|alias] [prefix1:prefix2:prefix3:...]
 *      Jump to a sublabel variant named with [prefix][label]
 *      Add more prefixes with colon : to random sublabel variants
 *      Avoid previx to use the prefix fallback defined in the parameters
 *      If no sublabel found, will attempt to jump to the original label
 * 
 * KunCommands chainlabel [alias] [label1:label2:label3]
 *      Sets the label alias to the defined label list one after the other
 * 
 * KunCommands haslabel [label] [switch_id]
 *      Set the switch_id value if the label alias is set or not
 * 
 * KunCommands varlabel [alias] [label1:label2:label3:...] [exportVar]
 *      Search a label alias in the label list and exports position into exportVar
 *      If none of the labels in the list is found, exportVar is set to zero
 *      Good to assign a label-alias into a variable by it's index, or to findout the value of a label alias
 * 
 * KunCommands labelmenu [option:option:option:...] [random|last|skip|disable|first] [left|middle|right] [window|dim|transparent|none]
 *      ℹ Displays a label menu from the options provided separated by semicolon (:)
 *      ℹ USE UNDERSCORE BAR (_) TO SET SPACES!
 *      ℹ Add [LABEL_NAME] at the beginning of EVERY option, so the menu selection will JUMP TO LABEL_NAME
 *      Allows to jump both to LABELS and label ALIASES
 *      Select a cancelType option from random|last|skip|disable|first
 *      Select a layout position from left|middle|right
 *      Select a window display type from window|dim|transparent
 * 
 * 
 * @param debug
 * @text Debug
 * @type boolean
 * @default false
 * 
 * @param labelFallback
 * @text SubLabel Falback Char
 * @define a fallback character for fallback a sub-label command
 * @type text
 * @default _
 * 
 * @param switchOn
 * @text Switch On Icon
 * @type number
 * @min 0
 * @default 0
 * 
 * @param switchOff
 * @text Switch Off Icon
 * @type number
 * @min 0
 * @default 0
 * 
 * @param parseNickName
 * @text Parse NickName
 * @desc Enable Parse NickName on Escape Chars. Let disabled if causes conflict with other plugins.
 * @type boolean
 * @default false
 * 
 * @param commands
 * @type text[]
 * @text Plugin Commands
 * @desc Use Older plugins to hack in these commands
 * 
 */

function KunCommands() {
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 */
KunCommands.Initialize = function () {

    //var parameters = PluginManager.parameters('KunCommands');
    var parameters = this.PluginData();

    this._debug = parameters.debug;
    this._parseNickName = parameters.parseNickName;
    this._labelFallback = parameters.labelFallback || '_';

    this._icons = {
        'on':parameters.switchOn,
        'off':parameters.switchOff,
    };

    this._commands = parameters.commands || [];

    this._labelAlias = {};
};
/**
 * 
 */
KunCommands.PluginData = function () {
    function _parsePluginData ( key , value ) {
        if (typeof value === 'string' && value.length ) {
            try {
                if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                    return JSON.parse(value, _parsePluginData );
                }
            } catch (e) {
                // If parsing fails or it's not an object/array, return the original value
            }
            if( value === 'true' || value === 'false'){
                return value === 'true';
            }
            if( !isNaN(value) ){
                return parseInt(value);
            }
        }
        return value;
    };

    var _data = PluginManager.parameters('KunCommands');
    var _output = {};
    Object.keys( _data ).forEach( function(key ){
        _output[key] = _parsePluginData(key , _data[key]);
    });
    return _output;
};
/**
 * @returns {String[]}
 */
KunCommands.commands = function(){
    return [ 'KunCommand' , 'KunCommands', ...this._commands ];
};
/**
 * @param {String} icon 
 * @returns {Number}
 */
KunCommands.icon = function( icon ){
    return this._icons.hasOwnProperty(icon) ? this._icons[icon] : 0;
};
/**
 * @param {Boolean} value 
 * @returns {Number}
 */
KunCommands.switchIcon = function( value = false ){
    return this.icon( value ? 'on' : 'off');
};
/**
 * @returns {String}
 */
KunCommands.labelFallback = function () {
    return this._labelFallback;
};
/**
 * @returns {Boolean}
 */
KunCommands.debug = function () {
    return this._debug;
};
/**
 * @returns {Boolean}
 */
KunCommands.parseNickName = function () {
    return this._parseNickName;
};
/**
 * @param {String|Object} message 
 */
KunCommands.DebugLog = function (message) {
    if (this.debug()) {
        console.log('[ KunCommands ]', message);
    }
};
/**
 * @param {Number} actor_id 
 * @param {Number[]} skills 
 * @param {Number} exportVar
 * @param {Boolean} random
 * @returns {Number}
 */
KunCommands.learnSkill = function (actor_id, skills, exportVar = 0, random = false) {
    if (actor_id && Array.isArray(skills)) {
        var actor = $gameActors.actor(actor_id);
        var list = skills.filter( skill_id => !actor.isLearnedSkill(skill_id));
        if( list.length ){
            var skill_id = random ? list[Math.floor(Math.random() * list.length )] : list[0];
            actor.learnSkill(skill_id);
            if (exportVar) {
                $gameVariables.setValue(exportVar, skill_id);
            }
            return skill_id;
        }
    }

    return 0;
};
/**
 * 
 * @param {Number[]} values 
 * @returns Number
 */
KunCommands.SelectValue = function (values) {
    if (Array.isArray(values)) {
        switch (true) {
            case values.length > 2:
                return values[Math.floor(Math.random() * values.length)];
            case values.length > 1:
                return Math.floor(Math.random() * (values[1] - values[0])) + values[0];
            case values.length:
                return values[0];
        }
    }
    return 0;
};
/**
 * @param {Game_Event} gameEvent 
 * @returns Number
 */
KunCommands.ImportEventPageVar = function (gameEvent, defaultVal) {
    if (gameEvent instanceof Game_Event) {
        if (gameEvent.page().conditions.variableValid) {
            return gameEvent.page().conditions.variableValue;
        }
    };
    return typeof defaultVal === 'number' && defaultVal ? defaultVal : 0;
};
/**
 * @param {Game_Event} gameEvent 
 * @param {Number} eventVar
 * @param {Number} mapVar
 * @returns Boolean
 */
KunCommands.ImportMapEventVars = function (gameEvent, eventVar, mapVar) {
    if (gameEvent instanceof Game_Event) {
        if (eventVar) {
            $gameVariables.setValue(eventVar, gameEvent.eventId());
        }
        if (mapVar && gameEvent.hasOwnProperty('_mapId')) {
            $gameVariables.setValue(mapVar, gameEvent._mapId);
        }
        return true;
    };
    $gameVariables.setValue(mapVar, 0);
    $gameVariables.setValue(eventVar, 0);
    return false;
};
/**
 * 
 * @param {Number[]} items 
 * @param {Number} amount 
 * @returns Number
 */
KunCommands.AddItemFrom = function (items, amount) {
    if (Array.isArray(items) && amount > 0) {
        var selected = items[Math.floor(Math.random() * items.length)];
        if (selected > 0 && selected < $dataItems.length) {
            var item = $dataItems[selected];
            if (item !== null) {
                $gameParty.gainItem(item, amount);
                return item.id;
            }
        }
    }
    return 0;
};
/**
 * @param {Numbes[]} items 
 * @param {Number} amount 
 * @param {String} type 
 * @returns {KunCommands}
 */
KunCommands.loot = function( items , amount = 1, type = 'item'){
    var drops = [];
    if( Array.isArray(items) && items.length > 1){
        for( var i = 0 ; i < amount ; i++ ){
            drops.push( items[Math.floor(Math.random() * items.length)]);
        }
    }
    drops.forEach( function(item){
        switch(type){
            case 'items':
            case 'item':
                KunCommands.addItem(item);
                break;
            case 'weapons':
            case 'weapon':
                KunCommands.addWeapon(item);
                break;
            case 'armors':
            case 'armor':
                KunCommands.addArmor(item);
                break;
        }
    });
    return this;
};
/**
 * @param {Number} item_id 
 * @param {Number} amount 
 */
KunCommands.addItem = function( item_id , amount = 1){
    if( item_id && item_id < $dataItems.length ){
        $gameParty.gainItem( $dataItems[item_id] , amount );
    }
};
/**
 * @param {Number} armor_id 
 * @param {Number} amount 
 */
KunCommands.addArmor = function( armor_id , amount = 1){
    if( armor_id && armor_id < $dataArmors.length ){
        $gameParty.gainItem( $dataArmors[armor_id] , amount );
    }
};
/**
 * @param {Number} weapon_id 
 * @param {Number} amount 
 */
KunCommands.addWeapon = function( weapon_id , amount = 1){
    if( weapon_id && weapon_id < $dataWeapons.length ){
        $gameParty.gainItem( $dataWeapons[weapon_id] , amount );
    }
};
/**
 * 
 * @param {String} type 
 * @param {Number} amount 
 * @returns {Number}
 */
KunCommands.MenuCancelType = function (type, amount) {
    switch (type) {
        case 'random':
            return Math.floor(Math.random() * amount);
        case 'last':
            return amount - 1;
        case 'skip':
            return -2;
        case 'disable':
            return -1;
        case 'first':
        default:
            return 0;
    }
};

/**
 * 
 * @param {Number} actorVar 
 * @param {Number} enemyVar 
 * @returns Number
 */
KunCommands.ExportBattleTarget = function (actorVar, enemyVar) {

    if ($gameParty.inBattle()) {

        var targetEnemy = BattleManager._action._subjectActorId > 0;

        var caster_id = targetEnemy ?
            //caster is party character, CAREFUL!!! this is the actual ACTOR ID, not the party member in  the troop!!!
            BattleManager._action._subjectActorId :
            //caster is troop enemy (-1 if not used)
            BattleManager._action._subjectEnemyIndex;

        var target_id = targetEnemy ?
            //target is troop enemy
            BattleManager._action._targetIndex :
            //target is party member
            $gameParty.members().length > 1 ? parseInt(Math.random() * $gameParty.members().length) : 0;

        var actor_id = targetEnemy ? caster_id : $gameParty.members()[target_id]._actorId;
        var enemy_id = $gameTroop.members()[targetEnemy ? target_id : caster_id]._enemyId;

        if (typeof actorVar === 'number' && actorVar) {
            $gameVariables.setValue(actorVar, actor_id);
        }
        if (typeof enemyVar === 'number' && enemyVar) {
            $gameVariables.setValue(enemyVar, enemy_id);
        }

        return targetEnemy ? enemy_id : actor_id;
    }
    return 0;
};
/**
 * @param {String} alias 
 * @param {String} label 
 */
KunCommands.labelAlias = function (alias, label = '') {
    if (typeof alias === 'string' && alias.length) {
        if (typeof label === 'string' && label.length) {
            this.labels()[alias] = label;
            KunCommands.DebugLog(`LABEL ALIAS ${alias} = ${label}`);
        }
        else {
            if (this.hasLabel(alias)) {
                delete this.labels()[alias];
                KunCommands.DebugLog(`LABEL ALIAS ${alias} REMOVED`);
            }
        }
    }
};
/**
 * @returns KunCommands
 */
KunCommands.clearLabels = function () {
    this._labelAlias = {};
    return this;
};
/**
 * @param {String} alias
 * @param {Boolean} drop
 * @returns String
 */
KunCommands.label = function (alias, drop = false) {
    if (this.hasLabel(alias)) {
        var label = this.labels()[alias];
        if (drop) {
            this.labelAlias(alias);
        }
        return label;
    }
    return alias;
    //return this.hasLabel(label) ? this.labels()[label] : label;
};
/**
 * @param {String} alias 
 * @returns Boolean
 */
KunCommands.hasLabel = function (alias) {
    return this.labels().hasOwnProperty(alias);
};
/**
 * @param {Boolean} list 
 * @returns String[] | Object
 */
KunCommands.labels = function (list) {
    return typeof list === 'boolean' && list ? Object.keys(this._labelAlias) : this._labelAlias;
};


/**
 * 
 */
function KunCommands_Setup_Interpreter() {
    /**
     * @param {Number} gameVar Game Variable to export the actor's ID
     * @param {Number} cancelType [random|first|last|skip|disable]
     * @param {Number} positionType [left|middle|right]
     * @param {Number} background [window|dim|none]
     */
    Game_Interpreter.prototype.setupPartySelector = function (gameVar, cancelType, positionType, backgroundType) {
        if ($gameParty.size()) {
            var positions = ['left', 'middle', 'right'];
            var backgrounds = ['window', 'dim', 'transparent'];

            var _names = $gameParty.members().map(actor => actor.name());
            var _ids = $gameParty.members().map(actor => actor.actorId());

            var position = typeof positionType === 'string' && positions.includes(positionType) ? positions.indexOf(positionType) : 2;
            var background = typeof backgroundType === 'string' && backgrounds.includes(backgroundType) ? backgrounds.indexOf(backgroundType) : 2;
            var cancel = KunCommands.MenuCancelType(typeof cancelType === 'string' ? cancelType : 'first', _ids.length);

            $gameMessage.setChoices(_names, 0, cancel);
            $gameMessage.setChoiceBackground(background);
            $gameMessage.setChoicePositionType(position);
            $gameMessage.setChoiceCallback(function (n) {
                if (_ids.length > n) {
                    $gameVariables.setValue(gameVar, _ids[n]);
                }
            }.bind(this));
        }
    };

    /**
     * @param {String[]} options Defined Label Menu to load options from
     * @param {Number} cancelType [random|first|last|skip|disable]
     * @param {Number} positionType [left|middle|right]
     * @param {Number} background [window|dim|none]
     * @param {Number} gameVar Define a game variable to setup the menu as a VALUE SELECTOR. Leave zero to use LABEL SELECTOR
     */
    Game_Interpreter.prototype.setupCustomMenuSelector = function ( options, cancelType, positionType, backgroundType , gameVar = 0 ) {
        if ( Array.isArray(options) && options.length) {
            var positions = ['left', 'middle', 'right'];
            var backgrounds = ['window', 'dim', 'transparent'];
                //setupCustomMenuSelector
                const regex = gameVar ? /^\[(\d+)\]/ : /^\[([a-zA-Z0-9]+)\]/;
                var position = typeof positionType === 'string' && positions.includes(positionType) ? positions.indexOf(positionType) : 2;
                var background = typeof backgroundType === 'string' && backgrounds.includes(backgroundType) ? backgrounds.indexOf(backgroundType) : 2;
                var cancel = KunCommands.MenuCancelType(
                    typeof cancelType === 'string' ? cancelType : 'first',
                    options.length);
    
                $gameMessage.setChoices(options.map( option => option.replace(regex,'').trim()), 0, cancel);
                $gameMessage.setChoiceBackground(background);
                $gameMessage.setChoicePositionType(position);
                if( gameVar ){
                    //capture as Var Menu then SET VALUE TO VAR
                    $gameMessage.setChoiceCallback(function (n) {
                        var content = options[n].match(regex);
                        var value = content !== null && content.length > 1 ? parseInt(content[1]) : n + 1;
                        $gameVariables.setValue( gameVar , value );
                    }.bind(this)); 
                }
                else{
                     //capture as LABEL MENU then JUMP TO LABEL
                     $gameMessage.setChoiceCallback(function (n) {
                        var content = options[n].match(regex);
                        if( content !== null && content.length > 1 ){
                            this.jumpToLabel( KunCommands.label( content[1] ) );
                        }
                    }.bind(this));    
                }
        }
    };

    //Plugin Command Jump to Label
    Game_Interpreter.prototype.jumpToLabel = function (labelName) {
        if (typeof labelName === 'string' && labelName.length > 0) {
            for (var i = 0; i < this._list.length; i++) {
                var command = this._list[i];
                if (command.code === 118 && command.parameters[0] === labelName) {
                    this.jumpTo(i);
                    KunCommands.DebugLog(`Jumping to Label ${labelName}...`);
                    return true;
                }
            }
        }
        return false;
    };
}
/**
 * 
 */
function KunCommands_Setup_EscapeChars() {
    //Window_Base.prototype.JayaKSetup_escapeCharacters = Window_Base.prototype.convertEscapeCharacters;
    var _KunCommands_Escape_Characters = Window_Base.prototype.convertEscapeCharacters;
    Window_Base.prototype.convertEscapeCharacters = function (text) {

        var parsed = _KunCommands_Escape_Characters.call(this, text);

        //bind saved label
        parsed = parsed.replace(/\x1bLABEL\[([a-zA-Z0-9]+)\]/gi, function () {
            return KunCommands.label( arguments[1]);
        }.bind(this));

        return parsed;
    };
}


/**
 * 
 */
function KunCommands_Setup_Command() {
    var _KunCommands_PluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunCommands_PluginCommand.call(this, command, args);
        if (command === 'KunCommands') {
            if (args && args.length) {
                switch (args[0]) {
                    case 'mapevent':
                        if (args.length > 1) {
                            KunCommands.ImportMapEventVars(this.character(),
                                parseInt(args[1]),
                                args.length > 2 ? parseInt(args[2]) : 0);
                        }
                        break;
                    case 'targetbattler':
                        if (args.length > 2) {
                            KunCommands.ExportBattleTarget(parseInt(args[1]), parseInt(args[2]));
                        }
                        break;
                    case 'partymenu':
                        if (args.length > 1 && $gameParty.size() > 0) {
                            this.setupPartySelector(parseInt(args[1]),
                                args.length > 2 ? args[2] : 'first',
                                args.length > 3 ? args[3] : 'right',
                                args.length > 4 ? args[4] : 'window',
                            );
                            //set this to wait for a response
                            //this._index++;
                            this.setWaitMode('message');
                        }
                        break;
                    case 'partymember':
                        if (args.length > 2 && $gameParty.size() > 0) {
                            var exportVar = parseInt(args[1]);
                            var partyMember = args[2] === 'random' ? Math.floor(Math.random() * $gameParty.size()) : parseInt(args[2]);
                            $gameVariables.setValue(exportVar, $gameParty.members()[partyMember].actorId());
                        }
                        break;
                    case 'learn':
                    case 'learn_skill':
                        if (args.length > 2) {
                            var actor_id = parseInt(args[1]);
                            var actor = $gameActors.actor(args.includes('import') && actor_id ? $gameVariables.value(actor_id) : actor_id);
                            var exportVar = args.length > 3 ? parseInt(args[3]) : 0;
                            var skill_id = 0;
                            if( actor ){
                                var skills = args[2].split(':')
                                    .filter(id => !isNaN(id) && !actor.isLearnedSkill(parseInt(id)))
                                    .map(id => parseInt(id));
                                if( skills.length ){
                                    var skill_id = args.includes('random') ? skills[Math.floor(Math.random() * skills.length )] : skills[0];
                                    actor.learnSkill(skill_id);
                                }
                            }
                            if (exportVar) {
                                $gameVariables.setValue(exportVar, skill_id);
                            }                                    
                        }
                        break;
                    case 'sell':
                        if( args.length > 1 ){
                            var items = args[1].split(':').map( id => parseInt(id)).filter(id => id > 0);
                            var gameVar = args.length > 2 && args[2] > 0 ? parseInt(args[2]) : 0;
                            var value = 0;
                            items.map(id => $dataItems[id] ).forEach(function(item){
                                var amount = $gameParty.numItems(item);
                                if( amount ){
                                    console.log(`Item ${item.name}: ${amount}`);
                                    value += item.price * amount;
                                    $gameParty.gainItem(item, -amount);
                                }
                            });
                            if(gameVar){
                                $gameVariables.setValue(gameVar,value);
                            }
                            else{
                                $gameParty.gainGold(value);
                            }
                        }
                        break;
                    case 'gain':
                    case 'add_item':
                        if (args.length > 1) {
                            var list = args[1].split(':').filter(item => !isNaN(item)).map(item => parseInt(item));
                            var amount = args.length > 2 ? args[2].split(':').filter(value => !isNaN(value)).map(value => parseInt(value)) : [1];
                            if (args.length > 4 && args[4] === 'import' && amount.length === 1) {
                                amount = $gameVariables.value(amount[0]);
                            }
                            else {
                                amount = KunCommands.SelectValue(amount);
                            }
                            var item = KunCommands.AddItemFrom(list, amount || 1);
                            var exportVar = args.length > 3 ? parseInt(args[3]) : 0;
                            if (exportVar) {
                                $gameVariables.setValue(exportVar, item);
                            }
                        }
                        break;
                    case 'loot':
                    case 'weapons':
                    case 'armors':
                    case 'items':
                        if( args.length > 1 ){
                            var list = args[1].split(':').map(id => parseInt(id));
                            var drops = args.length > 2 ? args[2].split(':').map(value => parseInt(value)) : [1];
                            var amount = Math.floor(Math.random() * drops.length);
                            KunCommands.loot(list , amount , args[0] === 'loot' ? 'item' : args[0]);
                        }
                        break;
                    case 'varadd':
                        if (args.length > 2) {
                            var gameVar = parseInt(!Number.isNaN(args[1]) ? args[1] : 0);
                            var top = args.length > 3 ? parseInt(args[3]) : 0;
                            var value = args[2] === 'pagevar' ?
                                KunCommands.ImportEventPageVar(this.character(), top) :
                                KunCommands.SelectValue(args[2].split(':').filter(value => !isNaN(value)).map(value => parseInt(value)));
                            if (args.length > 4 && args[4] === 'import' && top > 0) {
                                top = $gameVariables.value(top);
                            }
                            if (gameVar > 0) {
                                value = $gameVariables.value(gameVar) + value;
                                $gameVariables.setValue(gameVar, value < top || top === 0 ? value : top);
                            }
                        }
                        break;
                    case 'varsub':
                        if (args.length > 2) {
                            var gameVar = parseInt(!Number.isNaN(args[1]) ? args[1] : 0);
                            var min = args.length > 3 ? parseInt(args[3]) : 0;
                            var value = args[2] === 'pagevar' ?
                                KunCommands.ImportEventPageVar(this.character(), min) :
                                KunCommands.SelectValue(args[2].split(':').filter(value => !isNaN(value)).map(value => parseInt(value)));
                            if (args.length > 4 && args[4] === 'import' && min > 0) {
                                min = $gameVariables.value(min);
                            }
                            if (gameVar > 0) {
                                value = $gameVariables.value(gameVar) - value;
                                $gameVariables.setValue(gameVar, value > min ? value : min);
                            }
                        }
                        break;
                    case 'oneof':
                        if (args.length > 2) {
                            var gameVar = parseInt(args[1]);
                            if (gameVar > 0) {
                                var list = args[2].split(':').filter(value => !isNaN(value)).map(value => parseInt(value));
                                var selection = Math.floor(Math.random() * list.length);
                                if (list.includes(list[selection])) {
                                    $gameVariables.setValue(gameVar, list[selection]);
                                }
                            }
                        }
                        break;
                    case 'rate':
                        if (args.length > 2) {
                            var exportVar = parseInt(args[1]);
                            var range = args[2].split('/').filter(value => !isNaN(value)).map(value => parseInt(value));
                            if (range.length > 1 && range[1] > 0) {
                                if (args.length > 3 && args[3] === 'import' && $gameVariables.value(range[0]) && $gameVariables.value(range[1])) {
                                    range[0] = $gameVariables.value(range[0]);
                                    range[1] = $gameVariables.value(range[1]);
                                }
                                $gameVariables.setValue(exportVar, range[0] / parseFloat(range[1]) * 100);
                            }
                            else {
                                $gameVariables.setValue(exportVar, 0);
                            }
                        }
                        break;
                    case 'progress':
                        if( args.length > 3 ){
                            var value = $gameVariables.value(parseInt(args[2]));
                            var range = $gameVariables.value(parseInt(args[3]));
                            $gameVariables.setValue(parseInt(args[1]), range > 0 ? parseInt(value / range * 100) : 0 );
                        }
                        break;
                    case 'varmenu':
                        if (args.length > 2 ) {
                            this.setupCustomMenuSelector(
                                args[2].split(':').map( option => option.replace(/_/g ,' ' ) ), //menu options
                                args.length > 3 ? args[3] : 'first',
                                args.length > 4 ? args[4] : 'right',
                                args.length > 5 ? args[5] : 'window',
                                parseInt(args[1]) //capture menu option into var
                            );
                            //set this to wait for a response
                            this.setWaitMode('message');
                        }
                        break;
                    case 'labelmenu':
                        if (args.length > 1 ) {
                            this.setupCustomMenuSelector(
                                args[1].split(':').map( option => option.replace(/_/g ,' ' ) ), //menu options
                                args.length > 2 ? args[2] : 'first',
                                args.length > 3 ? args[3] : 'right',
                                args.length > 4 ? args[4] : 'window',
                            );
                            //set this to wait for a response
                            this.setWaitMode('message');
                        }
                        break;
                    case 'alias':
                    case 'label':
                    case 'labelalias':
                    case 'savelabel':
                        if (args.length > 2) {
                            var labels = args[2].split(':');
                            if( labels.length > 1 ){
                                KunCommands.labelAlias(args[1], labels[Math.floor(Math.random() * labels.length )]);
                            }
                            else{
                                KunCommands.labelAlias(args[1], labels[0]);
                            }
                        }
                        else if (args.length > 1) {
                            //clear aliases
                            args[1].split(':').forEach(alias => KunCommands.labelAlias(alias));
                        }
                        break;
                    case 'chainlabel':
                        if (args.length > 2) {
                            var chain = args[2].split(':');
                            if (KunCommands.hasLabel(args[1])) {
                                var current = chain.indexOf(KunCommands.label(args[1]));
                                if (current >= 0) {
                                    if (current < chain.length - 1) {
                                        //cycle to next label in the chain
                                        KunCommands.labelAlias(args[1], chain[current + 1]);
                                    }
                                    else {
                                        //cleanup label alias
                                        KunCommands.labelAlias(args[1]);
                                    }
                                }
                            }
                            else {
                                //reset to the first label
                                KunCommands.labelAlias(args[1], chain[0]);
                            }
                        }
                        break;
                    case 'droplabel':
                        if (args.length > 1) {
                            args[1].split(':').forEach(label => KunCommands.labelAlias(label));
                        }
                        else {
                            KunCommands.clearLabels();
                        }
                        break;
                    case 'varlabel':
                        if( args.length > 3){
                            var index = args[2].split(':').indexOf(KunCommands.label(args[1] ));
                            var exportVar = parseInt(args[3]);
                            $gameVariables.setValue(exportVar, index >= 0 ? index + 1 : 0);
                        }
                        break;
                    case 'haslabel':
                        if (args.length > 2) {
                            $gameSwitches.setValue(parseInt(args[2]), KunCommands.hasLabel(args[1]));
                        }
                        break;
                    case 'sublabel':
                        if (args.length > 1) {
                            var variants = args.length > 2 ? args[2].split(':') : [KunCommands.labelFallback()];
                            var prefix = variants.length > 1 ? variants[Math.floor(Math.random() * variants.length)] : variants[0];
                            if (!this.jumpToLabel(prefix + KunCommands.label(args[1]))) {
                                //jump to default label
                                this.jumpToLabel(KunCommands.label(args[1]));
                            }
                        }
                        break;
                    case 'jumpto':
                        if (args.length > 1) {
                            var remove = args.includes('drop');
                            var labels = args[1].split(':').map(label => KunCommands.label(label, remove));
                            var random = args.includes('random');
                            if (random) {
                                this.jumpToLabel(labels[Math.floor(Math.random() * labels.length)]);
                            }
                            else {
                                for (var i in labels) {
                                    if (this.jumpToLabel(labels[i])) {
                                        break;
                                    }
                                }
                            }
                        }
                        break;
                    case 'jumptovar':
                        if( args.length > 2 ){
                            var value = $gameVariables.value(parseInt(args[1]));
                            var regex = /^\[(\d+)\]/;
                            var labels = args[2].split(':').map(function(tag){
                                var content = tag.match(regex);
                                var label = tag.replace(regex,'').trim();
                                return {
                                    'value':content !== null && content.length > 1 ? parseInt(content[1]) : 0,
                                    'label': label,
                                };
                            }).filter( tag => tag.value === value).map( tag => tag.label );
                            if( labels.length ){
                                this.jumpToLabel( args.includes('random') ? labels[Math.floor(Math.random() * labels.length)] : labels[0] );
                            }
                        }    
                        break;
                }
            }
        }
    }
};

(function ( /* autosetup */) {
    KunCommands.Initialize();
    KunCommands_Setup_EscapeChars();
    KunCommands_Setup_Command();
    KunCommands_Setup_Interpreter();
})( /* */);

