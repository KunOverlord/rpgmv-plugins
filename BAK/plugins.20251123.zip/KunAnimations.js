//=============================================================================
// KunAnimations.js
//=============================================================================
/*:
 * @filename KunAnimations.js
 * @plugindesc Kun Interactive Picture Animations - Create Animated and Interactive picture scenes
 * @version 3.33
 * @author KUN
 * @target MC | MZ
 * 
 * @help
 * 
 * COMMANDS:
 * 
 *      KunAnimations play|set animation-name [setName] [wait frames:frame_offset]
 *          Switch animation frameset setName for animation-name
 *          If offsetVarx and offsetVarY are defined, both vars will apply the defined offset
 *          Use offsetScale % to scale the offset displacement for each coordinate
 * 
 *      KunAnimations reset animation-name [replay]
 *          Resets the given animation
 *          Restarts the controller if replay is required
 * 
 *      KunAnimations fps animation-name [fps] [import]
 *          Set custom frames per second for the playing animation-name. Define import to use a Game Variable to grab the fps from
 * 
 *      KunAnimations speed|variant [animation|alias] [variant]
 *          Creates an additive variant percent value over the FPS and LOOP animation properties,
 *          to cause a duration and speed random behaviour.
 * 
 *      KunAnimations playback [animation] [on|off]
 *          Keep playing the animation once finished again and again, if this animation has a next animation list
 * 
 *      KunAnimations pause animation-name
 *          Pause animation-name if playing
 * 
 *      KunAnimations resume animation-name
 *          Resume animation-name if paused
 * 
 *      KunAnimations target [random|include|exclude] [tag:tag:tag:...]
 *          Update to the next target in the list of touched spots
 *          Tag random for random target selection inthe available state
 *          Tag include to only get the targets from the selected tags
 *          Tag exclude to get all the targets non included in the selected tags
 * 
 *      KunAnimations spot animation-name spot-name
 *          Export the X and Y coordinates of the spot-name area if available in the current animation play
 * 
 *      KunAnimations repeat [animation|alias]
 *          Repeats the last spot targeted
 * 
 *      KunAnimations mode [playback|capture|touch|disabled]
 *          Set the mouse interactive mode. Set touch to activate the interactive events. Set capture to describe hotspot areas in the console (requires debug mode on). Set disable to turn off the event listener.
 * 
 *      KunAnimations clear [targets | alias]
 *          Clear the current target queue
 *          Clear targets or defined aliases
 * 
 *      KunAnimations alias [alias_name] [animation_name] [pictureId]
 *          Create an alias for a specific animation controller to ease picture swapping with the same tags
 *          Use a pictureId to filter which animation picture is the alias for
 * 
 *      KunAnimations load [profile:profile:profile] [id:x:y:sx:sy:opacity:blend:origin] [alias]
 *          Prepare a staged scene and setup picture from an existing animation profile
 *          Fill in all required setups with picture ID, position(x,y), scale(sx,sy), opacity, blending and origin
 *          Override the profile alias if required
 * 
 *      KunAnimations wait [elapsed_seconds] [random_elapsed_seconds]
 *          Wait for elapsed seconds before running the next routines in the event editor
 *          Add random elapsed seconds to define a randomized timespan
 * 
 *      KunAnimations prepare | complete
 *          Resets all the active animations to prepare a new animation or close a running one.
 * 
 *      KunAnimations action [alias|picture] [action_tag]
 * 
 *      KunAnimations playlist [alias|picture] [clear|animation1:animation2:animation3:...]
 *          Create a playlist for a scene playback
 *          Use alias and picturenames alike
 *          Use clear command to remove a playlist
 *          Define a list of animations separated by :
 * 
 *      KunAnimations playback [alias|picture]
 *          Play an animation from the PlayBack manager
 *          Define playback mode to let the Animation Controller get the animations from the user's playlist
 * 
 *      KunAnimations playspot [alias|picture]
 *          Capture an interactive hotspot from the current playing animation of the given picture.
 *          Captured spot will export the registered X and Y Game Variables.
 * 
 *      KunAnimations stages [alias|picture] [stage:picture] [stage:picture] [stage:picture] [...]
 *          Binds a list of stages to this picture to replace the current playing picture with a single command line
 * 
 *      KunAnimations stage [alias|picture] [stage]
 *          Changes the current picture and animation to the defined stage
 *          Picture ID and animation alias will be moved to the next stage picture
 * 
 *      KunAnimations position [x1:y1:x2:y2] [x1:y1:x2:y2] [x1:y1:x2:y2] ...
 *          Set the TouchX and TouchY game variables with the coordinates providen
 *          if more than one block, will random among them
 *          set x1,y1 to the top-left, set x2,y2 to the top-right
 *          set only x1,y1, to define the x,y righ away
 * 
 * 
 *      KunAnimations spotmenu [animation|alias] [skip|random|first|last|cancel] [left|center|right] [window|dim|transparent]
 *      KunAnimations animationmenu [animation|alias] [skip|random|first|last|cancel] [left|center|right] [window|dim|transparent]
 *      KunAnimations stagemenu [animation|alias] [skip|random|first|last|cancel] [left|center|right] [window|dim|transparent]
 * 
 * 
 * HIERARCHY:
 * 
 *  -> Scene
 *  ----> Spritesheet
 *  ----> Animation
 *  --------> TouchSpot
 * 
 *  - Animation Controllers
 *    defined by the Selected Picture File.
 *    Here you can setup the columns and rows, to properly display the frames.
 * 
 *  - Animation Frameset Groups
 *    A list of frames to play, with a custom FPS, behavior and looping iterations.
 * 
 *  - Touch Spots
 *    Every frameset animates a list of frames, but you can define on these a list of specific spots
 *    to click and cause a reaction, update a Game Variable, play a custom sound effect,
 *    and change to another specific frameset.
 * 
 * 
 * @param debug
 * @text Debug Level
 * @desc Show debug info. Activate Trace Log to detail the imports and exports of data.
 * @type select
 * @option TraceLog
 * @value 2
 * @option Enabled
 * @value 1
 * @option Disabled
 * @value 0
 * @default 0
 * 
 * @param accurateSpots
 * @text Accurate Spots
 * @desc Set targetting spot accurate, or leave it disabled to random spot area coordinates.
 * @type boolean
 * @default false
 * 
 * @param masterFPS
 * @text Master Frame Time
 * @desc default frame time
 * @type number
 * @min 1
 * @default 10
 * 
 * @param touchVarCounter
 * @text Touch Counter Variable
 * @desc This variable handles the counter of enqueued interactions performed by the player
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchVarLimit
 * @parent touchVar
 * @text Touch Limit Variable
 * @desc How many interactions can be saved in the queue. Can be updated in game to increase the touch events.
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchMode
 * @parent touchVar
 * @text Target Switch
 * @desc Get if there was a target spot fired in the last target call
 * @type switch
 * @default 0
 * 
 * @param touchX
 * @text Touch X Var
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchY
 * @text Touch Y Var
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param wheel
 * @text wheel var
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchSfx
 * @text Default Touch SE
 * @desc Define a default sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param cancelSfx
 * @text Don't Touch SE
 * @desc Define a no touch sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param selectSfx
 * @text Select SE
 * @desc Define a wheel/select sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param labels
 * @type string[]
 * @text Labels
 * @desc Assign labels to hotspot and animation names, displayable on command menus. Split with colon: value:label1:label2:...
 * 
 * @param scenes
 * @type struct<Scene>[]
 * @text Animation Scenes
 * @desc Define the DataBase of Animation Scene Controllers (keep it clean and easy!!)
 * 
 * @param controllers
 * @parent scenes
 * @type struct<Scene>[]
 * @text Animation Scenes (OLD)
 * @desc Backward compatibility. Move to Animation Scenes (scenes)
 * 
 */


/**
 * @class {KunScenes}
 */
class KunScenes {
    /**
     * @returns {KunScenes}
     */
    constructor() {
        if (KunScenes.__instance) {
            return KunScenes.__instance;
        }

        KunScenes.__instance = this;

        const importer = this.importer();
        const parameters = importer.pluginData();

        this._mode = KunScenes.Mode.Disabled;
        this._debug = parameters.debug;
        this._accurateSpots = parameters.accurateSpots;
        this._fps = parameters.masterFPS || 12;
        this._touchVar = parameters.touchVarCounter;
        this._limitVar = parameters.touchVarLimit;
        this._targetSwitch = parameters.touchMode;

        this._varX = parameters.touchX;
        this._varY = parameters.touchY;
        this._varWheel = parameters.wheel;
        this._sfx = {
            'touch': parameters.touchSfx || '',
            'cancel': parameters.cancelSfx || '',
            'select': parameters.selectSfx || '',
        };


        this._scenes = {};
        importer.createScenes(parameters.scenes || []).forEach(scene => this.add(scene));
        this._labels = importer.createLabels(parameters.labels || []);
        this.initialize();
    }
    /**
     * 
     */
    initialize() {
        this._targets = new KunTargets();
        this._playlist = new KunPlayList();
    }
    /**
     * @returns {KunPlayList}
     */
    playlist() {
        return this._playlist;
    }
    /**
     * @returns {KunTargets}
     */
    targets() {
        return this._targets;
    }
    /**
     * @returns {KunSceneReader}
     */
    importer() {
        return new KunSceneReader();
    }

    /**
     * @param {Boolean} list 
     * @returns {Object|String[]}
     */
    labels(list = false) {
        return list ? Object.values(this._labels) : this._labels;
    };
    /**
     * @param {KunScenes.DebugLevel|Number} level
     * @returns {Boolean}
     */
    debug(level = KunScenes.DebugLevel.Enabled) {
        return this._debug && this._debug >= level;
    };
    /**
     * @returns {Boolean}
     */
    accurateSpots() {
        return this._accurateSpots;
    }
    /**
     * @param {String} mode 
     * @returns {KunScenes}
     */
    setMode(mode) {
        this._mode = mode;
        if (this.mode() === KunScenes.Mode.Disabled) {
            this.clearTargets();
        }
        return this;
    };
    /**
     * @returns {String}
     */
    sfx(name = '') {
        return name && this._sfx[name] || this._sfx.touch;
    };
    /**
     * @param {Boolean} unlock
     * @returns {KunScenes}
     */
    touchMode(unlock = true) {
        if (this._targetSwitch) {
            $gameSwitches.setValue(this._targetSwitch, unlock || false);
        }
        return this;
    };
    /**
     * @returns {Boolean}
     */
    locked() {
        return this._mode === KunScenes.Mode.Disabled;
    };
    /**
     * Required for clear chaining. Do not remove atm
     * @returns {KunScenes}
     */
    clearTargets() {
        this.targets().clear();
        return this;
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @returns {KunScenes}
     */
    setPosition(x = 0, y = 0) {
        if (this._varX > 0) {
            $gameVariables.setValue(this._varX, x);
        }
        if (this._varY > 0) {
            $gameVariables.setValue(this._varY, y);
        }
        return this;
    };
    /**
     * @returns {Object} {x,y}
     */
    position() {
        return {
            'x': this._varX && $gameVariables.value(this._varX) || 0,
            'y': this._varY && $gameVariables.value(this._varY) || 0,
        };
    };
    /**
     * 
     * @param {Number} x1 
     * @param {Number} y1 
     * @param {Number} x2 
     * @param {Number} y2
     * @returns {KunScenes}
     */
    area(x1 = 0, y1 = 0, x2 = 0, y2 = 0) {
        if (x2 && y2) {
            this.setPosition(
                Math.floor(Math.random() * (x2 - x1)) + x1,
                Math.floor(Math.random() * (y2 - y1)) + y1,
            );
        }
        else {
            this.setPosition(x1, y1);
        }
        return this;
    };
    /**
     * @param {String} name 
     * @param {Number} x 
     * @param {Number} y 
     * @returns {Object} {x,y}
     */
    picturePosition(name, x = 0, y = 0) {
        const pictures = name && $gameScreen._pictures.filter(picture => picture && picture._name === name) || [];
        const position = { x: 0, y: 0, };
        if (pictures.length) {
            position.x = pictures[0]._x + Math.floor(pictures[0]._scaleX / 100 * x);
            position.y = pictures[0]._y + Math.floor(pictures[0]._scaleY / 100 * y);
        }
        return position;
    };
    /**
     * @param {Number} value 
     * @returns {KunScenes}
     */
    scroll(value = 0) {
        if (Math.abs(value) > 0 && this._varWheel) {
            const min = 0;
            const max = 8;
            const amount = Math.max(($gameVariables.value(this._varWheel) + value / Math.abs(value)) % max, min);
            $gameVariables.setValue(this._varWheel, amount);
            //console.log($gameVariables.value(this._varWheel));
        }
        return this;
    };
    /**
     * @param {Number} counter 
     * @returns {KunScenes}
     */
    updateTouchPoints(counter = 0) {
        if (this._touchVar > 0) {
            $gameVariables.setValue(this._touchVar, counter);
        }
        return this;
    };
    /**
     * @param {Boolean} gameVar
     * @returns {Number}
     */
    touchLimit(gameVar = false) {
        return gameVar ? this._limitVar : this._limitVar && $gameVariables.value(this._limitVar) || 1;
    };
    /**
     * @returns {Boolean}
     */
    canCapture = function () {
        return this.mode() === KunScenes.Mode.Capture;
    };
    /**
     * @returns {Boolean}
     */
    canTouch() {
        return this.mode() === KunScenes.Mode.Touch && !this.locked();
    };
    /**
     * @returns {Boolean}
     */
    canWheel() {
        return this.mode() === KunScenes.Mode.Touch && this._varWheel > 0;
    };
    /**
     * @returns {Boolean}
     */
    canPlayBack() {
        return this.mode() === KunScenes.Mode.PlayBack;
    };
    /**
     * @returns {String}
     */
    mode() {
        return this._mode;
    };
    /**
     * @returns Number
     */
    fps() {
        return this._fps || 10;
    };
    /**
     * @param {Boolean} list
     * @returns {KunPicture[]|Object}
     */
    scenes(list = false) {
        return list ? Object.values(this._scenes) : this._scenes;
    };
    /**
     * @param {String} name 
     * @returns {Boolean}
     */
    has(name = '') {
        return name && this.scenes().hasOwnProperty(name);
    }
    /**
     * @param {KunPicture} scene 
     * @returns {KunScenes}
     */
    add(scene = null) {
        if (scene && scene instanceof KunPicture && !this.has(scene.name())) {
            this._scenes[scene.name()] = scene;
        }
        return this;
    }
    /**
     * @param {String} name 
     * @returns {KunPicture}
     */
    scene(name = '') {
        return this.scenes()[name] || null;
    }
    /**
     * @param {Number} pictureId 
     * @param {String} name 
     * @param {Number} x 
     * @param {Number} y 
     * @param {Number} scaleX 
     * @param {Number} scaleY 
     * @param {Number} opacity 
     * @param {Number} blend 
     * @param {Number} origin
     * @returns {Game_Picture}
     */
    preparePicture(name = '', pictureId = 0, x = 0, y = 0, scaleX = 100, scaleY = 100, opacity = 255, blend = 0, origin = 0) {

        if (name && pictureId) {
            $gameScreen.showPicture(
                pictureId, name,
                origin || 0, // origin (top-left)
                x, y,
                scaleX, scaleY,
                opacity, blend);

            return $gameScreen.picture(pictureId);
        }

        return null;
    };
    /**
     * @param {Number} pictureId 
     * @param {String} pictureName 
     * @returns {Game_Picture}
     */
    replacePicture(pictureId = 0, pictureName = '') {
        if (pictureName && pictureId) {

            const original = $gameScreen.picture(pictureId);
            if (original) {

                return this.preparePicture(pictureName, pictureId,
                    original.x(), original.y(),
                    original.scaleX(), original.scaleY(),
                    original.opacity(), original.blendMode(),
                    original.origin());
            }

        }
        return null;
    };
    /**
     * Create an animation and alias from a profile setup
     * @param {String} name 
     * @param {Number} pictureId 
     * @param {Boolean} autoplay 
     * @param {String} alias
     * @returns {KunAnimation}
     */
    loadGroup(name, pictureId = 0, autoplay = false, alias = '') {
        const scenes = this.scenes(true).filter(scene => scene.package() === name);
        if (scenes.length) {
            const animation = scenes[0].createAnimation(pictureId, alias, '', autoplay);
            KunScenes.DebugLog(`Loading Group: ${animation.name()} (${animation.alias()})`);
            const stage = alias || name;
            for (var i = 0; i < scenes.length; i++) {
                animation.addStage(`${stage}_${i + 1}`, scenes[i].name());
            }
            return animation;
        }
        return null;
    };

    /**
     * @param {String} sound 
     * @param {Number} round
     * @returns {KunScenes}
     */
    static playSound(sound, round) {
        if (typeof KunSounds === 'function') {
            KunSounds.play(sound, round);
        }
        return this;
    };
    /**
     * @param {String} sfx
     * @param {Number} pitch
     * @param {Number} pan
     * @param {Boolean} random
     * @returns {KunScenes}
     */
    static playFx(sfx, pitch = 90, pan = 0, random = false) {
        if (sfx.length) {
            if (random) {
                pitch += Math.floor(Math.random() * 20) - 10;
                pan += Math.floor(Math.random() * 20) - 10;
            }
            KunScenes.AudioManager(sfx, 100, pitch, pan);
        }
        return this;
    };
    /**
     * @param {String} se 
     * @param {Number} volume 
     * @param {Number} pitch 
     * @param {Number} pan 
     * @param {Boolean} interrupt
     */
    static AudioManager(se, volume = 90, pitch = 100, pan = 0, interrupt = false) {
        if (se.length) {
            if (interrupt) {
                AudioManager.stopSe();
            }
            AudioManager.playSe({ name: se, pan: pan, pitch: pitch, volume: volume });
        }
    };
    /**
     * @param {String} message 
     */
    static DebugLog(message = '') {
        if (KunScenes.manager().debug()) {
            console.log('[KunAnimations]', message);
        }
    };
    /**
     * @returns {KunPlayList}
     */
    static PlayList() {
        return KunScenes.manager().playlist();
    }
    /**
     * @returns {KunTargets}
     */
    static Targets() {
        return KunScenes.manager().targets();
    }
    /**
     * @returns {KunScenes}
     */
    static manager() {
        return KunScenes.__instance || new KunScenes();
    }
};

/**
 * @returns {KunScenes.Mode|String}
 */
KunScenes.Mode = {
    Disabled: 'disabled',
    Touch: 'touch',
    Capture: 'capture',
    PlayBack: 'playback',
};
/**
 * @type {KunScenes.Behavior|String}
 */
KunScenes.Behavior = {
    Default: 'default',
    Forward: 'forward',
    Reverse: 'reverse',
    PingPong: 'ping-pong',
    Static: 'static',
};
/**
 * @returns {KunScenes.DebugLevel|String}
 */
KunScenes.DebugLevel = {
    Disabled: 0,
    Enabled: 1,
    TraceLog: 2,
};
/**
 * @class {KunSceneReader}
 */
class KunSceneReader {
    /**
     * 
     */
    constructor() {
        this._scenes = 0;
        this._pictures = 0;
        this._framesets = 0;
        this._hotspots = 0;
        this._actions = 0;
        this._conditions = 0;
        this._labels = 0;
    }
    /**
     * Converts labels from label:text:text:... to {label:text|text|...}
     * @param {Object[]} labelData 
     * @returns {Object[]}
     */
    createLabels(labelData = []) {
        const labels = {};
        labelData.map(tag => tag.split(':')).filter(tag => tag.length > 1).forEach(tag => {
            labels[tag[0]] = tag.slice(1).join(':');
        });
        return labels;
    }

    /**
     * @returns {KunSceneReader}
     */
    summary() {
        //leave this here for debugging.
        if (KunScenes.manager().debug(KunScenes.DebugLevel.TraceLog)) {
            KunScenes.DebugLog(`Imported a total of ${this._pictures} animated pictures, ${this._framesets} animation layers and ${this._hotspots} hotspots`);
            KunScenes.DebugLog(`Imported a total of ${this._actions} actions and  ${this._conditions} conditions`);
            KunScenes.DebugLog(`Imported a total of ${this._labels} labels`);
        }
        return this;
    };
    /**
     * @returns {Object[]}
     */
    collections() {
        return $plugins.filter(p => p.name === 'KunAnimationPack' && p.status && p.parameters.scenes.length > 0)
            .map(plugin => plugin.parameters);
    };
    /**
     * @param {Object[]} input 
     * @returns {KunPicture[]}
     */
    createScenes(input) {
        const scenes = [];
        if (Array.isArray(input)) {
            input.forEach(controller => {
                const spots = {};
                const framesets = Array.isArray(controller.framesets) ? controller.framesets : [];
                const actions = Array.isArray(controller.actions) ? controller.actions : [];
                //import all scene defined hotspots
                (Array.isArray(controller.hotspots) ? controller.hotspots : []).forEach(spot => spots[spot.name] = spot);
                (Array.isArray(controller.pictures) ? controller.pictures : []).forEach(picture => {
                    //register a Scene Controller on every picture loaded in the list
                    const scene = this.scene(picture, controller);
                    this.populate(scene, framesets, spots, actions);
                    scenes.push(scene);
                    //KunScenes.add(scene);
                    this._pictures++;
                });
                this._scenes++;
            });
        }
        this.summary();
        return scenes;
        //return this.summary();
    };
    /**
     * 
     * @param {Object} spriteSheet 
     * @param {Object} controller 
     * @returns {KunPicture}
     */
    scene(spriteSheet, controller) {
        return new KunPicture(
            spriteSheet.picture,
            controller.cols,
            controller.rows,
            controller.fps,
            spriteSheet.sound,
            spriteSheet.soundLoop,
            spriteSheet.package
        );
    }
    /**
     * 
     * @param {KunPicture} scene 
     * @param {KunFrameSet[]} frameSets 
     * @param {KunHotSpot[]} spots 
     * @param {KunAction[]} actions 
     */
    populate(scene, frameSets = [], spots = [], actions = []) {
        if (scene instanceof KunPicture) {
            frameSets.forEach(fs => {
                scene.add(this.frameset(fs, spots));
            });
            actions.forEach(action => {
                scene.addAction(this.action(action));
            });
        }
    }

    /**
     * @param {Object} data 
     * @param {Object} spots 
     * @returns {KunFrameSet}
     */
    frameset(data, spots) {
        const frameset = new KunFrameSet(
            data.name,
            data.type,
            data.fps,
            data.loops,
            Array.isArray(data.next) ? data.next : [],
            Array.isArray(data.sounds) ? data.sounds : data.bank || [],
            data.offsetX,
            data.offsetY
        );
        //import frameset
        (Array.isArray(data.frames) ? data.frames : []).forEach(function (frame) {
            frameset.add(frame);
        });
        //import conditions
        (Array.isArray(data.conditions) ? data.conditions : []).forEach(condition => {
            frameset.addCondition(this.condition(condition));
        });
        //merge hotspots into touchspots
        (Array.isArray(data.spots) ? data.spots : []).forEach(touchSpot => {
            if (spots.hasOwnProperty(touchSpot.name)) {
                var spot = spots[touchSpot.name];
                Object.keys(spot).forEach(function (key) {
                    if (!touchSpot.hasOwnProperty(key)) {
                        touchSpot[key] = spot[key];
                    }
                });
                frameset.registerSpot(this.spot(touchSpot));
            }
        });

        //import all tags
        (Array.isArray(data.tags) ? data.tags : []).forEach( tag => frameset.tag(tag) );        

        this._framesets++;

        return frameset;
    };
    /**
     * 
     * @param {Object} data 
     * @returns {KunAction}
     */
    action(data) {
        this._actions++;
        return new KunAction(
            data.var || 0,
            data.op || '',
            data.val,
        );
    };
    /**
     * 
     * @param {Object} data 
     */
    condition(data) {

        this._conditions++;

        return new KunCondition(
            data.var || 0,
            data.op || '',
            data.val || 0,
            data.target || false,
            data.on || [],
            data.off || []
        );
    };
    /**
     * @param {Object} data 
     * @returns {KunHotSpot}
     */
    spot(data) {
        this._hotspots++;
        const spot = new KunHotSpot(
            data.name,
            data.x1,
            data.y1,
            data.x2,
            data.y2,
            data.trigger || KunHotSpot.Trigger.Queue,
            Array.isArray(data.next) ? data.next : [],
            data.sfx
        );
        if (data.varId > 0) {
            //backwards compatibility.
            spot.addAction(new KunAction(data.varId, data.behavior, data.amount || 1));
        }
        //No actions parameter until next versions, use varId instead for backwards compatibility
        if (Array.isArray(data.actions)) {
            //map all event actions
            data.actions.forEach(action => spot.addAction(this.action(action)));
        }
        if (Array.isArray(data.conditions)) {
            //map all event conditions
            data.conditions.forEach(condition => spot.addCondition(this.condition(condition)));
        }
        if (Array.isArray(data.tags)) {
            data.tags.forEach(tag => spot.tag(tag));
        }
        return spot;
    }

    /**
     * @returns {Object}
     */
    pluginData() {

        function _readData(key, value) {
            if (typeof value === 'string' && value.length) {
                try {
                    if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                        return JSON.parse(value, _readData);
                    }
                } catch (e) {
                    // If parsing fails or it's not an object/array, return the original value
                }
                if (value === 'true' || value === 'false') {
                    return value === 'true';
                }
                if (!isNaN(value)) {
                    return parseInt(value);
                }
            }
            else if (typeof value === 'object' && !Array.isArray(value)) {
                var _output = {};
                Object.keys(value).forEach(function (key) {
                    _output[key] = _readData(key, value[key]);
                });
                return _output;
            }
            return value;
        };

        var pluginData = _readData('KunAnimations', PluginManager.parameters('KunAnimations'));
        //no more local plugin scenes reading since version 3.31
        //pluginData.scenes = pluginData.scenes || [];
        pluginData.scenes = [];

        this.collections().map(pack => _readData('KunAnimationPack', pack)).forEach(pack => {
            //Import animation packs
            if (pack.scenes && pack.scenes.length) {
                KunScenes.DebugLog(`Loading Animation Pack ${pack.name} (${pack.scenes.length} scenes)`);
                pack.scenes.forEach(scene => {
                    pluginData.scenes.push(_readData('KunAnimationPack', scene));
                });
            }
        });
        return pluginData;
    };
}


/**
 * @class {KunTargets}
 */
class KunTargets {
    /**
     * 
     */
    constructor() {
        this._targets = [];
        this._enabled = true;
    }
    /**
     * @returns {KunTargets}
     */
    reset() {
        this.toggle();
        this._targets = [];
        return this.toggle(true);
    };
    /**
     * @param {Boolean} enabled 
     * @returns {KunTargets}
     */
    toggle(enabled = false) {
        this._enabled = enabled;
        return this;
    };
    /**
     * @returns {Boolean}
     */
    locked() {
        return !this._enabled;
    }
    /**
     * @returns {KunTarget[]}
     */
    targets() {
        return this._targets;
    };
    /**
     * @returns {Number}
     */
    count() {
        return this.targets().length;
    };
    /**
     * @returns {Number}
     */
    size() {
        return KunScenes.manager().touchLimit();
    };
    /**
     * @returns {Boolean}
     */
    full() {
        return this.count() >= this.size();
    };
    /**
     * @returns {KunTargets}
     */
    drop() {
        if (this.count() && !this.locked()) {
            this.toggle();
            this.targets().shift();
            this.update().toggle(true);
            KunScenes.playFx(KunScenes.manager().sfx('cancel'));
        }
        return this;
    };
    /**
     * @param {Boolean} random 
     * @returns {KunTarget}
     */
    target(random = false) {
        if (this.count() && !this.locked()) {

            this.toggle();

            const target = random ?
                this.targets().splice(Math.floor(Math.random() * this.count()), 1)[0] :
                this.targets().shift();

            this.update().toggle(true);

            return target.execute();
        }
        return null;
    }
    /**
     * @param {String[]} tags 
     * @param {Boolean} random
     * @returns {KunTarget}
     */
    include(tags = [],random = false) {
        if (this.count() && !this.locked()) {
            const targets = this.targets().filter(target => target.tagged(tags));
            if (targets.length) {
                const selected = random ? targets[Math.floor(Math.random() * targets.length)] : targets[0];
                this.toggle();
                this.targets().splice(this.targets().indexOf(selected), 1);
                this.update().toggle(true);
                return selected.execute();
            }
        };
        return null;
    }
    /**
     * @param {String[]} tags 
     * @param {Boolean} random
     * @returns {KunTarget}
     */
    exclude(tags = [] , random = false) {
        if (this.count() && !this.locked()) {
            const targets = this.targets().filter(target => target.untagged(tags));
            if (targets.length) {
                const selected = random ? targets[Math.floor(Math.random() * targets.length)] : targets[0];
                this.toggle();
                this.targets().splice(this.targets().indexOf(selected), 1);
                this.update().toggle(true);
                return selected.execute();
            }
        };
        return null;
    }
    /**
     * @returns {Boolean}
     */
    ready() {
        return !this.full() && !this.locked();
    };
    /**
     * @param {KunTarget} target 
     * @returns {KunTargets}
     */
    add(target) {
        if (target instanceof KunTarget && this.ready()) {
            this.targets().push(target);
            this.update();
        }
        return this;
    };
    /**
     * @returns {KunTargets}
     */
    clear() {
        return this.reset().update();
    };
    /**
     * @returns {KunTargets}
     */
    update() {
        KunScenes.manager().updateTouchPoints(this.count());
        return this;
    };
};


/**
 * @class {KunPlayList}
 */
class KunPlayList {
    /**
     * 
     */
    constructor() {

        this._animations = {};
    }
    /**
     * @returns {KunScenes}
     */
    manager() {
        return KunScenes.manager();
    }
    /**
     * @param {Boolean} list 
     * @returns {KunAnimation[]|Object}
     */
    animations(list = false) {
        return list && Object.values(this._animations) || this._animations;
    };
    /**
     * @param {String} name 
     * @returns {Boolean}
     */
    has(name = '') {
        return this.animations(true).filter(anim => anim.is(name)).length > 0;
        //return this.animations().hasOwnProperty(useAlias ? this.alias(name) : name);
    };
    /**
     * @param {KunAnimation} animation 
     * @returns {KunPlayList}
     */
    add(animation = null) {
        //if (animation instanceof KunAnimation && !this.has(animation.name())) {
        if (animation instanceof KunAnimation) {
            this.animations()[animation.name()] = animation;
        }
        return this;
    }
    /**
     * @param {String} name 
     * @returns {KunAnimation}
     */
    get(name = '') {
        return this.animations(true).filter(anim => anim.is(name))[0] || null;
    };
    /**
     * @param {String} name 
     * @param {Number} pictureId 
     * @param {String} alias 
     * @param {String} frameset 
     * @returns {KunAnimation}
     */
    setup(name = '', pictureId = 0, alias = '', frameset = '') {
        if (this.manager().has(name)) {
            const animation = this.animations()[name] || this.manager().scene(name).createAnimation(pictureId, alias, frameset, frameset.length > 0);
            if (animation) {
                if (alias) {
                    //do not remove other animations yet, but ensure they're not using this alias anymore
                    this.animations(true).filter(anim => anim.alias() === alias).forEach(anim => anim.setAlias());
                    animation.setAlias(alias);
                }
                if (pictureId) {
                    animation.setID(pictureId);
                }
                this.add(animation);
                return animation;
            }
        }
        return null;
    };
    /**
     * @param {String} name 
     * @param {String} stage 
     * @returns {KunPlayList}
     */
    setstage(name = '', stage = '', reset = false) {
        const animation = this.get(name);
        if (animation && animation.stages()[stage]) {
            const picture = animation.stages()[stage]
            const frameset = animation.frameset() && animation.frameset().name() || '';
            const newanimation = this.setup(picture, animation.ID(), animation.alias(), !reset && frameset || '');
            //copy all stages into the new animation
            newanimation._stages = animation._stages;
            //copy variant modifier
            newanimation._variant = animation._variant || 0;
            this.manager().replacePicture(animation.ID(), picture);
        }
        return this;
    };

    /**
     * @param {String} name 
     * @param {String} picture 
     * @returns {Boolean}
     */
    replace(name, picture = '') {
        const animation = this.get(name);
        return animation && animation.replaceBy(picture) || false;
    };
    /**
     * @param {String} alias 
     * @returns {String}
     */
    alias(alias = '') {
        return this.animations(true)
            .filter(animation => animation.is(alias))
            .map(animation => animation.name())[0] || '';
    };
    /**
     * @param {String} animation 
     * @returns {String[]}
     */
    list(animation = '') {
        const scene = this.get(animation);
        return scene && scene.playbackList() || [];
    };
    /**
     * @param {String} animation 
     * @param {String[]} list 
     * @returns {KunPlayList}
     */
    push(animation = '', list = []) {
        if (this.has(animation)) {
            this.get(animation).push(list);
        }
        return this;
    };
    /**
     * @param {String} animation 
     * @param {String} frameset
     * @returns {KunPlayList}
     */
    play(animation = '', frameset = '') {
        if (this.has(animation)) {
            this.get(animation).play(frameset);
        }
        return this;
    };
    /**
     * @returns {KunPlayList}
     */
    clear() {
        this.animations().forEach( anim => {
            if(anim.ID()){
                //remove picture
                $gameScreen.erasePicture(anim.ID());
            }            
        } );
        this._animations = [];
        return this;
    };
    /**
     * @param {String} animation 
     * @param {Number} fps 
     * @returns {KunPlayList}
     */
    setFps(animation = '', fps = 0) {
        const scene = this.get(animation);
        if (scene) {
            scene.setFps(fps);
        }
        return this;
    };
    /**
     * Gets a random spot from the playbacks' active scene animation.
     * @param {String} name 
     * @param {String} spot
     * @returns {KunHotSpot}
     */
    spot(name, spot = 'random') {
        const animation = this.get(name);
        if (animation) {
            return spot === 'random' ? animation.randomSpot() : animation.spots()[spot] || null;
        }
        return null;
    };
    /**
     * @param {String} name 
     * @param {String[]} tags 
     * @returns {KunPlayList}
     */
    tag( name = '' , tags = []){
        if( tags.length ){
            const animation = this.get(name);
            if( animation ){
                animation.playTag(tags[Math.floor(Math.random() * tags.length)] , true );
            }
        }
        return this;
    }    
    /**
     * @param {String} name 
     * @param {String} target 
     * @param {Boolean} touch
     * @returns {KunPlayList}
     */
    capture(name = '', target = '', touch = false) {
        const animation = this.get(name);
        if (animation) {
            animation.capture(target, touch, true);
        }
        return this;
    };
    /**
     * @param {String} name 
     * @returns {Object {X,Y}}
     */
    offset(name = '') {
        return this.has(name) ? this.get(name).offset() : { 'x': 0, 'y': 0 };
    };
};


/**
 * @param {String} name 
 * @param {Number} cols 
 * @param {Number} rows 
 * @param {Number} fps 
 * @param {String} soundProfile 
 * @param {Number} soundLoop
 * @param {String} package
 */
class KunPicture {
    constructor(name, cols = 1, rows = 1, fps = 0, soundProfile = '', soundLoop = 0, animPack = '') {
        this._name = name || '';
        this._cols = cols || 1;
        this._rows = rows || 1;
        this._framesets = [];
        this._animpack = animPack || '';
        //this one can be overriden
        this._fps = fps || KunScenes.manager().fps();
        this._audioProfile = soundProfile || '';
        this._audioLoop = soundLoop || 0;
        this._actions = [
            //KunActions
        ];
    }
    /**
     * @param {Number} pictureID
     * @param {String} alias
     * @param {String} first 
     * @param {Boolean} autoPlay
     * @returns {KunAnimation}
     */
    createAnimation(pictureId = 0, alias = '', first = '', autoPlay = false) {
        return new KunAnimation(this, first, autoPlay, pictureId, alias);
    };
    /**
     * @returns {String}
     */
    toString() {
        return this.name();
    };
    /**
     * @returns {String}
     */
    name() {
        return this._name;
    };
    /**
     * @returns {String}
     */
    package() {
        return this._animpack;
    }
    /**
     * @returns {KunFrameSet[]}
     */
    framesets() {
        return this._framesets;
    };
    /**
     * @returns {Number}
     */
    cols() { return this._cols; }
    /**
     * @returns {Number}
     */
    rows() { return this._rows; }
    /**
     * @returns {Number}
     */
    countFrames() { return this._cols * this._rows; };
    /**
     * @param {String} name 
     * @returns {Boolean}
     */
    has(name = '') {
        return name && this.framesets().filter(fs => fs.name() === name).length > 0;
    }
    /**
     * @param {KunFrameSet} frameset 
     * @returns {KunPicture}
     */
    add(frameset) {
        if (frameset instanceof KunFrameSet) {
            this.framesets().push(frameset);
        }
        return this;
    };
    /**
     * @returns {Boolean}
     */
    empty() {
        return this.framesets().length === 0;
    };
    /**
     * @param {String} sound
     * @returns {String}
     */
    soundProfile(sound = '') {
        return sound ? this._audioProfile && this._audioProfile + '-' + sound || sound : this._audioProfile;
    };
    /**
     * @returns {Number}
     */
    soundLoop() {
        return this._audioLoop;
    };
    /**
     * @returns {Number}
     */
    fps() {
        return this._fps;
    };
    /**
     * @param {KunAction} action
     * @returns {KunPicture}
     */
    addAction(action, tag = '') {
        if (action instanceof KunAction) {
            this._actions.push(action.tag(tag));
        }
        return this;
    };
    /**
     * @param {String} tag
     * @returns {KunAction[]}
     */
    actions(tag = '') {
        return tag ? this._actions.filter(action => action.is(tag)) : this._actions;
    };
    /**
     * @param {String} tag
     * @returns {KunPicture}
     */
    runActions(tag = '') {
        this.actions(tag).forEach(action => action.update());
        return this;
    };
}
/**
 * @class {KunFrameSet}
 */
class KunFrameSet {
    /**
     * @param {String} name 
     * @param {String|KunScenes.Behavior} type 
     * @param {Number} fps 
     * @param {Number} loops 
     * @param {String} next 
     * @param {String[]|String} sounds
     * @param {Number} offsetX
     * @param {Number} offsetY
     */
    constructor(name, type = '', fps = 0, loops = 0, next = [], sounds = [], offsetX = 0, offsetY = 0) {
        this._name = name.toLowerCase().replace(/[\s\_]/, '-');
        this._fps = fps || KunScenes.manager().fps();
        this._frames = [];
        this._type = type || KunScenes.Behavior.Default;
        this._loops = loops || 0;
        this._offsetX = offsetX || 0;
        this._offsetY = offsetY || 0;
        //this._tags = [];
        this._spots = {
            //interactive spots to touch
        };

        this._next = Array.isArray(next) ? next : (typeof next === 'string' && next.length ? [next] : []);
        this._sounds = Array.isArray(sounds) ? sounds : (typeof sounds === 'string' && sounds.length ? [sounds] : []);

        this._conditions = [
            //KunConditions
        ];

        this._tags = [
            //Add tags for frames
        ];
    }

    /**
     * @returns {Number}
     */
    offsetX() {
        return this._offsetX;
    };
    /**
     * @returns {Number}
     */
    offsetY() {
        return this._offsetY;
    };
    /**
     * @returns {Boolean}
     */
    interactive() {
        return this.spots(true).length > 0;
    };
    /**
     * @param {KunHotSpot} spot 
     * @returns {KunFrameSet}
     */
    registerSpot(spot) {
        if (spot instanceof KunHotSpot && !this._spots.hasOwnProperty(spot.name())) {
            this._spots[spot.name()] = spot;
        }
        return this;
    };
    /**
     * List all spots as array or object ids
     * @param {Boolean} list 
     * @returns {Object | KunHotSpot[]}
     */
    spots(list = false) {
        return list ? Object.values(this._spots) : this._spots;
    }
    /**
     * @param {String} spot 
     * @returns {Boolean}
     */
    hasSpot(spot = '') {
        return spot.length && this.spots().hasOwnProperty(spot);
    }
    /**
     * @param {String} spot 
     * @returns {KunHotSpot}
     */
    getSpot(spot) {
        return this.hasSpot(spot) ? this.spots()[spot] : null;
    }
    /**
     * Check if any spot was touched
     * @param {Number} x 
     * @param {Number} y 
     * @returns {KunHotSpot} 
     */
    touched(x = 0, y = 0) {
        const spots = this.spots(true).filter(target => target.canCollide(x, y));
        return spots[0] || null;
    };
    /**
     * @returns {String}
     */
    behavior() {
        return this._type;
    };
    /**
     * @param {Number} frame 
     * @returns {KunFrameSet}
     */
    add(frame) {
        this._frames.push(frame);
        return this;
    };
    /**
     * @returns {Number}
     */
    fps() {
        return this._fps;
    };
    /**
     * @returns {Number}
     */
    loops() {
        return this._loops;
    };
    /**
     * @returns {Number}
     */
    frames() {
        return this._frames.length && this._frames || [0];
    }
    /**
     * @returns {Number}
     */
    count() {
        return this.frames().length;
    };
    /**
     * @returns {Number}
     */
    first() {
        return this.frames()[0] || 0;
    };
    /**
     * @param {Number} index 
     * @returns {Number}
     */
    frame(index = 0) {
        return this.frames()[index % this.count()] || this.first();
    };
    /**
     * @returns {Number}
     */
    name() {
        return this._name;
    };
    /**
     * @returns {String[]}
     */
    next() {
        return this._next;
    };
    /**
     * @param {Boolean} select
     * @returns {String[]|String}
     */
    getNext(select = false) {
        if (select) {
            var size = this._next.length;
            return size ? this._next[Math.floor(Math.random() * size)] : '';
        }
        return this._next;
    }
    /**
     * @param {Boolean} select
     * @returns {String[]|String}
     */
    sounds(select = false) {
        var size = this._sounds.length;
        if (select) {
            //always return a string with a select flag!
            return size ? this._sounds[Math.floor(Math.random() * size)] : '';
        }
        return this._sounds;
    };
    /**
     * @returns {String[]}
     */
    tags( ){
        return this._tags;
    }    
    /**
     * @param {String} tag 
     * @returns {Boolean}
     */
    tagged( tag = ''){
        return tag && this.tags().includes(tag);
    }
    /**
     * @param {String} tag 
     * @returns {KunFrameSet}
     */
    tag(tag = ''){
        if( !this.tagged(tag)){
            this.tags().push(tag);
        }
        return this;
    }
    /**
     * @param {KunCondition} condition
     * @returns {KunFrameSet}
     */
    addCondition(condition) {
        if (condition instanceof KunCondition) {
            this._conditions.push(condition);
        }
        return this;
    };
    /**
     * @param {Boolean} filter
     * @returns {KunCondition[]}
     */
    conditions(filter = false) {
        return filter ?
            this._conditions.filter(condition => condition.validate()) :
            this._conditions;
    };
    /**
     * @returns {Boolean}
     */
    unlocked() {
        return this.conditions(true).length === this.conditions().length;
    };
    /**
     * @returns {KunFrameAnimation}
     */
    createAnimation() {
        switch (this.behavior()) {
            case KunScenes.Behavior.Static:
                return new KunFrameAnimation(this);
            case KunScenes.Behavior.PingPong:
                return new KunFramePingPong(this);
            case KunScenes.Behavior.Reverse:
                return new KunFrameBack(this);
            case KunScenes.Behavior.Default:
            case KunScenes.Behavior.Forward:
            default:
                return new KunFrameForward(this);
        }
    }
}



/**
 * @type {KunAnimation}
 */
class KunAnimation {
    /**
     * @param {KunPicture} scene 
     * @param {String} animation
     * @param {Boolean} autoPlay
     * @param {Number} pictureId
     * @param {String} alias
     */
    constructor(scene, animation = '', autoPlay = false, pictureId = 0, alias = '') {

        this._scene = scene instanceof KunPicture ? scene : null;
        //this._frameset = this.get(animation) || this.first();
        const fs = this.get(animation) || this.first();
        //handle frame states using FrameData subclasses
        this._state = fs && fs.createAnimation() || null;

        this.setAlias(alias || '');
        this.setID(pictureId || 0);

        this._playing = autoPlay;
        this._mode = KunAnimation.Mode.Disabled;

        //this one can be overriden
        this._variant = 0;

        this._playback = [];

        this._stages = {};
    }
    /**
     * @returns {KunScenes}
     */
    manager() {
        return KunScenes.manager();
    }
    /**
     * @returns {KunFrameAnimation}
     */
    frameLoop() {
        return this._state;
    }
    /**
     * @param {String} mode 
     * @returns {KunAnimation}
     */
    setMode(mode = KunAction.Mode.Static) {
        this._mode = mode;
        return this;
    }
    /**
     * @returns {String}
     */
    mode() {
        return this._mode;
    };
    /**
     * @returns {Boolean}
     */
    isPlayBack() {
        return this.mode() === KunAnimation.Mode.PlayBack;
    };
    /**
     * @returns {Boolean}
     */
    canTouch() {
        return this.mode() === KunAnimation.Mode.Touch;
    };
    /**
     * @param {Boolean} list 
     * @returns {String[]|Object}
     */
    stages(list = false) {
        return list ? Object.keys(this._stages) : this._stages;
    };
    /**
     * @param {String} stage 
     * @returns {KunPicture}
     */
    stage(stage = '') {
        return this.manager().scene(this.stages()[stage] || '');
    };
    /**
     * @param {String} stage 
     * @param {String} picture 
     * @returns {KunPicture}
     */
    addStage(stage = '', picture = '') {
        if (stage && !this.stages().hasOwnProperty(stage) && this.manager().has(picture)) {
            this.stages()[stage] = picture;
        }
        return this;
    };
    /**
     * @param {Boolean} list 
     * @returns {String[]}
     */
    labels(list = false) {
        return this.manager().labels(list);
    }
    /**
     * @param {String[]} names 
     * @returns {Object[]}
     */
    mapLabels(names = []) {
        const contents = this.labels();
        return names.map(name => {
            const labels = contents[name] && contents[name].split(':') || [name];
            const option = {};
            option[name] = labels[Math.floor(Math.random() * labels.length)];
            return option;
        });
    }
    /**
     * @param {String} type 
     * @returns {Object}
     */
    mapMenu(type = 'spot') {
        switch (type) {
            case 'stage':
                return this.mapLabels(this.stages(true));
            case 'animation':
                return this.mapLabels(this.animations().map(a => a.name()));
            case 'touch':
            case 'capture':
            default:
                const spots = this.frameset() && this.frameset().spots(true).map(s => s.name()) || [];
                return this.mapLabels(spots);
        }
    };
    /**
     * @param {String} tag 
     * @returns {KunAnimation}
     */
    runActions(tag = '') {
        if (this.scene()) {
            this.scene().runActions(tag);
        }
        return this;
    };
    /**
     * @param {String} animation 
     * @returns {KunAnimation}
     */
    push(animation) {
        this._playback.push(animation);
        return this;
    };
    /**
     * @returns {KunAnimation}
     */
    clear() {
        this._playback = [];
        return this;
    };
    /**
     * @returns {String[] }
     */
    playbackList() {
        return this._playback;
    };
    /**
     * @returns {String[]}
     */
    list() {
        return this.scene() && this.scene().framesets().map(fs => fs.name()) || [];
    };
    /**
     * @returns {Number}
     */
    rows() {
        return this.scene() && this.scene().rows() || 0;
    };
    /**
     * @returns {Number}
     */
    cols() {
        return this.scene() && this.scene().cols() || 0;
    };
    /**
     * @returns {Number}
     */
    frame() {
        return this.frameLoop().frame();
        //return this.frameset() && this.frameset().frame(this._frame) || 0;
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @returns {KunHotSpot}
     */
    touch(x, y) {
        return this.frameset() && this.frameset().touched(x, y) || null;
    };
    /**
     * @param {Boolean} unlockedOnly
     * @returns {KunHotSpot}
     */
    randomSpot(unlockedOnly) {
        const spots = unlockedOnly ? this.frameset().spots(true).filter(spot => spot.unlocked()) : this.frameset().spots(true);
        return spots.length ? spots[Math.floor(Math.random() * spots.length)] : null;
    };
    /**
     * @param {String[]} spots 
     * @returns {String[]}
     */
    filterSpots(spots = []) {
        return this.frameset().spots(true).filter(spot => spot.unlocked()).map(spot => spot.name());
    }
    /**
     * @param {KunHotSpot} spot 
     * @param {Number} x 
     * @param {Number} y 
     * @returns {KunTarget}
     */
    createTarget(spot = null, x = 0, y = 0) {
        if (spot instanceof KunHotSpot) {
            const targets = KunScenes.Targets();
            const target = new KunTarget(spot, this.name(), x, y, this.ID());
            targets.add(target);
            //console.log(target);
            return target;
        }
        return null;
    }
    /**
     * @param {KunHotSpot} spot 
     * @param {Number} x 
     * @param {Number} y 
     * @param {Boolean} playFx
     * @returns {KunAnimation}
     */
    target(spot, x, y, playFx = false) {
        if (spot instanceof KunHotSpot) {
            if (playFx) {
                spot.touchSfx();
            }
            switch (spot.trigger()) {
                case KunHotSpot.Trigger.Queue:
                    this.createTarget(spot, x, y);
                    //this.manager().targets().add(new KunTarget(spot, this.name(), x, y, this.ID()));
                    break;
                case KunHotSpot.Trigger.Instant:
                    spot.runActions();
                    this.manager().setPosition(x, y);
                    this.select(spot.next());
                    break;
                case KunHotSpot.Trigger.Frame:
                    var frame = this.frame();
                    spot.actions().forEach(action => action.set(frame));
                    break;
                case KunHotSpot.Trigger.NextFrame:
                    this.select(spot.next());
                    if (this.frameset()) {
                        const first = this.frameset().first();
                        spot.actions().forEach(action => action.set(first));
                    }
                    break;
            }
        }
        return this;
    };
    /**
     * @param {String} target
     * @param {Boolean} touch
     * @param {Boolean} unlockedOnly
     * @returns {KunAnimation}
     */
    capture(target = '', touch = false, unlockedOnly = false) {
        const spot = target && this.frameset().spots()[target] || this.randomSpot(unlockedOnly);
        if (spot instanceof KunHotSpot) {
            const accurate = this.manager().accurateSpots();
            const x = accurate ? spot.midx() : spot.x(true);
            const y = accurate ? spot.midy() : spot.y(true);
            const position = this.manager().picturePosition(this.name(), x, y);
            if (touch) {
                this.target(spot, position.x, position.y);
            }
            else {
                this.manager().setPosition(position.x, position.y);
            }
        }
        return this;
    };
    /**
     * @param {String} name 
     * @returns {Object {X,Y}}
     */
    offset() {
        const animation = this.frameset();
        return {
            'x': animation && animation.offsetX(),
            'y': animation && animation.offsetY(),
        };
    };
    /**
     * @returns {String[]}
     */
    next() {
        if (this.isPlayBack()) {
            //if playback list is set, pick from the list, otherwise, just keep playing the current frameset
            return this.playbackList().length ? this.playbackList() : [];
        }
        return this.frameset() && this.frameset().next() || [];
    };
    /**
     * @param {String} name
     * @returns {KunAnimation}
     */
    play(name = '') {
        if (name) {
            const fs = this.get(name, true);
            if (fs) {
                this._state = fs.createAnimation();
            }
        }

        this._playing = this.frameset() !== null;

        return this;
    }
    /**
     * @param {String} tag
     * @param {Boolean} random 
     * @returns {KunAnimation}
     */
    playTag( tag = '' , random = false ){
        if( tag ){
            const list = this.animations().filter( fs => fs.tagged(tag));
            if( list.length ){
                const fs = random && list[Math.floor(Math.random() * list.length)] || list[0];
                this._state = fs.createAnimation();
                //this._frameset = random && list[Math.floor(Math.random() * list.length)] || list[0];
                KunSceneManager.DebugLog(`Playing animation ${this.name()} by tag ${tag} ( ${fs.name()} selected)`);
                this.reset();
            }
        }
        this._playing = this.frameset() !== null;
        return this;
    }
    /**
     * @returns {KunAnimation}
     */
    playMap(){
        if( this.playlist().length){
            const selected = this.variable(true) % this.playlist().length;
            this.play( this.playlist()[selected]);
        }
        return this;
    }    
    /**
     * @returns {KunAnimation}
     */
    stop() {
        this._playing = false;
        return this;
    }
    /**
     * @returns {Boolean}
     */
    playing() {
        return this.ready() && this._playing;
    };
    /**
     * @returns {Number}
     */
    ID() {
        return this._pictureId;
    };
    /**
     * @return {KunAnimation}
     */
    setID(pictureId = 0) {
        this._pictureId = pictureId || 0;
        return this;
    };
    /**
     * @param {Boolean} useAlias 
     * @returns {String}
     */
    name(useAlias = false) {
        return useAlias && this._alias ? this.alias() : this.scene().name();
    };
    /**
     * @returns {String}
     */
    alias() {
        return this._alias;
    };
    /**
     * @param {String} alias 
     * @returns {KunAnimation}
     */
    setAlias(alias = '') {
        this._alias = alias || '';
        return this;
    };
    /**
     * @param {String} name 
     * @returns {Boolean}
     */
    is(name = '') {
        return name && (this.name() === name || this.alias() === name);
    }
    /**
     * @returns {Number}
     */
    fps() {
        return this._fps;
    };
    /**
     * @param {Number} fps
     * @param {Number} rate
     * @returns {KunAnimation} 
     */
    setFps(fps = 0, rate = 0) {
        this._fps = fps || this.manager().fps();
        this._fpsRate = rate;
        return this;
    };
    /**
     * @returns {Boolean}
     */
    ready() {
        return this.frameLoop() !== null;
    }
    /**
     * @returns {KunPicture}
     */
    scene() {
        return this._scene;
    };
    /**
     * @returns {String}
     */
    picture() {
        return this.scene() && this.scene().name() || '';
    };
    /**
     * @param {String} picture 
     * @returns {Boolean}
     */
    replaceBy(picture = '') {
        const manager = this.manager();
        if (manager.has(picture)) {
            this._scene = manager.scene(picture);
            this.play(this.first().name());
            return true;
        }
        return false;
    }
    /**
     * 
     * @param {Number} loop
     * @returns {KunAnimation}
     */
    sound(loop = 0) {
        const list = this.frameset().sounds();
        if (this.canPlayFx(loop) && list.length) {
            const sound = list[Math.floor(Math.random() * list.length)];
            KunScenes.playSound(this.scene().soundProfile(sound));
        }
        return this;
    };
    /**
     * @param {String} filter
     * @return {KunFrameSet[]}
     */
    animations(filter = '') {
        return this.ready() ? filter && this.scene().framesets().filter(fs => fs.name() === filter) || this.scene().framesets() : [];
    }
    /**
     * @returns {KunFrameSet}
     */
    first() {
        return this.animations()[0] || null;
    };
    /**
     * @returns {Boolean}
     */
    interactive() {
        return this.frameset() && this.frameset().interactive();
    };
    /**
     * @param {String} name 
     * @param {Boolean} random
     * @returns {KunFrameSet}
     */
    get(name = '', random = false) {
        const list = this.animations(name);
        return list.length ? random && list[Math.floor(Math.random() * list.length)] || list[0] : null;
    };
    /**
     * @param {String[]} animation
     * @returns {KunAnimation}
     */
    select(list = []) {
        const animations = list.length ? this.animations().filter(a => list.includes(a.name()) && a.unlocked()).map(a => a.name()) : [];
        const selected = animations.length ? animations[Math.floor(Math.random() * animations.length)] : '';
        if (selected) {
            this.play(selected);
        }
        return this;
    };
    /**
     * @returns {KunFrameSet}
     */
    frameset() {
        return this.frameLoop().base();
        //return this._frameset || null;
    };
    /**
     * 
     * @returns {KunScenes.Behavior|String}
     */
    behavior() {
        return this.frameset().behavior() || KunScenes.Behavior.Forward;
    }
    /**
     * @param {Number} loop 
     * @returns {Boolean}
     */
    canPlayFx(loop = 0) {
        const soundLoop = this.scene().soundLoop() || 0;
        return loop && soundLoop && loop % soundLoop === 0 || false;
    };
    /** 
     * @returns {Number}
     */
    count() {
        return this.frameset().count() || 0;
    }
    /**
     * @param {Number} amount 
     * @returns {Number}
     */
    variant(amount) {
        if (this._variant) {
            const value = amount * this._variant / 100;
            return amount + Math.floor(Math.random() * value - Math.random() * value);
        }
        return amount;
    };
    /**
     * @param {Number} variant 
     * @returns {KunAnimation}
     */
    setVariant(variant = 0) {
        this._variant = variant;
        return this;
    };
    /**
     * @returns {KunAnimation}
     */
    update() {
        if (this.playing() && this.frameLoop().update()) {
            if (this.frameLoop().done()) {
                //new framestate approach
                const next = this.next();
                return this.select(next);
            }
            this.sound(this.frameLoop().current());
        }
        return this;
    };
}

/**
 * @type {KunAnimation.Mode|String}
 */
KunAnimation.Mode = {
    Static: 'static',
    Touch: 'touch',
    PlayBack: 'playback',
};

/**
 * @class {KunFrameAnimation}
 */
class KunFrameAnimation {
    /**
     * @param {KunFrameSet} frameset
     */
    constructor(frameset = null) {
        this._base = frameset instanceof KunFrameSet && frameset || null;
        this._index = 0;
        this._loop = 0;
        this._elapsed = 0;
        this._fps = this.base().fps();

        //allow overrides on subclasses
        this.reset();
    }
    /**
     * @returns {KunFrameSet}
     */
    base() {
        return this._base;
    }
    /**
     * @returns {String}
     */
    name() {
        return this.base().name();

    }
    /**
     * @returns {Number}
     */
    fps() {
        return this._fps;
    }
    /**
     * @param {Number} fps 
     * @returns {KunFrameAnimation}
     */
    setFps(fps = 0) {
        this._fps = fps || this.base().fps();
        return this;
    }
    /**
     * @returns {Boolean}
     */
    tick() {
        this._elapsed = ++this._elapsed % this.fps();
        return this._elapsed === 0;
    };
    /**
     * @returns {Number}
     */
    index() {
        return this._index;
    }
    /**
     * @returns {Number}
     */
    frame() {
        return this.frames()[this.index() % this.count()];
    }
    /**
     * @returns {Number}
     */
    current() {
        return this._loop;
    }
    /**
     * @returns {Boolean}
     */
    infinite() {
        return this.base().loops() === 0;
    }
    /**
     * @returns {Boolean}
     */
    next() {
        if (this.current() < this.base().loops()) {
            this._loop++;
            return this.done();
        }
        return false;
    }
    /**
     * @returns {Number}
     */
    last() {
        return this.count() - 1;
    }
    /**
     * @returns {Number}
     */
    count() {
        return this.base().count();
    }
    /**
     * @returns {Number[]}
     */
    frames() {
        return this.base().frames();
    }
    /**
     * 
     * @returns {Boolean}
     */
    done() {
        return !this.infinite() && this.current() >= this.base().loops();
    }
    /**
     * @returns {Boolean}
     */
    update() {
        //make it all static for default
        if (this.tick()) {
            if (this.done()) {
                //set autocomplete when round finishes
                this.reset();
            }
            return true;
        }
        return false;
    }
    /**
     * 
     */
    reset() {
        this._index = 0;
        this._elapsed = 0;
        //this._loop = this.base().loops();
        this._loop = 0;
    }
}
/**
 * @class {KunFrameBack}
 */
class KunFrameForward extends KunFrameAnimation {
    /**
     * @param {KunFrameSet} frameset 
     */
    constructor(frameset) {
        super(frameset);
    }
    /**
     * @returns {Boolean}
     */
    update() {
        if (super.update()) {
            //check this conditiojn first, then update index, also run when index points to last frame.
            this._index = ++this._index % this.count();

            if (this.index() === 0) {
                //new round, update loop
                this.next();
            }

            return true;
        }
        return false;
    }
}
/**
 * @class {KunFrameBack}
 */
class KunFrameBack extends KunFrameAnimation {
    /**
     * @param {KunFrameSet} frameset 
     */
    constructor(frameset) {
        super(frameset);
    }
    /**
     * @returns {Boolean}
     */
    update() {
        if (super.update()) {
            if (this.index()) {
                this._index--;
            }
            else {
                this._index = this.count() - 1;
                this.next();
            }
            return true;
        }
        return false;
    }
    /**
     * @returns {KunFrameBack}
     */
    reset() {
        super.reset();
        this._index = this.count() - 1;
        return this;
    }
}
/**
 * @class {KunFramePingPong}
 */
class KunFramePingPong extends KunFrameAnimation {
    /**
     * @param {KunFrameSet} frameset 
     */
    constructor(frameset) {
        super(frameset);
        this._backwards = false;
    }
    /**
     * @returns {Boolean}
     */
    backwards() {
        return this._backwards;
    }
    /**
     * @returns {Boolean}
     */
    update() {
        if (super.update()) {
            if (this.backwards()) {
                //reverse
                this._index = Math.max(this.index() - 1, 0);
                if (!this.index()) {
                    this._backwards = false;
                    //setup for next round
                    this.next()
                }
            }
            else {
                if (++this._index >= this.count() - 1) {
                    this._backwards = true;
                }
            }
            return true;
        }
        return false;
    }
    /**
     * @returns {KunFramePingPong}
     */
    reset() {
        super.reset();
        this._backwards = false;
        return this;
    }
}

/**
 * 
 * @param {String} name 
 * @param {Number} x1 
 * @param {Number} y1 
 * @param {Number} x2 
 * @param {Number} y2 
 * @param {String} trigger
 * @param {String} next
 * @param {String} sfx
 */
class KunHotSpot {
    constructor(name = '', x1 = 0, y1 = 0, x2 = 0, y2 = 0, trigger = '', next = [], sfx = '') {
        this._name = name || KunHotSpot.name;

        this._left = x1 > x2 && x2 || x1;
        this._top = y1 > y2 && y2 || y1;
        this._right = x2 > x1 && x2 || x1;
        this._bottom = y2 > y1 && y2 || y1;

        this._trigger = trigger || KunHotSpot.Trigger.Instant;
        this._sfx = sfx || '';
        this._next = Array.isArray(next) && next || [];

        this._tags = [
            //Tags
        ];
        this._conditions = [
            //KunCondions
        ];
        this._actions = [
            //KunActions
        ];
    }
    /**
     * @returns {KunScenes}
     */
    manager() {
        return KunScenes.manager();
    }
    /**
     * @returns {String}
     */
    toString() {
        return this.name();
    }
    /**
     * @returns {String}
     */
    name() {
        return this._name;
    };

    /**
     * @returns {Number}
     */
    left() {
        return this._left;
    }
    /**
     * @returns {Number}
     */
    right() {
        return this._right
    }
    /**
     * @returns {Number}
     */
    top() {
        return this._top;
    }
    /**
     * @returns {Number}
     */
    bottom() {
        return this._bottom;
    }
    /**
     * @param {Boolean}
     * @returns {Number}
     */
    x(random = false) {
        return random ? this.left() + Math.floor(Math.random() * this.width()) : this.left();
    };
    /**
     * @param {Boolean}
     * @returns {Number}
     */
    y(random = false) {
        return random ? this.top() + Math.floor(Math.random() * this.height()) : this.top();
    };
    /**
     * @returns {Number}
     */
    midx() {
        return this.x() + this.width() / 2;
    }
    /**
     * @returns {Number}
     */
    midy() {
        return this.y() + this.height() / 2;
    }
    /**
     * @returns {Number}
     */
    width() {
        return this.right() - this.left();
    }
    /**
     * @returns {Number}
     */
    height() {
        return this.bottom() - this.top();
    }

    /**
     * @returns {String[]}
     */
    next() {
        return this._next;
    };
    /**
     * @returns Number
     */
    amount() {
        return this._amount;
    };
    /**
     * @returns {String}
     */
    trigger() {
        return this._trigger;
    };
    /**
     * @returns {KunHotSpot}
     */
    touchSfx() {
        if (this._sfx.length) {
            KunScenes.playFx(this._sfx);
        }
        else {
            KunScenes.playFx(this.manager().sfx());
        }
        return this;
    }
    setValue(value) {
        if (this._varId > 0) {
            $gameVariables.setValue(this._varId, value);
        }
        return this;
    };
    /**
     * @deprecated Use runActions instead
     * @returns {KunHotSpot}
     */
    update() {
        return this.runActions();
    };
    /**
     * 
     * @param {Number} x 
     * @param {Number} y 
     * @returns {Boolean}
     */
    collide(x = 0, y = 0) {
        return this.left() <= x && this.right() >= x && this.top() <= y && this.bottom() >= y;
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @returns {Boolean}
     */
    canCollide(x = 0, y = 0) {
        return this.unlocked() && this.collide(x, y);
    }
    /**
     * @returns {Number[]}
     */
    area() {
        return [this.left(), this.top(), this.right(), this.bottom()];
    };
    /**
     * 
     * @param {Number} x 
     * @param {Number} y 
     * @returns {KunHotSpot}
     */
    test(x, y) {
        KunScenes.DebugLog(`${this.name()} X(${this.left()} >= ${x} <= ${this.right()}) Y(${this.top()} >= ${y} <= ${this.bottom()})`);
        return this;
    };
    /**
     * @returns {String[]}
     */
    tags() {
        return this._tags;
    }
    /**
     * @param {String} tag 
     * @returns {Boolean}
     */
    hasTag(tag = '') {
        return tag && this.tags().includes(tag);
    }
    /**
     * @param {String} tag 
     * @returns {KunHotSpot}
     */
    tag(tag = '') {
        if (!this.hasTag(tag)) {
            this._tags.push(tag);
        }
        return this;
    }
    /**
     * @param {KunCondition} condition
     * @returns {KunHotSpot}
     */
    addCondition(condition) {
        if (condition instanceof KunCondition) {
            this._conditions.push(condition);
        }
        return this;
    };
    /**
     * @param {Boolean} filter
     * @returns {KunCondition[]}
     */
    conditions(filter = false) {
        return typeof filter === 'boolean' && filter ?
            this._conditions.filter(condition => condition.validate()) :
            this._conditions;
    };
    /**
     * @returns {Boolean}
     */
    unlocked() {
        return this.conditions(true).length === this.conditions().length;
    };
    /**
     * @param {KunAction} action
     * @param {String} tag
     * @returns {KunHotSpot}
     */
    addAction(action, tag = '') {
        if (action instanceof KunAction) {
            this._actions.push(action.tag(tag));
        }
        return this;
    };
    /**
     * @param {String} tag
     * @returns {KunAction[]}
     */
    actions(tag = '') {
        return tag ? this._actions.filter(action => action.is(tag)) : this._actions;
    };
    /**
     * @param {String} tag
     * @returns {KunHotSpot}
     */
    runActions(tag = '') {
        this.actions(tag).forEach(action => action.update());
        return this;
    };

}

/**
 * @type {KunHotSpot.Trigger|String}
 */
KunHotSpot.Trigger = {
    Instant: 'instant',
    Queue: 'queue',
    Ignore: 'ignore',
    Frame: 'frame',
    NextFrame: 'next',
};


/**
 * Save targets in the KunTouch list of touched spots
 * @class {KunTarget}
 */
class KunTarget {
    constructor(spot = null, picture = '', x = 0, y = 0, pictureID = 0) {
        this._spot = spot instanceof KunHotSpot ? spot : null;
        this._picture = picture || '';
        this._pictureId = pictureID || 0;
        this._x = x || 0;
        this._y = y || 0;
    }
    /**
     * @returns {KunScenes}
     */
    manager() {
        return KunScenes.manager();
    }
    /**
     * @returns {KunPlayList}
     */
    playlist() {
        return this.manager().playlist();
    }
    /**
     * Will retrieve all targets tagged with the providen tags
     * @param {String[]} tags 
     * @returns {Boolean}
     */
    tagged(tags = []) {
        return tags.length === 0 || this.spot().tags().filter(tag => tags.includes(tag)).length > 0;
    }
    /**
     * Will retrieve all targets NOT tagged with the providen tags
     * @param {String[]} tags 
     * @returns {Boolean}
     */
    untagged(tags = []) {
        return this.spot().tags().filter(tag => tags.includes(tag)).length === 0;
    }
    /**
     * @returns {String}
     */
    toString() {
        return this.picture() + '.' + this.spot().toString();
    };
    /**
     * @returns {String}
     */
    name() {
        return this.spot().name();
    }
    /**
     * @returns {String}
     */
    picture() {
        return this._picture;
    };
    /**
     * @returns {KunAnimation}
     */
    animation() {
        return this.playlist().get(this.picture());
    };
    /**
     * @returns {KunHotSpot}
     */
    spot() {
        return this._spot;
    };
    /**
     * @returns {String[]}
     */
    tags(){
        return this.spot().tags();
    }    
    /**
     * @returns {Number}
     */
    x() {
        return this._x;
    };
    /**
     * @returns {Number}
     */
    y() {
        return this._y;
    };
    /**
     * @returns {Number}
     */
    ID() {
        return this._pictureId;
    };
    /**
     * @returns {KunTarget}
     */
    position() {
        this.manager().setPosition(this.x(), this.y());
        return this;
    };
    /**
     * @returns {KunTarget}
     */
    execute() {
        if (this.valid()) {
            var animation = this.animation();
            if (animation && animation.ready()) {
                //export X and Y positions, then run actions
                this.position().spot().runActions();
                //jump to next frameset (if any)
                animation.select(this.spot().next());
            }
        }
        return this;
    };
    /**
     * @returns {Boolean}
     */
    valid() {
        return this.spot() && this.picture() && this.manager().has(this.picture());
    };
}


/**
 * @class {KunCondition}
 * @type {KunCondition}
 */
class KunCondition {
    /**
     * 
     * @param {Number} variable 
     * @param {String} operation 
     * @param {Number} value 
     * @param {Boolean} valueAsVar 
     * @param {Number[]} on 
     * @param {Number[]} off 
     */
    constructor(variable, operation, value = 0, valueAsVar = false, on = [], off = []) {
        this._variable = typeof variable === 'number' && variable > 0 ? variable : 0;
        this._operator = typeof operation === 'string' && operation.length > 0 ? operation : KunCondition.Operator().Equal;
        this._value = typeof value === 'number' && value > 0 ? value : 0;
        //define if value targets a game Variable
        this._targetVar = valueAsVar || false;
        //required switches ON and OFF
        this._switchOn = Array.isArray(on) ? on : [];
        this._switchOff = Array.isArray(off) ? off : [];
    }
    /**
     * @returns {Number}
     */
    targetVar() {
        return this._targetVar && this._value > 0;
    }
    /**
     * @returns {Number}
     */
    value() {
        return this.targetVar() ? $gameVariables.value(this._value) : this._value;
    }
    /**
     * @param {Boolean} getValue 
     * @returns {Number}
     */
    variable(getValue = false) {
        return getValue && $gameVariables.value(this._variable) || this._variable;
    }
    /**
     * @returns {String}
     */
    operator() {
        return this._operator;
    }
    /**
     * @param {Boolean} listValues 
     * @returns {Number[],Boolean[]}
     */
    on(listValues = false) {
        return listValues ? this._switchOn.map(sw => $gameSwitches.value(sw)) : this._switchOn;
    }
    /**
     * @param {Boolean} listValues 
     * @returns {Number[],Boolean[]}
     */
    off(listValues = false) {
        return listValues ? this._switchOff.map(sw => $gameSwitches.value(sw)) : this._switchOff;
    }
    /**
     * @returns {Boolean}
     */
    validate() {
        if (this.variable() > 0) {
            //validate variable
            switch (this.operator()) {
                case KunCondition.Operator.Greater:
                    return this.variable(true) > this.value();
                case KunCondition.Operator.GreaterOrEqual:
                    return this.variable(true) >= this.value();
                case KunCondition.Operator.Equal:
                    return this.variable(true) === this.value();
                case KunCondition.Operator.LessOrEqual:
                    return this.variable(true) <= this.value();
                case KunCondition.Operator.Less:
                    return this.variable(true) < this.value();
            };
        }
        if (this.on(true).filter(val => !val).length > 0) {
            //count all switched OFF required switches
            return false;
        }
        if (this.off(true).filter(val => val).length > 0) {
            //count all switched ON required switches
            return false;
        }
        return true;
    }
}
/**
 * @type {KunCondition.Operator|String}
 */
KunCondition.Operator = {
    Greater: 'greater',
    GreaterOrEqual: 'greater_equal',
    Equal: 'equal',
    LessOrEqual: 'less_equal',
    Less: 'less',
};

/**
 * Run some variable updates
 * @class {KunAction}
 * @type {KunAction}
 */
class KunAction {
    /**
     * @param {Number} variable 
     * @param {String} operation 
     * @param {Number} value 
     */
    constructor(variable, operation = KunAction.Operator.Add, value = 0) {
        this._variable = variable || 0;
        this._operation = operation && operation || KunAction.Operator.Add;
        this._value = value || 0;
        this._tag = [];
    }
    /**
     * @returns {String}
     */
    operation() {
        return this._operation;
    }
    /**
     * @param {Boolean} asValue 
     * @returns {Number}
     */
    variable(asValue = false) {
        return asValue ? $gameVariables.value(this._variable) : this._variable;
    }
    /**
     * @returns {Number}
     */
    value() {
        return this._value;
    }
    /**
     * @param {Number} value 
     * @returns {KunAction}
     */
    set(value = 0) {
        if (this.variable() > 0) {
            $gameVariables.setValue(this.variable(), value);
        }
        return this;
    }
    /**
     * @returns {KunAction}
     */
    update() {
        const amount = this.value();
        const current = this.variable(true);
        if (amount > 0) {
            switch (this.operation()) {
                case KunAction.Operator.Increase: //backwards compatibility
                case KunAction.Operator.Add:
                    this.set(current + amount);
                    break;
                case KunAction.Operator.Sub:
                    this.set(current - amount > 0 ? current - amount : 0);
                    break;
                case KunAction.Operator.Set:
                    this.set(amount);
                    break;
            }
        }
        return this;
    }
    /**
     * @param {String} tag 
     * @returns {Boolean}
     */
    is(tag = '') {
        return (tag.length + this.tags().length === 0) || this.tags().includes(tag);
    }
    /**
     * @param {String} tag 
     * @returns {KunAction}
     */
    tag(tag = '') {
        this._tag = tag.length ? tag.split(' ') : [];
        return this;
    }
    /**
     * @returns {String[]}
     */
    tags() {
        return this._tag;
    }
}
/**
 * @type {KunAction.Operator|String}
 */
KunAction.Operator = {
    Increase: 'increase', //backwards compatibility
    Add: 'add',
    Sub: 'sub',
    Set: 'set',
};


/**
 * 
 */
function KunAnimations_RegisterManagers() {

    var _kunAnimations_Initialize_Sprite = Sprite_Picture.prototype.initialize;
    Sprite_Picture.prototype.initialize = function (pictureId) {
        _kunAnimations_Initialize_Sprite.call(this, pictureId);
        this._touching = false;
        this._canceled = false;
        this._scroll = 0;
        this._animation = null;
    };

    /**
     * @returns {KunScenes}
     */
    Sprite_Picture.prototype.sceneManager = function () {
        return KunScenes.manager();
    }
    /**
     * @returns {KunTargets}
     */
    Sprite_Picture.prototype.touchSpots = function () {
        return this.sceneManager().targets();
    }
    /**
     * @returns {KunPlayList}
     */
    Sprite_Picture.prototype.playlist = function () {
        return this.sceneManager().playlist();
    }

    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.canTouch = function () {
        return this.sceneManager().canTouch();
    }

    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.canCapture = function () {
        //return KunScenes.canCapture()
        return this.sceneManager().canCapture();
    }
    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.canWheel = function () {
        return this.sceneManager().canWheel() && ++this._scroll % 2 === 0;
    };
    /**
     * @returns {Sprite_Picture}
     */
    Sprite_Picture.prototype.processWheel = function () {
        if (this.canWheel()) {
            this.sceneManager().scroll(TouchInput.wheelY);
        }
        return this;
    };

    /**
     * Sprite_Picture.loadBitmap WON'T BE CALLED if the picture ID already points to the SAME SOURCE!!
     */
    var _KunAnimations_SpritePicture_LoadBitmap = Sprite_Picture.prototype.loadBitmap;
    Sprite_Picture.prototype.loadBitmap = function () {
        //vanilla image preload
        _KunAnimations_SpritePicture_LoadBitmap.call(this);
        //setup animation if its a scene spritesheet
        //this._animation = this.playlist().requestAnimation(this._pictureName, this._pictureId);
        this._animation = this.playlist().setup(this._pictureName, this._pictureId);
        if (this.isAnimated()) {
            this.animation().play(); //initialize and play
            this.bitmap.addLoadListener(this.updateAnimation.bind(this));
        }
    };

    var _kunAnimations_Update_Sprite = Sprite_Picture.prototype.update;
    Sprite_Picture.prototype.update = function () {
        //call vanilla
        _kunAnimations_Update_Sprite.call(this);

        if (this.isAnimated()) {
            //update the scene manager
            this.updateAnimation().processTouch();
            //this.processWheel();
        }
    };
    /**
     * @returns {Sprite_Picture}
     */
    Sprite_Picture.prototype.updateAnimation = function () {
        return this.updateAnimationFrame(this.animation());
    };
    /**
     * @param {KunAnimation} animation
     * @returns {Sprite_Picture}
     */
    Sprite_Picture.prototype.updateAnimationFrame = function (animation = null) {
        //const animation = this.animation();
        if (animation && animation.update()) {
            if (this.bitmap) {
                const frameIndex = animation.frame();
                const w = this.bitmap.width / animation.cols();
                const h = this.bitmap.height / animation.rows();
                const x = frameIndex % animation.cols() * w;
                const y = Math.floor(frameIndex / animation.cols()) * h;
                this.setFrame(x, y, w, h);
                //return true;                    
            }
        }
        return this;
    };
    /**
     * @returns {KunAnimation}
     */
    Sprite_Picture.prototype.animation = function () {
        return this._animation || null;
    };
    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.isAnimated = function () {
        return this.animation() !== null;
        //return KunScenes.has(this._pictureName);
    }
    /**
     * @param {Number} x 
     * @returns Number
     */
    Sprite_Picture.prototype.offsetX = function (x) {
        return this.picture().scaleX() > 0 ? Math.floor((x - this.picture().x()) * 100 / this.picture().scaleX()) : 0;
    };
    /**
     * @param {Number} y 
     * @returns Number
     */
    Sprite_Picture.prototype.offsetY = function (y) {
        return this.picture().scaleY() > 0 ? Math.floor((y - this.picture().y()) * 100 / this.picture().scaleY()) : 0;
    };
    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.validScale = function () {
        return this.picture() && this.picture().scaleX() && this.picture().scaleY() > 0;
    }
    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.touch = function () {
        if (this.canTouch() && this.validScale()) {
            var x = TouchInput._x;
            var y = TouchInput._y;
            const spot = this.animation().touch(this.offsetX(x), this.offsetY(y));

            if (spot) {
                this.animation().target(spot, x, y, true);
                //, X, Y, this._pictureId);    
            }
            return true;
        }
        return false;
    };
    /**
     * @param {Boolean}
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.capture = function (to = false) {
        if (this.canCapture()) {
            if (to) {
                this.animation().captureTo(this.offsetX(TouchInput._x), this.offsetY(TouchInput._y));
            }
            else {
                this.animation().captureFrom(this.offsetX(TouchInput._x), this.offsetY(TouchInput._y));
            }
            return true;
        }
        return false;
    };
    /**
     * @returns {Boolean}
     */
    Sprite_Picture.prototype.processTouch = function () {
        if (this.isAnimated() && this.canTouch()) {
            if (TouchInput.isCancelled()) {
                if (!this._canceled) {
                    this._canceled = true;
                    this._touching = false;
                    //drop spots here
                    //KunScenes.dropSpot();
                    //New Version
                    this.touchSpots().drop();
                    return this._touching;
                }
            }
            if (this._canceled) {
                this._canceled = false;
            }
            if (TouchInput.isTriggered()) {
                if (!this._touching) {
                    this._touching = true;
                }
            }
            if (TouchInput.isReleased()) {
                if (this._canceled) {
                    this._canceled = false;
                }
                if (this._touching) {
                    this._touching = false;
                    this.touch();
                }
            }
        }
        return this._touching;
    };


    //OVERRIDE Game_Picture move method to capture the picture offset when required
    var _kunAnimations_GamePicture_Move = Game_Picture.prototype.move;
    Game_Picture.prototype.move = function (origin, x, y, scaleX, scaleY, opacity, blendMode, duration) {

        //capture X and Y offset from picture name
        if (this.name()) {
            //import offset from currently active picture's frameset controller plus the scale
            var offset = this.playlist().offset(this.name());
            //then apply the transformations
            x -= Math.floor(offset.x * (scaleX / 100));
            y -= Math.floor(offset.y * (scaleY / 100));
        }

        _kunAnimations_GamePicture_Move.call(this, origin, x, y, scaleX, scaleY, opacity, blendMode, duration);
    };
    /**
     * @returns {KunPlayList}
     */
    Game_Picture.prototype.playlist = function () {
        return KunScenes.manager().playlist();
    }
}
/**
 * 
 */
function KunAnimations_SetupCommands() {

    var _KunAnimations_SetupCommands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunAnimations_SetupCommands.call(this, command, args);
        if (command === 'KunAnimations') {
            const cmdManager = new KunSceneCommands(this, args);
            cmdManager.run();
        }
    };
}
/**
 * @class {KunSceneCommands}
 */
class KunSceneCommands {
    /**
     * @param {Game_Interpreter}
     * @param {String[]} input 
     */
    constructor(interpreter = null, input = []) {
        this._interpreter = interpreter instanceof Game_Interpreter && interpreter || null;
        this._args = input;

        this.initialize();
    }
    initialize() {
        //capture manager
        this._manager = KunScenes.manager();
    }
    /**
     * @returns {String}
     */
    toString() {
        return this.arguments().join(' ');
    }
    /**
     * @returns {KunScenes}
     */
    manager() {
        return this._manager;
    }
    /**
     * @returns {KunPlayList}
     */
    playlist() {
        return this.manager().playlist();
    }
    /**
     * @returns {KunTargets}
     */
    targets() {
        return this.manager().targets();
    }
    /**
     * @returns {Game_Interpreter}
     */
    interpreter() {
        return this._interpreter;
    }
    /**
     * @returns {Boolean}
     */
    import() {
        return this.arguments().includes('import');
    }
    /**
     * @returns {Number}
     */
    wait(fps = 10) {
        this.interpreter().wait(fps);
    }
    /**
     * 
     */
    waitMessage() {
        this.interpreter().setWaitMode('message');
    }
    /**
     * @returns {String[]}
     */
    arguments() {
        return this._args;
    }
    /**
     * @returns {Number}
     */
    count() {
        return this.arguments().length;
    }
    /**
     * @returns {String}
     */
    command() {
        return this._args[0] || '';
    }
    /**
     * @returns {Boolean}
     */
    run() {
        if (this.interpreter()) {
            const command = this.command() && `${this.command()}Command` || '';
            const manager = this.manager();
            if (command && typeof this[command] === 'function') {
                if (manager.debug() > KunScenes.DebugLevel.Enabled) {
                    KunScenes.DebugLog(`Running Command: ${this.toString()}`);
                }
                this[command](this.count() > 1 && this.arguments().slice(1) || []);
                return true;
            }
        }
        return false;
    }
    /**
     * @param {String[]} args 
     */
    testCommand(args = []) {
        KunScenes.DebugLog(`Test Command: "${args.join()}"`);
    }
    /**
     * @param {String[]} args 
     */
    speedCommand(args = []) {
        return this.variantCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    variantCommand(args = []) {
        if (args.length > 1) {
            const values = args[1].split(':').map(value => parseInt(value));
            const playlist = this.playlist();
            if (args.includes('import')) {
                values = values.map(value => $gameVariables.value(value));
            }
            args[1].split(':')
                .map(name => playlist.get(name))
                .forEach(anim => anim && anim.setVariant(values[Math.floor(Math.random() * values.length)]));
        }
    }
    /**
     * @param {String[]} args 
     */
    stagemenuCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            const collection = args[0].split(':');
            const animation = collection[Math.floor(Math.random() * collection.length)];
            this.createMenu(
                playlist.get(animation),
                ['stage', args[1] || 'skip', args[2] || 'right', args[3] || 'window']
            );
        }
    }
    /**
     * @param {String[]} args 
     */
    spotmenuCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            const collection = args[0].split(':');
            const animation = collection[Math.floor(Math.random() * collection.length)];
            this.createMenu(
                playlist.get(animation),
                [args.includes('touch') && 'touch' || 'target', args[1] || 'skip', args[2] || 'right', args[3] || 'window']
            );
        }
    }
    /**
     * @param {String[]} args 
     */
    animationmenuCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            const collection = args[0].split(':');
            const animation = collection[Math.floor(Math.random() * collection.length)];
            this.createMenu(
                playlist.get(animation),
                ['animation', args[1] || 'skip', args[2] || 'right', args[3] || 'window']
            );
        }
    }
    /**
     * @param {String[]} args 
     */
    actionsCommand(args = []) {
        if (args.length) {
            const animation = this.playlist().get(args[0]);
            if (animation) {
                animation.runActions(args.length > 1 && args[1] || '');
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    packCommand(args = []) {
        this.loadCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    loadCommand(args = []) {
        if (args.length > 1) {
            const manager = this.manager();
            const profiles = args[0].split(':');
            const setup = args[1].split(':').map(att => parseInt(att));
            const alias = args.length > 2 ? args[2] : '';
            const animation = manager.loadGroup(
                profiles[Math.floor(Math.random() * profiles.length)],
                setup[0], true, alias
            );
            if (animation) {
                this.playlist().add(animation);
                manager.preparePicture(animation.picture(), ...setup);
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    createCommand(args = []) {
        if (args.length) {
            const pictures = args[0].split(':');
            const setup = args[1].split(':').map(n => parseInt(n));
            const alias = args[2] || '';
            const animation = args[3] && args[3].split(':') || [];
            const picture = pictures[pictures.length > 1 ? Math.floor(Math.random() * pictures.length) : 0];
            this.playlist().setup(
                picture, setup[0], alias,
                animation.length ? animation[Math.floor(Math.random() * animation.length)] : '');
            this.manager().preparePicture(picture, ...setup);
        }
    }
    /**
     * @param {String[]} args 
     */
    playlistCommand(args = []) {
        const playlist = this.playlist();
        if (args.length > 1) {
            const list = args[1].split(':');
            const clear = list.includes('clear');
            args[0].split(':').forEach(name => {
                const animation = playlist.get(name);
                if (animation) {
                    if (clear) {
                        animation.clear();
                    }
                    else {
                        animation.push(name, list);
                    }
                }
            });
        }
        else if (args.includes('clear')) {
            playlist.animations().forEach(animation => animation.clear());
        }
    }
    /**
     * @param {String[]} args 
     */
    spotCommand(args = []) {
        if (args.length) {
            const animations = args[0].split(':');
            const animation = animations[Math.floor(Math.random() * animations.length)];
            const spots = args.length > 1 && !args[1].includes('import') && args[1].split(':') || [];
            const count = args.length > 2 && args[1] === 'import' && $gameVariables.value(parseInt(args[2])) || 1;
            if (count) {
                for (var i = 0; i < count; i++) {
                    this.playlist().capture(
                        animation,
                        spots.length && spots[Math.floor(Math.random() * spots.length)] || '',
                        true);
                }
                KunScenes.playFx(this.manager().sfx());
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    queueCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            const spots = args.length > 1 && args[1].split(':') || [''];
            const touch = args.length > 2 && args[2] === 'touch';
            spots.forEach(spot => playlist.capture(args[0], spot, touch));
        }
    }
    /**
     * @param {String[]} args 
     */
    targetCommand(args = []) {
        const manager = this.manager();
        const targetGauge = this.targets();

        if (args.length) {
            //capture all tags within the scope to include/exclude in the filter
            const scope = args[0].split(':');
            //catch the animation tags to match with the current target spot, to play the allowed tagged animations
            const matchtags = args[1] && args[1].split(':') || [];
            //define an escape X,Y position if required, when there's no  match
            const escapePos = args[2] && args[2].split(':').map(n => parseInt(n)) || [];
            switch (scope.shift()) {
                case 'include':
                    var target = targetGauge.include(scope,true);
                    manager.touchMode(target && true || false);
                    this.targetEffect(target,matchtags,escapePos);
                    break;
                case 'exclude':
                    var target = targetGauge.exclude(scope,true);
                    manager.touchMode(target && true || false);
                    this.targetEffect(target,matchtags,escapePos);
                    break;
                case 'random':
                    var target = targetGauge.target(true);
                    manager.touchMode(target && true || false);
                    this.targetEffect(target,matchtags,escapePos);
                    break;
            }
        }
        else {
            manager.touchMode(
                targetGauge.target(args.includes('random')) && true || false
            );
        }
    }
    /**
     * @param {KunTarget} target 
     * @param {String[]} tagged 
     * @param {Number[]} position 
     */
    targetEffect( target = null , tagged = [] , position = [] ) {
        if( target instanceof KunTarget ){
            if (target && tagged.length) {
                tagged.forEach(animation => this.playlist().tag(animation, target.tags()));
            }
            else if(position.length) {
                this.manager().setPosition(position[0], position[1] || position[0]);
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    aliasCommand(args = []) {
        if (args.length > 1) {
            const playlist = this.playlist();
            //do not allow reset alias on teh same animation if already playing
            const animation = playlist.get(args[1]) || playlist.setup(args[1], 0, args[0]);
            const id = args[2] && parseInt(args[2]) || 0;
            //filter by picture ID
            if (animation && (id === 0 || animation.ID() === id)) {
                if (animation.alias() !== args[1]) {
                    this.playlist().animations(true)
                        .filter(anim => anim.alias() === args[1])
                        .forEach(anim => anim.setAlias());
                    animation.setAlias(args[1]);
                }
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    stageCommand(args = []) {
        if (args.length > 1) {
            //remove dash from stage names, replace by underscore
            const stages = args[1].split(':').map(stage => stage.replace(/-/g, '_'));
            this.playlist().setstage(args[0], stages[Math.floor(Math.random() * stages.length)]);
        }
    }
    /**
     * @param {String[]} args 
     */
    prepareCommand(args = []) {
        this.targets().clear();
    }
    /**
     * @param {String[]} args 
     */
    completeCommand(args = []) {
        //clear all referenecs before starting scene
        this.playlist().clear();
        this.targets().clear();
    }
    /**
     * @param {String[]} args 
     */
    clearCommand(args = []) {
        switch (args[0] || '') {
            case 'playlist':
            case 'scenes':
                this.playlist().clear();
                break;
            case 'all':
                this.playlist().clear();
                this.targets().clear();
                break;
            case 'targets':
            default:
                this.targets().clear();
                break;
        }
    }
    /**
     * @param {String[]} args 
     */
    fpsCommand(args = []) {
        if (args.length > 1) {
            var fps = parseInt(args[1]);
            if (this.import()) {
                fps = $gameVariables.value(fps);
            }
            const animation = this.playlist().get(args[0]);
            if (animation) {
                animation.setFps(fps);
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    playCommand(args = []) {
        if (args.length > 1) {
            const playlist = this.playlist();
            const framesets = args[1].replace(/\./g, ':').split(':');
            const spots = (args.length > 2 && args[2] === 'spot' && args.length > 3 && args[3].split(':')) || [];
            args[0].split(':').map(name => playlist.get(name)).filter(anim => anim !== null).forEach(animation => {
                //play random selection for any animated picture :D
                animation.play(framesets[Math.floor(Math.random() * framesets.length)]);
                if (spots.length) {
                    this.playlist().capture(animation.name(), spots[Math.floor(Math.random() * spots.length)]);
                }
            });
            if (args.length > 2 && args[2] === 'wait') {
                if (args.length > 3) {
                    const wait = args[3].split(':').map(count => parseInt(count));
                    this.wait(wait.length > 1 ? wait[0] + Math.floor(Math.random() * wait[1]) : wait[0]);
                }
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    setCommand(args = []) {
        this.playCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    resetCommand(args = []) {
        if (args.length) {

        }
    }
    /**
     * @param {String[]} args 
     */
    pauseCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            args[0].split(':')
                .filter(animation => playlist.has(animation))
                .map(animation => playlist.get(animation))
                .forEach(animation => animation.stop());
        }
    }
    /**
     * @param {String[]} args 
     */
    resumeCommand(args = []) {
        if (args.length) {
            const playlist = this.playlist();
            args[0].split(':')
                .filter(scene => playlist.has(scene))
                .map(scene => playlist.get(scene))
                .forEach(scene => scene.play());
        }
    }
    /**
     * @param {String[]} args 
     */
    waitCommand(args = []) {
        if (args.length) {
            var wait = args[0].split(':').map(t => parseInt(t));
            if (this.import() && wait > 0) {
                wait[0] = $gameVariables.value(wait[0]);
                if (wait.length > 1) {
                    wait[1] = $gameVariables.value(wait[1]);
                }
            }
            this.wait(wait.length > 1 ? wait[0] + Math.floor(Math.random() * wait[1]) : wait[0]);
            //KunScenes.DebugLog(`Waiting ${wait[0]} +(${wait.length > 1 ? wait[1] : 0}) fps ...`);
        }
    }
    /**
     * animation list: animation:animation:animation
     * state: on|off
     * playback animations: frameset:frameset:frameset
     * @param {String[]} args 
     */
    playbackCommand(args = []) {
        if (args.length) {
            const playback = args.length > 1 && args[1] === 'on';
            const list = args.length > 2 && args[2].split(':') || [];
            args[0].split(':')
                .map(name => this.playlist().get(name))
                .filter(animation => animation !== null)
                .forEach(animation => {
                    if (playback) {
                        list.forEach(fs => animation.push(fs));
                        animation.setMode(KunAnimation.Mode.PlayBack);
                    }
                    else {
                        animation.setMode(KunAnimation.Mode.Disabled);
                        animation.clear();
                    }
                });
        }
    }
    /**
     * @param {String[]} args 
     */
    modeCommand(args = []) {
        this.manager().setMode(args[0] || KunScenes.Mode.Disabled);
    }
    /**
     * @param {String[]} args 
     */
    positionCommand(args = []) {
        if (args.length) {
            const coordinates = args.slice(1);
            const area = coordinates.length > 1 ? coordinates[Math.floor(Math.random() * coordinates.length)] : coordinates[0];
            this.manager().area(...area.split(':').map(n => parseInt(n)));
        }
    }


    /**
     * @param {String} position
     * @returns {Number}
     */
    menuPosition(position = 'left') {
        return ['left', 'middle', 'right'].includes(position) ? positions.indexOf(position) : 2
    }
    /**
     * @param {String} displayMode
     * @returns {Number}
     */
    menuBackground(displayMode = 'window') {
        return ['window', 'dim', 'transparent'].includes(displayMode) ? backgrounds.indexOf(displayMode) : 2
    }
    /**
     * @param {String} cancel 
     * @param {Number} count
     * @returns {Number}
     */
    menuCancelMode(cancel = '', count = 0) {
        switch (cancel) {
            case 'random':
                return Math.floor(Math.random() * count);
            case 'last':
                return count > 0 && count - 1 || 0;
            case 'skip':
                return -2;
            case 'disable':
                return -1;
            case 'first':
            default:
                return 0;
        }
    }
    /**
     * @param {KunAnimation} animation
     * @param {String} type 
     * @param {Number} choice 
     */
    menuCallback(animation = null, type = 'touch', choice = 0) {
    }
    /**
     * 
     * @param {KunAnimation} animation 
     * @param {String[]} setup
     * @returns 
     */
    createMenu(animation = null, setup = []) {
        //console.log(this.interpreter(),animation);
        if (this.interpreter() && animation instanceof KunAnimation) {

            //KunScenes.DebugLog(`Preparing Animation Menu for ${animation.name()}: ${setup.join(', ')}`);

            const action = setup[0] || 'touch';
            const cancelType = setup[1] || 'skip';
            const location = setup[1] || 'right';
            const windowType = setup[1] || 'window';
            //object array {name:label}
            const options = animation.mapMenu(action);
            //setupCustomMenuSelector
            this.showMenu(animation, action, options,
                this.menuCancelMode(cancelType, options.length),
                this.menuBackground(windowType),
                this.menuPosition(location)
            );
        }
    };
    /**
     * 
     * @param {KunAnimation} animation 
     * @param {String} action 
     * @param {Object[]} options 
     * @param {Number} cancel 
     * @param {Number} background 
     * @param {Number} position 
     */
    showMenu(animation = null, action = 'touch', options = [], cancel = 0, background = 2, position = 0) {

        const interpreter = this.interpreter();
        const playlist = this.playlist();

        const values = options.map(option => Object.keys(option)[0]);
        const labels = options.map(option => Object.values(option)[0]);

        if (options.length === 0) {
            return;
        }

        $gameMessage.setChoices(labels, 0, cancel);
        $gameMessage.setChoiceBackground(background);
        $gameMessage.setChoicePositionType(position);
        $gameMessage.setChoiceCallback(function (choice) {
            switch (action) {
                case 'touch':
                case 'capture':
                    animation.capture(values[choice], action === 'touch');
                    break;
                case 'animation':
                    animation.play(values[choice]);
                    break;
                case 'stage':
                    playlist.setstage(animation.name(true), values[choice]);
                    break;
                default:
                    break;
            }
        }.bind(interpreter));
        this.waitMessage();
    }
}


/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunScenes.manager();

    KunAnimations_RegisterManagers();

    KunAnimations_SetupCommands();
})( /* initializer */);



