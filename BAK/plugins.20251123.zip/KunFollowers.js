//=============================================================================
// KunFollowers.js
//=============================================================================
/*:
 * @filename KunFollowers.js
 * @plugindesc Add Randomly generated Hirelings by class and generic NPCs to the party. Handle the party max size in game!
 * @version 1.24
 * @author Kun
 * 
 * @help
 * 
 * Add Guest Actors to the Followers queue.
 * 
 * They won't fight, they can be joined several times (as much as Maximum Guests are allowed).
 * 
 * Define the guests which can be joined in Allowed Followers list.
 * 
 * Set the actor 
 * 
 * COMMANDS
 * 
 *  KunFollower add actor_id [amount]
 *  - Add an actor ID to the guest followers.
 *  - Define how many by number if required.
 * 
 *  KunFollower remove actor_id [all] [game_var]
 *  - Remove an actor from the guest followers
 *  - Remove them all if required. (optional)
 *  - Export removed guests to game_var if defined (optional)
 * 
 *  KunFollower count actor_id game_var
 *  - Export the actor_id guest count into the given GameVariable
 * 
 *  KunFollower max-followers game_var
 *  - Export the the maximum number of followers available
 * 
 *  KunFollower max-guests game_var
 *  - Export the the maximum number of guests available
 * 
 *  KunFollower increase [followers | guests] [amount]
 *  - Increase the number of followers|guests in the party
 *  - Define the amount to increase the party, default to 1
 * 
 *  KunFollower decrease [followers | guests] [amount]
 *  - Decrease the number of followers|guests in the party
 *  - Define the amount to decrease the party, default to 1
 * 
 *  KunFollower add-hireling hireling_id|hireling_name [level] [exportVar]
 *  - Adds a hireling in party if there's enough room available
 *  - Defines/Resets the hireling level if required
 *  - Exports the joined ActorId if requested
 * 
 *  KunFollower count-hirelings countVar [maxVar]
 *  - Exports the number of active hirelings in party
 *  - Exports the max number of allowed hirelings if required
 * 
 *  KunFollower setup-hireling hireling_id|hireling_name actor_id [level]
 *  - Overrides the selected actor_id slot (if defined as hireling slots in this plugin) with the selected hireling template
 * 
 * 
 * FUNCTIONS / CONDITIONS
 * 
 *  kun_follower_add_guest( actor_id , [amount : 1 ] )
 *  - Define the actor ID to add to add as a guest follower.
 *  - Define how many guests of this type are required. Default is 1. (optional)
 *  - Return TRUE if the actor was added successfully.
 * 
 *  kun_follower_remove_guest( actor_id , [remove_all : false] , [game_var] )
 *  - Remove a given guest follower
 *  - Remove all the same type if required (optional)
 *  - Export removed guests to game_var if defined (optional)
 *  - Return TRUE if the actor or actors were removed successfully.
 * 
 *  kun_follower_count( actor_id )
 *  - REturn all actor_id instances in the guests queue
 * 
 * 
 * @param followers
 * @text Maximum Followers
 * @desc How many followers can join the party
 * @type number
 * @min 0
 * @max 10
 * @default 4
 * 
 * @param guests
 * @text Maximum Guests
 * @desc How many guests can follow?
 * @type number
 * @min 0
 * @max 10
 * @default 0
 * 
 * @param templates
 * @text Allowed Guests
 * @parent guests
 * @desc Allow to "guest" these followers only.
 * @type actor[]
 * 
 * @param hirelings
 * @text Hirelings
 * @desc Hirelings are generic companions which can be duplicated from a single hireling template overriding the mapped selected characters.
 * @type struct<Hireling>[]
 * 
 * @param hirelingSlots
 * @parent hirelings
 * @text Hireling Slots
 * @desc Available Hireling Slots (warning, reserve these actors to be oftenly overriden by this plugin)
 * @type Actor[]
 * 
 * @param debug
 * @text Debug Mode
 * @type Boolean
 * @default false
 * 
 * 
 */
/*~struct~Hireling:
 * @param name
 * @text Name
 * @type text
 * @default Hireling
 * 
 * @param level
 * @text Default Level
 * @type number
 * @min 1
 * @max 99
 * @default 1
 * 
 * @param class
 * @text Class
 * @type class
 * @default 0
 * 
 * @param variations
 * @text Variations
 * @detail Define a list of face-character display variations
 * @type struct<Graphics>[]
 * 
 * @param names
 * @text Random Names
 * @type text[]
 * 
 * @param armorSet
 * @text Armor Set
 * @type armor[]
 * 
 * @param weaponSet
 * @text Weapons
 * @type weapon
 * 
 * @param itemSet
 * @text Items
 * @type item[]
 */
/*~struct~Graphics:
 * @param characterSet
 * @text character Set
 * @type file
 * @require 1
 * @dir img/characters/
 * 
 * @param characterId
 * @text Character Set Id
 * @type number
 * @min 0
 * @default 0
 * 
 * @param faceSet
 * @text FaceSet
 * @type file
 * @require 1
 * @dir img/faces/
 * 
 * @param faceId
 * @text Face
 * @type number
 * @default 0
 * 
 * @param svBattler
 * @text SideView Battler
 * @type file
 * @required 1
 * @dir img/sv_actors/
 * 
 */
/**
 * @description KUN Modules
 * @type KUN
 */
var KUN = KUN || {};

function KunFollowers() {
    throw `${this.constructor.name} is a Static Class`;
}

KunFollowers.Initialize = function () {

    var _parameters = this.PluginManager();

    this._debug = _parameters.debug === 'true';
    this._guestSlots = parseInt(_parameters.guests) || 0;
    this._partySlots = parseInt(_parameters.followers) || 0;
    this._guests = [];
    this._hirelings = [];
    this._hirelingTemplates = {};
    this._hirelingNames = [];



    (_parameters.templates.length > 0 ? JSON.parse(_parameters.templates) : []).map(actor_id => parseInt(actor_id)).forEach(function (actor_id) {
        KunFollowers.addGuest(actor_id);
    });

    (_parameters.hirelingSlots.length > 0 ? JSON.parse(_parameters.hirelingSlots) : []).map(actor_id => parseInt(actor_id)).forEach(function (actor_id) {
        KunFollowers.addHirelingSlot(actor_id);
    });

    (_parameters.hirelings.length > 0 ? JSON.parse(_parameters.hirelings) : []).forEach(function (hireling) {
        var _tpl = KunHireling.Import(hireling);
        if (hireling !== null) {
            KunFollowers.addHirelingTemplate(_tpl);
        }
    });

};

/**
 * @returns Boolean
 */
KunFollowers.debug = function () {
    return this._debug;
};
/**
 * @param {Number} actor_id 
 * @returns 
 */
KunFollowers.addGuest = function (actor_id) {
    if (!this._guests.contains(actor_id)) {
        this._guests.push(actor_id);
    }
    return this;
};
/**
 * @param {Number} actor_id 
 * @returns Boolean
 */
KunFollowers.hasGuest = function( actor_id ){
    return this._guests.contains( actor_id );
};
/**
 * @param {Number} actor_id 
 * @returns Boolean
 */
KunFollowers.hasHireling = function( actor_id ){
    return this._hirelings.contains( actor_id );
};
/**
 * @param {Number} actor_id 
 * @returns KunFollowers
 */
KunFollowers.addHirelingSlot = function (actor_id) {
    if (!this._hirelings.contains(actor_id)) {
        this._hirelings.push(actor_id);
    }
    return this;
};
/**
 * @param {KunHireling} hirelingTpl 
 * @returns KunFollowers
 */
KunFollowers.addHirelingTemplate = function (hirelingTpl) {
    if (hirelingTpl instanceof KunHireling) {
        if (!this._hirelingTemplates.hasOwnProperty(hirelingTpl.name())) {
            this._hirelingTemplates[hirelingTpl.name().toLowerCase()] = hirelingTpl;
        }
    }
    return this;
};
/**
 * 
 * @param {Number|String} hireling_id 
 * @param {Number} actor_id 
 * @param {Number} level (optional)
 * @param {Number} variation (optional)
 * @returns Boolean
 */
KunFollowers.updateHireling = function (hireling_id, actor_id, level, variation) {

    var _overriden = false;
    if (typeof hireling_id !== 'string') {
        hireling_id = this.getHirelingName(hireling_id);
    }

    if (hireling_id.length > 0 && this._hirelingTemplates.hasOwnProperty(hireling_id)) {
        var _overriden = this._hirelingTemplates[hireling_id].overrideActor(actor_id, level, variation);
    }

    return _overriden;
};
/**
 * Join a hireling in party
 * @param {String|Number} hireling 
 * @param {Number} level  (optional)
 * @param {Number} variation (optional)
 * @returns Number The joined Hireling actor ID or 0 if failure
 */
KunFollowers.joinHireling = function (hireling, level, variation) {
    var slot = this.availableHirelingSlot();
    var canJoin = $gameParty.maxBattleMembers() > $gameParty.size();
    //console.log( `${slot} , ${canJoin}`);
    if (slot > -1 && canJoin) {
        var actor_id = this._hirelings[slot];
        if (this.updateHireling(hireling, actor_id, level, variation)) {
            $gameParty.addActor(actor_id);
            if (this._debug) {
                console.log(`Hireling Id${actor_id}: ${hireling}(${level || 1}) - Slot: ${slot}  - Available: ${canJoin}`);
            }
            return actor_id;
        }
    }
    return 0;
};
/**
 * Remove the selected hirelings in party by actor_id or actor class
 * @param {Number|String} selection 
 */
KunFollowers.removeHirelings = function (selection) {
    switch (typeof selection) {
        case 'string':
            var _hireling = this.getHireling(selection);
            if (_hireling !== null) {
                this.partyHirelings().forEach(function (actor_id) {
                    if ($gameActors.actor(actor_id).currentClass() === _hireling.class().name) {
                        $gameParty.removeActor(actor_id);
                    }
                });
            }
            break;
        case 'number':
            if (this._hirelings.contains(selection)) {
                $gameParty.removeActor(selection);
            }
            break;
        case 'undefined':
            this.partyHirelings().forEach(function (actor_id) {
                $gameParty.removeActor(actor_id);
            });
            break;
    }
};
/**
 * @param {Number} id 
 * @returns String
 */
KunFollowers.getHirelingName = function (id) {
    var names = Object.keys(this._hirelingTemplates);
    return id < names.length ? names[id] : '';
};
/**
 * @param {Number|String} hireling 
 * @returns KunHireling
 */
KunFollowers.getHireling = function (hireling) {
    if (typeof hireling !== 'string') {
        hireling = this.getHirelingName(hireling);
    }
    return this._hirelingTemplates.hasOwnProperty(hireling) ? this._hirelingTemplates[hireling] : null;
};
/**
 * @param {Boolean} list 
 * @returns Object|KunHireling[]
 */
KunFollowers.hirelings = function (list) {
    return typeof list === 'boolean' && list ? Object.values(this._hirelingTemplates) : this._hirelingTemplates;
};
/**
 * List all active hireling slots within the active gameParty actor list
 * @returns Number[]
 */
KunFollowers.partyHirelings = function(){
    return $gameParty.allMembers().map(actor => actor.actorId()).filter(actor_id => this.hirelings().contains(actor_id));
};
/**
 * @returns Number
 */
KunFollowers.availableHirelingSlot = function () {
    var _party = this.partyHirelings();
    for (var i = 0; i < this._hirelings.length; i++) {
        if (!_party.includes(this._hirelings[i])) {
            return i;
        }
    }
    return -1;
};
/**
 * @returns Number
 */
KunFollowers.countHirelings = function () {
    return this.partyHirelings().length;
}
/**
 * @returns Number
 */
KunFollowers.maxHirelings = function(){
    return this.hirelings().length;
};
/**
 * @param {Number} actor_id 
 * @returns Boolean
 */
KunFollowers.isFollower = function (actor_id) {
    return this.hasGuest( actor_id ) || this.hasHireling(actor_id);
};
/**
 * @returns Array
 */
KunFollowers.guestList = function(){
    return this._guests;
};
/**
 * @returns Number
 */
KunFollowers.maxGuests = function() {
    return this._guestSlots;
};
/**
 * @returns Number
 */
KunFollowers.maxBattleMembers = function(){
    return this._partySlots;
};
/**
 * @returns Number
 */
KunFollowers.maxPartyMembers = function(){
    return this._partySlots;
};
/**
 * @returns Number
 */
KunFollowers.maxMembers = function(){
    return this.maxPartyMembers() + this.maxGuests();
};
/**
 * @param {Number} amount 
 * @return KunFollowers
 */
KunFollowers.addPartySlot = function (amount) {
    this._partySlots += (typeof amount === 'number' && amount > 0 ? amount : 1);
    //$gamePlayer._followers.populate();
    return this;
};
/**
 * @param {Number} amount
 * @return KunFollowers
 */
KunFollowers.addGuestSlot = function (amount) {
    this._guestSlots += (typeof amount === 'number' && amount > 0 ? amount : 1);
    return this;
};
/**
 * @param {Number} amount 
 * @return KunFollowers
 */
KunFollowers.removePartySlot = function (amount) {
    if (this._partySlots > 1) {
        this._partySlots -= (typeof amount === 'number' && amount > 0 ? amount : 1);
    }
    return this;
};
/**
 * @param {Number} amount 
 * @return KunFollowers
 */
KunFollowers.removeGuestSlot = function (amount) {
    if (this._guestSlots > 0) {
        this._guestSlots -= (typeof amount === 'number' && amount > 0 ? amount : 1);
    }
    return this;
};
/**
 * @returns Object
 */
KunFollowers.PluginManager = function () {
    return PluginManager.parameters('KunFollowers');
};
/**
 * Party member types
 */
KunFollowers.Type = {
    'Guest': 'guest',
    'Hireling': 'hireling',
    'Member': 'member'
};

/**
 * 
 * @param {String} name 
 * @param {Number} actorClass 
 * @param {Number} level
 * @param {String} mode
 * @returns 
 */
function KunHireling(name, actorClass, level, mode) {

    this._name = name || 'Hero';
    this._nameList = [];
    this._class = actorClass || 0;
    this._graphics = [];
    this._level = level || 1;
    this._armors = [];
    this._weapons = [];
    this._items = [];
};

/**
 * @param {String} character 
 * @param {Number} character_id 
 * @param {String} face 
 * @param {Number} face_id 
 * @param {String} battler 
 * @returns 
 */
KunHireling.prototype.addGraphics = function (character, character_id, face, face_id, battler) {
    this._graphics.push({
        'character': character,
        'character_id': character_id,
        'face': face,
        'face_id': face_id,
        'battler': battler,
    });
    return this;
};
/**
 * @returns Object
 */
KunHireling.prototype.dump = function () {
    return this;
};
/**
 * @returns String
 */
KunHireling.prototype.name = function () {
    return this._name;
};
/**
 * @returns Object
 */
KunHireling.prototype.class = function () {
    return $dataClasses[this._class];
};
/**
 * @returns Number
 */
KunHireling.prototype.level = function () {
    return this._level;
};
/**
 * @returns Number[]
 */
KunHireling.prototype.armors = function () {
    return this._armors;
};
/**
 * @returns Number[]
 */
KunHireling.prototype.weapons = function () {
    return this._weapons;
};
/**
 * @returns Number[]
 */
KunHireling.prototype.items = function () {
    return this._items;
};
/**
 * @returns Object
 */
KunHireling.prototype.generateGraphics = function (variation) {
    variation = typeof variation === 'number' ? variation : this._graphics[Math.floor(Math.random() * this._graphics.length)];
    return this._graphics.length > 0 ? variation : { 'character': '', 'character_id': 0, 'face': '', 'face_id': 0, 'battler': '' };
};
/**
 * @param {String} name 
 * @returns KunHireling
 */
KunHireling.prototype.addName = function (name) {
    if (!this._nameList.includes(name)) {
        this._nameList.push(name);
    }
    return this;
};
/**
 * @returns String
 */
KunHireling.prototype.generateName = function () {
    return this._nameList.length > 0 ? this._nameList[Math.floor(Math.random() * this._nameList.length)] : this._name;
};
/**
 * @returns String[]
 */
KunHireling.prototype.listNames = function () {
    return this._nameList;
};
/**
 * @param {Number} actor_id 
 * @param {Number} level (optional)
 * @param {Number|Boolean} variation (optional)
 * @returns Boolean
 */
KunHireling.prototype.overrideActor = function (actor_id, level, variation) {
    var _actor = $gameActors.actor(actor_id);
    if (_actor !== null) {
        //reset actor class
        _actor.changeClass(this._class, false);
        //reset actor level
        _actor._level = typeof level === 'number' && level > 0 ? level : this._level;
        //rename
        _actor._name = this.generateName();

        var graphics = this.generateGraphics(variation || false);
        if (graphics.character.length) {
            _actor.setCharacterImage(graphics.character, graphics.character_id);
        }
        if (graphics.face.length) {
            _actor.setFaceImage(graphics.face, graphics.face_id);
        }
        if (graphics.battler.length) {
            _actor.setBattlerImage(graphics.battler);
        }
        if (KunFollowers.debug()) {
            console.log(`Actor ID ${actor_id} overriden by Hireling[${this.name()}] (level:${_actor._level})`);
        }
        return true;
    }
    return false;
};
/**
 * Add an item definition to the template
 * @param {Number} item 
 * @returns 
 */
KunHireling.prototype.addItem = function (item) {
    this._items.push(item);
    return this;
};
/**
 * Add an armor definition to the template
 * @param {Number} armor 
 * @returns 
 */
KunHireling.prototype.addArmor = function (armor) {
    this._armors.push(armor);
    return this;
};
/**
 * Add a weapon definition to the template
 * @param {Number} weapon 
 * @returns 
 */
KunHireling.prototype.addWeapon = function (weapon) {
    this._weapons.push(weapon);
    return this;
};

/**
 * @param {String} data
 * @return KunHireling
 */
KunHireling.Import = function (data) {
    if (typeof data === 'string' && data.length) {
        var hireling = JSON.parse(data);
        var graphics = hireling.variations.length > 0 ? JSON.parse(hireling.variations).map(variation => JSON.parse(variation)) : [];

        var _hireling = new KunHireling(
            hireling.name || 'Hero',
            parseInt(hireling.class || 0),
            parseInt(hireling.level || 0));

        if (hireling.names.length) {
            JSON.parse(hireling.names).forEach(name => _hireling.addName(name));
        }
        if (hireling.armorSet.length > 0) {
            JSON.parse(hireling.armorSet).forEach(armor_id => _hireling.addArmor(parseInt(armor_id)));
        }
        if (hireling.itemSet.length > 0) {
            JSON.parse(hireling.itemSet).forEach(item_id => _hireling.addItem(parseInt(item_id)));
        }
        if (hireling.weaponSet.length > 0) {
            _hireling.addWeapon(parseInt(hireling.weaponSet));
        }

        graphics.forEach(function (g) {
            _hireling.addGraphics(
                g.characterSet,
                g.characterId,
                g.faceSet,
                g.faceId,
                g.svBattler
            );
        });

        return _hireling;
    }
    return null;
};

/**
 * 
 */
KunFollowers_SetupGameParty = function () {
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.isGuest = function(){
        return KunFollowers.hasGuest( this.actorId());
    };
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.isHireling = function(){
        return KunFollowers.hasHireling( this.actorId());
    };

    var _KunFollowers_Game_Party = Game_Party.prototype.initialize;
    Game_Party.prototype.initialize = function() {
        //members available for battle
        this._maxBattleMembers = KunFollowers.maxPartyMembers();
        _KunFollowers_Game_Party.call( this );
    }
    /**
     * @returns Number
     */
    Game_Party.prototype.maxBattleMembers = function () {
        return this._maxBattleMembers || KunFollowers.maxPartyMembers();
    };
    /**
     * @returns Number
     */
    Game_Party.prototype.maxGuests = function () {
        return KunFollowers.maxGuests();
    };
    /**
     * @returns Number
     */
    Game_Party.prototype.maxPartyMembers = function(){
        return this.maxBattleMembers() + this.maxGuests();
    };

    /**
     * @param {Number} actorId 
     * @returns Boolean
     */
    Game_Party.prototype.canJoin = function (actorId) {
        //console.log(KunFollowers.isFollower( actorId ));
        if( this.maxPartyMembers() > this.size() ){
            switch( true ){
                case KunFollowers.isFollower( actorId ) && this.countBattleMembers() < this.maxBattleMembers():
                    return true;
                case KunFollowers.isGuest( actorId ) && this.countGuests() < this.maxGuests():
                    return true;
            }
        }
        return false;
        return this.maxPartyMembers() > this._actors.length && ( KunFollowers.isFollower( actorId ) || !this._actors.contains(actorId) );
    }
    /**
     * 
     * @param {Number} actorId 
     * @returns 
     */
    Game_Party.prototype.addActor = function (actorId) {
        //remove vanilla actor limit
        if( this.canJoin( actorId ) ){
            this._actors.push(actorId);
            //console.log(`Joining Actor ${actorId} to the party`);
            $gamePlayer.followers().add(actorId).refresh();
        }
        return;


        //vanilla filter
        if (!this._actors.contains(actorId)) {
            this._actors.push(actorId);
            $gamePlayer.refresh();
            $gameMap.requestRefresh();
        }
    };
    Game_Party.prototype.removeActor = function(actorId) {
        //vanilla
        if (this._actors.contains(actorId)) {
            this._actors.splice(this._actors.indexOf(actorId), 1);
            console.log(`Removing Actor ${actorId} from the party`);
            $gamePlayer.followers().remove(actorId).refresh();
            //$gamePlayer.refresh();
            //$gameMap.requestRefresh();
        }
    };
    /**
     * Count all party guests
     * @returns Number
     */
    Game_Party.prototype.countGuests = function(){
        return this.allMembers().filter( function( actor ){
            return actor.isGuest();
        } ).length;
    };
    /**
     * Count all party guests
     * @returns Number
     */
    Game_Party.prototype.countHirelings = function(){
        return this.allMembers().filter( function( actor ){
            return actor.isHireling();
        } ).length;
    };
    /**
     * Count all party guests
     * @returns Number
     */
    Game_Party.prototype.countBattleMembers = function(){
        return this.allMembers().filter( actor => !actor.isGuest() ).length;
    };
    /**
     * @returns Number
     */
    Game_Party.prototype.countEveryone = function(){
        return this.allMembers().length;
    };
    /**
     * @returns Game_Actors[]
     */
    Game_Party.prototype.battleMembers = function() {
        return this.allMembers().slice(0, this.maxBattleMembers()).filter(function(actor) {
            return actor.isAppeared();
        });
    };    

    //////////////////////////////////////////////////////////////////////////////////////////////
    //// GAME FOLLOWERS 
    //////////////////////////////////////////////////////////////////////////////////////////////
    Game_Followers.prototype.initialize = function () {
        this._visible = $dataSystem.optFollowers;
        this._gathering = false;
        this._data = [];
        //this.populate().refresh();
    };
    Game_Followers.prototype.refresh = function(){
        //update party members previous to iterate over each one of them
        //this.updatePartyMembers().forEach(function(follower) {
        this.forEach(function(follower) {
            return follower.refresh();
        }, this);    
    };
    /**
     * @returns Game_Followers
     */
    Game_Followers.prototype.populate = function () {
        var _slots = $gameParty.maxPartyMembers();
        if (_slots > 0) {
            for (var i = 1; i < _slots; i++) {
                this.add( );
                //this._data.push(new Game_Follower( i ) );
            }
        }
        return this;
    };
    /**
     * @returns Number
     */
    Game_Followers.prototype.count = function(){
        return this._data.length;
    };
    /**
     * @returns Game_Follower
     */
    Game_Followers.prototype.first = function(){
        return this._data.length > 0 ? this._data[0] : null;
    };
    /**
     * @returns Game_Follower
     */
    Game_Followers.prototype.last = function(){
        return this._data.length > 0 ? this._data[ this._data.length - 1 ] : null;
    };
    /**
     * @returns Number
     */
    Game_Followers.prototype.count = function(){
        return this._data.length;
    };
    /**
     * @returns Game_Followers
     */
    Game_Followers.prototype.add = function( ){
            this._data.push(new Game_Follower( this._data.length ) );
            console.log( this.last() );
            if( this.currentSpriteSet() !== null ){
                this.currentSpriteSet().addCharacterSprite( this.last() );
            }
        return this;
    };
    /**
     * 
     * @param {Number} follower_id 
     * @returns Game_Followers
     */
    Game_Followers.prototype.remove = function( follower_id ){
        if( this.count() > 1 ){
            //this._data.splice(this._data.indexOf( _members + 1 ), this.count() - _members );
            var removed = this._data.pop();
            console.log( removed );
            if( this.currentSpriteSet() !== null ){
                this.currentSpriteSet().removeCharacterSprite(removed);
            }
        }
        return this;
    };
    /**
     * @returns Spriteset_Map
     */
    Game_Followers.prototype.currentSpriteSet = function(){
        if (SceneManager._scene instanceof Scene_Map) {
            return SceneManager._scene._spriteset;
        }
        return null;
    };
    /**
     * @returns String
     */
    Game_Follower.prototype.getType = function(){
        switch( true ){
            case this.actor().isGuest():
                return KunFollowers.Type.Guest;
            case this.actor().isHireling():
                return KunFollowers.Type.Hireling;
            default:
                return KunFollowers.Type.Member;
        }
    };
    /**
     * @returns Game_Actor
     */
    Game_Follower.prototype.actor = function() {
        return $gameParty.allMembers()[this._memberIndex];
    };



    /**
     * @param {Game_Follower} character
     * @returns 
     */
    Spriteset_Map.prototype.removeCharacterSprite = function( character ){
        if( this._characterSprites.includes( character ) ){
            var removed = this._characterSprites.pop( character )
            this._tilemap.removeChild(removed);
            console.log('Removing follower ...');
            console.log(removed);
            return true;
        }
        return false;
    };
    /**
     * 
     * @param {Game_Follower} character 
     * @returns Boolean
     */
    Spriteset_Map.prototype.addCharacterSprite = function( character ) {
        if( this.countPartyCharacters() < $gameParty.maxPartyMembers() ){
            //mark character sprite as follower to handle better future updates
            var sprite = new Sprite_Character( character , true );
            sprite.locate( $gamePlayer.x, $gamePlayer.y );
            this._characterSprites.push( sprite );
            this._tilemap.addChild( this._characterSprites[ this._characterSprites.length - 1 ] );
            console.log('Adding follower...');
            console.log(sprite);            
            return true;
        }
        return false;
    };
    /**
     * @returns Number
     */
    Spriteset_Map.prototype.countPartySprites = function() {
        //console.log(this._tilemap.children );
        return this._tilemap.children.filter( sprite => typeof sprite === Sprite_Character && sprite.isFollower()).length;
    };
    /**
     * @returns Number
     */
    Spriteset_Map.prototype.countPartyCharacters = function() {
        return this._characterSprites.length;
    };

    /**
     * Create a follower flag to handle the spriteset filtering
     */
    var _KunFollowers_SpriteCharacter_Initialize = Sprite_Character.prototype.initialize;
    /**
     * 
     * @param {Game_Event} character 
     * @param {Boolean} isFollower 
     */
    Sprite_Character.prototype.initialize = function(character , isFollower ) {

        _KunFollowers_SpriteCharacter_Initialize.call( this , character );

        this._isFollower = typeof isFollower === 'boolean' && isFollower;
    };
    /**
     * @returns Boolean
     */
    Sprite_Character.prototype.isFollower = function(){
        return this._isFollower;
    };
}


/**
 * 
 */
KunFollowers_SetupCommands = function () {
    var _KunFollowers_Commands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunFollowers_Commands.call(this, command, args);
        if (command === 'KunFollower') {
            if (args && args.length) {
                switch (args[0]) {
                    case 'add-guest':
                    case 'add':
                        kun_follower_add_guest(parseInt(args[1]), args.length > 2 ? parseInt(args[2]) : 1)
                        break;
                    case 'remove':
                    case 'remove-guest':
                        kun_follower_remove_guest(parseInt(args[1]),
                            args.length > 2 && args[2] === 'all',
                            args.length > 3 ? parseInt(args[3]) : 0);
                        break;
                    case 'count':
                        if (args.length > 2) {
                            $gameVariables.setValue(parseInt(args[2]), kun_follower_count(parseInt(args[1])));
                        }
                        break;
                    case 'count-guests':
                        if (args.length > 1) {
                            $gameVariables.setValue(parseInt(args[1]), $gameParty.countGuests());
                            //$gameVariables.setValue(parseInt(args[1]), $gamePlayer._followers.countGuests());
                        }
                        break;
                    case 'max-followers':
                        if (args.length > 1) {
                            //$gameVariables.setValue( parseInt(args[1]) , KunFollowers.maxPartyMembers());
                            $gameVariables.setValue(parseInt(args[1]), $gameParty.maxBattleMembers());
                        }
                        break;
                    case 'max-guests':
                        if (args.length > 1) {
                            $gameVariables.setValue(parseInt(args[1]), KunFollowers.maxGuests());
                        }
                        break;
                    case 'setup-hireling':
                        if (args.length > 2) {
                            kun_follower_reset_hireling(
                                Number.isInteger(args[1]) ? parseInt(args[1]) : args[1],
                                args[2],
                                args.length > 3 ? parseInt(args[3]) : 0,
                                args.length > 4 ? parseInt(args[4]) : false);
                        }
                        break;
                    case 'remove-hirelings':
                        KunFollowers.removeHirelings();
                        break;
                    case 'add-hireling':
                        if (args.length > 1) {
                            var _level = 1;
                            if (args.length > 2) {
                                //import level from gamevar
                                _level = $gameVariables.value(parseInt(args[2]));
                            }
                            var _actor_id = kun_follower_join_hireling(args[1], _level, args.length > 4 ? parseInt(args[4]) : false);
                            if (_actor_id > 0 && args.length > 3 && args[3] > 0) {
                                //export joined hireling actor ID
                                $gameVariables.setValue(parseInt(args[3]), _actor_id);
                            }
                        }
                        break;
                    case 'count-hirelings':
                        if (args.length > 1) {
                            $gameVariables.setValue(parseInt(args[1]), kun_follower_count_hirelings());
                            if (args.length > 2) {
                                $gameVariables.setValue(parseInt(args[2]), kun_follower_max_hirelings());
                            }
                        }
                        break;
                    case 'increase':
                        if (args.length > 1) {
                            var amount = args.length > 2 ? parseInt(args[2]) : 1;
                            switch (args[1]) {
                                case 'followers':
                                    KunFollowers.addPartySlot(amount || 1);
                                    break;
                                case 'guests':
                                    KunFollowers.addGuestSlot(amount || 1);
                                    break;
                            }
                        }
                        break;
                    case 'decrease':
                        if (args.length > 1) {
                            var amount = args.length > 2 ? parseInt(args[2]) : 1;
                            switch (args[1]) {
                                case 'followers':
                                    KunFollowers.removePartySlot(amount || 1);
                                    break;
                                case 'guests':
                                    KunFollowers.removeGuestSlot(amount || 1);
                                    break;
                            }
                        }
                        break;
                }
            }
        }
    };
}
/**
 * @param {Number} actor_id 
 * @returns 
 */
function kun_follower_count( actor_id ) {
    return $gameParty.allMembers().filter( id => id === actor_id ).length;
    return $gamePlayer.followers().guests(actor_id || 0).length;
}
/**
 * 
 * @param {Number} actor_id 
 * @param {Amount} amount Optional
 * @returns 
 */
//function kun_follower_add( actor_id , amount ) {
function kun_follower_add_guest(actor_id, amount) {
    return $gameParty.addActor( actor_id );
    return $gamePlayer.followers().addGuest(actor_id, amount || 1);
}
/**
 * @param {Number} actor_id 
 * @param {Boolean} removeAll Remove all from the same actor_id
 * @param {Number} exportVar export removed actors to this variable
 * @returns 
 */
//function kun_follower_remove(actor_id , removeAll , exportVar ) {
function kun_follower_remove_guest(actor_id, removeAll, exportVar) {
    //define if this is a required method
    return 0;

    var removed = $gamePlayer.followers().dropGuest(actor_id, removeAll);

    if (typeof exportVar === 'number' && exportVar > 0) {
        $gameVariables.setValue(exportVar, removed);
    }

    return removed > 0;
}
/**
 * @param {Number|String} hireling 
 * @param {Number} actor_id 
 * @param {Number} level (optional, default 1)
 * @param {Number} variation (optional)
 * @return Boolean
 */
function kun_follower_reset_hireling(hireling, actor_id, level, variation) {

    return KunFollowers.updateHireling(hireling, actor_id, level, variation);
}
/**
 * 
 * @param {String|Number} hireling 
 * @param {Number} level 
 * @param {Number} variation (optional)
 * @returns Number|Boolean Joined Actor ID or false if failure
 */
function kun_follower_join_hireling(hireling, level, variation) {
    return KunFollowers.joinHireling(hireling, level, variation);
};
/**
 * @returns Number
 */
function kun_follower_count_hirelings() {
    return KunFollowers.countHirelings();
};
/**
 * @returns Number
 */
function kun_follower_max_hirelings() {
    return KunFollowers.maxHirelings();
}


(function () {

    KunFollowers.Initialize();
    KunFollowers_SetupGameParty();
    KunFollowers_SetupCommands();

})();

















