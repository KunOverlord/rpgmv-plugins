//=============================================================================
// KunSounds.js
//=============================================================================
/*:
 * @filename KunSounds.js
 * @plugindesc Create playable sound banks to randomize different Sound Effect outputs
 * @version 1.1
 * @author KUN
 * @target MC | MZ
 * 
 * @help
 * 
 * COMMANDS:
 * 
 *      KunSounds play [sound_bank_name] [fps] [import]
 *          Play a sound bank selection by name. You can add more soundbanks separated by semi-colon (:) to allow random play.
 *          Set wait FPS to include a time waiting pause before running the next events
 *          Use import tag to define a Game Variable where to import the fps values from
 * 
 *      KunSounds interrupt [on|off]
 *          Allow a sound bank selection to interrupt other Sound Effects playing by MEdia Player
 *          Activated by default for those sound banks marked with Allow SE interruption
 * 
 *      KunSounds wait [fps] [import]
 *          Wait for elapsed FPS before running the next routines in the event editor
 *          Use import tag to define a Game Variable where to import the fps values from
 * 
 *      KunSounds list
 *          Debug sound bank info
 * 
 * @param debug
 * @text Debug Level
 * @desc Show debug info.
 * @type boolean
 * @default false
 * 
 * @param profiles
 * @text Profiles
 * @desc List all sound bank profiles here
 * @type struct<Profile>[]
 * 
 */
/*~struct~Profile:
 * @param name
 * @text Profile
 * @desc Define a profile to group a list of sound banks
 * @type text
 * 
 * @param collections
 * @type struct<Collection>[]
 * @text Sound Collections
 * @desc Define the list of Sound Effects for this profile
 * 
 */
/*~struct~Collection:
 * @param name
 * @text Name
 * @type text
 * @default sound-emitter
 * 
 * @param round
 * @text Rounds
 * @type number
 * @desc Play a sound selection every N frameset loops
 * @min 0
 * @max 10
 * @default 0
 * 
 * @param chance
 * @text Chance
 * @type number
 * @min 1
 * @max 100
 * @default 100
 * 
 * @param sfx
 * @text Sound Collection
 * @type file[]
 * @desc Add a selection of sound effects to play in this sound bank
 * @require 1
 * @dir audio/se/
 * 
 * @param volume
 * @text Volume
 * @desc Define a single volume value, a random volume interpolation among 2 values, or a random volume from 3 or more values.
 * @type number[]
 * @min 0
 * @max 100
 * @default ["90"]
 * 
 * @param pitch
 * @text Pitch
 * @desc Define a single pitch value, a random pitch interpolation among 2 values, or a random pitch from 3 or more values.
 * @type number[]
 * @min 50
 * @max 150
 * @default ["100"]
 * 
 * @param pan
 * @text Pan
 * @desc Define a single pan value, a random pan interpolation among 2 values, or a random pan from 3 or more values.
 * @type number[]
 * @min -100
 * @max 100
 * @default ["0"]
 * 
 * @param interrupt
 * @text Allow interruption
 * @desc Stop playing other Sound Effects when this bank plays a selection
 * @type boolean
 * @default false
 *
 */

//const { count } = require('console');

/**
 * @description KUN Modules
 * @type KUN
 */
var KUN = KUN || {};

/**
 * @returns 
 */
function KunSounds() {
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 * @returns {KunSounds}
 */
KunSounds.Initialize = function () {

    const parameters = this.PluginData()

    this._debug = parameters.debug;

    this._canInterrupt = true;

    this._collections = {};

    parameters.profiles.forEach( function( profile ){
        profile.collections.forEach( function( bank ){
            //console.log(bank);
            var sb = new KunSoundEmitter(
                profile.name.length ? profile.name + '-' + bank.name : bank.name,
                bank.chance,
                bank.interrupt,
                bank.round || 0);
            bank.pitch.forEach( pitch => sb.addPitch(pitch) );
            bank.pan.forEach( pan => sb.addPan(pan ) );
            bank.volume.forEach( volume => sb.addVol(volume) ) ;
            bank.sfx.forEach( se => sb.addSe(se) );
            KunSounds.add(sb);    
        });
    });
};
/**
 * @returns {Boolean}
 */
KunSounds.canInterrupt = function () {
    return this._canInterrupt;
};
/**
 * @param {Boolean} allow 
 * @returns {KunSounds}
 */
KunSounds.allowInterruption = function (allow) {
    this._canInterrupt = typeof allow === 'boolean' && allow;
    return this;
};
/**
 * @returns {Boolean}
 */
KunSounds.debug = function () {
    return this._debug;
};
/**
 * @returns {Boolean}
 */
KunSounds.enableSoundBanks = function(){
    return this._ksb;
};
/**
 * @param {Boolean} list 
 * @returns {Object | Object[]}
 */
KunSounds.sounds = function (list) {
    return typeof list === 'boolean' && list ? Object.values(this._collections) : this._collections;
};
/**
 * List all available sound banks
 * @returns {String[]}
 */
KunSounds.list = function(){
    return Object.keys( this.sounds( ) );
};
/**
 * @param {String} sound 
 * @returns {Boolean}
 */
KunSounds.has = function (sound) {
    return typeof sound === 'string' && sound.length > 0 && this._collections.hasOwnProperty(sound);
};
/**
 * @param {KunSoundEmitter} sound 
 * @returns {KunSounds}
 */
KunSounds.add = function (sound) {
    //console.log( bank );
    if (sound instanceof KunSoundEmitter && !this.has(sound.name())) {
        this._collections[sound.name()] = sound;
    }
    return this;
};
/**
 * @param {String} sound 
 * @returns {KunSoundEmitter}
 */
KunSounds.get = function (sound) {
    return this.has(sound) ? this.sounds()[sound] : KunSoundEmitter.Empty();
};
/**
 * @param {String} bank 
 * @param {Number} round
 * @returns {KunSounds}
 */
KunSounds.play = function (bank , round = 0 ) {
    //console.log( bank );
    if (this.has(bank)) {
        this.sounds()[bank].play( round );

    }
    return this;
};
/**
 * 
 */
KunSounds.PluginData = function () {
    function _parsePluginData ( key , value ) {
        if (typeof value === 'string' && value.length ) {
            try {
                if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                    return JSON.parse(value, _parsePluginData );
                }
            } catch (e) {
                // If parsing fails or it's not an object/array, return the original value
            }
            if( value === 'true' || value === 'false'){
                return value === 'true';
            }
            if( !isNaN(value) ){
                return parseInt(value);
            }
        }
        return value;
    };

    var _data = PluginManager.parameters('KunSounds');
    var _output = {};
    Object.keys( _data ).forEach( function(key ){
        _output[key] = _parsePluginData(key , _data[key]);
    });
    return _output;
};
/**
 * @param {Object[]} input 
 * @returns {KunSounds}
 */
KunSounds.ImportSoundBanks = function (input) {
    (input).map(sb => sb.length > 0 ? JSON.parse(sb) : null).forEach(function (bank) {
        var sb = new KunSoundEmitter(bank.name, bank.chance, bank.interrupt === 'true', parseInt(bank.round || 0));
        //console.log( sb.name() );
        (bank.pitch.length > 0 ? JSON.parse(bank.pitch) : []).map(pitch => parseInt(pitch)).forEach(function (pitch) {
            sb.addPitch(pitch);
        });
        (bank.pan.length > 0 ? JSON.parse(bank.pan) : []).map(pan => parseInt(pan)).forEach(function (pan) {
            sb.addPan(pan);
        });
        (bank.volume.length > 0 ? JSON.parse(bank.volume) : []).map(volume => parseInt(volume)).forEach(function (volume) {
            sb.addVol(volume);
        });
        (bank.sfx.length > 0 ? JSON.parse(bank.sfx) : []).forEach(function (se) {
            sb.addSe(se);
        });
        KunSounds.add(sb);
    });
    return this;
};
/**
 * 
 * @param {String} se 
 * @param {Number} volume 
 * @param {Number} pitch 
 * @param {Number} pan 
 * @param {Boolean} interrupt
 */
KunSounds.AudioManager = function (se, volume, pitch, pan, interrupt) {
    if (se.length) {
        if (typeof interrupt === 'boolean' && interrupt) {
            AudioManager.stopSe();
        }
        //KunSounds.DebugLog( `Playing ${se} at vol ${volume}, pitch ${pitch} and pan ${pan} ${interrupt}` );
        AudioManager.playSe({ name: se, pan: pan || 0, pitch: pitch || 100, volume: volume || 90 });
    }
};
/**
 * @param {String} message 
 */
KunSounds.DebugLog = function (message) {
    if (this.debug()) {
        console.log(typeof message === 'object' ? message : `[ KunSounds ] ${message.toString()}`);
    }
};
/**
 * @param {String} name 
 * @returns {Boolean}
 */
KunSounds.SoundEffectExists = function (name) {
    return this.FileExists(this.FilePath(name + AudioManager.audioFileExt()));
}
/**
 * @param {String} path 
 * @returns {Boolean}
 */
KunSounds.FileExists = function (path) {

    var fs = require('fs');
    if (fs.existsSync(path)) {
        return true;
    }

    if (KunSounds.debug(KunSounds.DebugMode().TraceLog)) {
        KunSounds.DebugLog(`File missing ${path}`);
    }

    return false;
};
/**
 * @param {String} file 
 * @returns {String}
 */
KunSounds.FilePath = function (file) {
    var path = require('path');
    var base = path.dirname(process.mainModule.filename);
    return path.join(base, `audio/se/${file}`);
};
/**
 * @param {String} command 
 * @returns {Boolean}
 */
KunSounds.command = function(command){
    return ['KunSoundBanks','KunSounds','KunMedia','KunSounds'].includes(command);
};


/**
 * Backwards Compatibility
 * @returns 
 */
function KunSoundBanks() {
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * @param {String} soundset 
 * @param {Number} round 
 * @returns {KunSounds}
 */
KunSoundBanks.play = function( soundset , round = 0){
    return KunSounds.play( soundset , round );
};




/**
 * @param {String} name 
 * @param {Number} chance
 * @param {Boolean} interrupt
 * @param {Number} round
 */
function KunSoundEmitter(name, chance, interrupt, round) {
    this._name = name || '';
    this._chance = chance || 100;
    this._interrupt = typeof interrupt === 'boolean' && interrupt;
    this._se = [];
    this._volume = [];
    this._pitch = [];
    this._pan = [];
    this._round = round || 0;
};
/**
 * @returns {String}
 */
KunSoundEmitter.prototype.toString = function () {
    return this.name();
};
/**
 * @returns {String}
 */
KunSoundEmitter.prototype.name = function () {
    return this._name;
};
/**
 * @returns {Number}
 */
KunSoundEmitter.prototype.round = function () {
    return this._round;
};
/**
 * @returns {Boolean}
 */
KunSoundEmitter.prototype.interrupt = function () {
    return this._interrupt && KunSounds.canInterrupt();
};
/**
 * @returns {Number}
 */
KunSoundEmitter.prototype.chance = function () {
    return this._chance > Math.floor(Math.random() * 100);
};
/**
 * 
 * @param {String} se 
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.prototype.addSe = function (se) {
    if (typeof se === 'string' && se.length) {
        this._se.push(se);
    }
    return this;
};
/**
 * @param {Number} vol 
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.prototype.addVol = function (vol) {
    if (typeof vol === 'number' && vol) {
        this._volume.push(vol);
    }
    return this;
};
/**
 * @param {Number} pitch 
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.prototype.addPitch = function (pitch) {
    if (typeof pitch === 'number' && pitch) {
        this._pitch.push(pitch);
    }
    return this;
};
/**
 * @param {Number} pan 
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.prototype.addPan = function (pan) {
    if (typeof pan === 'number' && pan) {
        this._pan.push(pan);
    }
    return this;
};
/**
 * @returns {Number}
 */
KunSoundEmitter.prototype.pan = function () {
    switch (this._pan.length) {
        case 0: return 0;
        case 1: return this._pan[0];
        case 2:
            var min = this._pan[0] < this._pan[1] ? this._pan[0] : this._pan[1];
            var max = this._pan[1] > this._pan[0] ? this._pan[1] : this._pan[0];
            return min + Math.floor(Math.random() * (max - min));
        default:
            return this._pan[Math.floor(Math.random() * this._pan.length)];
    }
};
/**
 * @returns {Number}
 */
KunSoundEmitter.prototype.pitch = function () {
    switch (this._pitch.length) {
        case 0: return 100;
        case 1: return this._pitch[0];
        case 2:
            var min = this._pitch[0] < this._pitch[1] ? this._pitch[0] : this._pitch[1];
            var max = this._pitch[1] > this._pitch[0] ? this._pitch[1] : this._pitch[0];
            return min + Math.floor(Math.random() * (max - min));
        default:
            return this._pitch[Math.floor(Math.random() * this._pitch.length)];
    }
};
/**
 * @returns {Number}
 */
KunSoundEmitter.prototype.volume = function () {
    switch (this._volume.length) {
        case 0: return 50;
        case 1: return this._volume[0];
        case 2:
            var min = this._volume[0] < this._volume[1] ? this._volume[0] : this._volume[1];
            var max = this._volume[1] > this._volume[0] ? this._volume[1] : this._volume[0];
            return min + Math.floor(Math.random() * (max - min));
        default:
            return this._volume[Math.floor(Math.random() * this._volume.length)];
    }
};
/**
 * @returns {String}
 */
KunSoundEmitter.prototype.select = function () {
    var size = this._se.length;
    if( size ){
        return size > 1 ? this._se[Math.floor(Math.random() * size)] : this._se[0];
    }
    return '';
};
/**
 * @param {Number} round
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.prototype.play = function ( round = 0 ) {
    if (this.canPlay()) {
        if(this.round() && round % this.round() > 0 ){
            //skip
            return this;
        }
        
        if(this.chance()){
            KunSounds.AudioManager(this.select(), this.volume(), this.pitch(), this.pan(), this.interrupt());
        }
    }
    return this;
};
/**
 * @returns {Boolean}
 */
KunSoundEmitter.prototype.canPlay = function () {
    return this._se.length > 0;
};
/**
 * 
 * @returns {KunSoundEmitter}
 */
KunSoundEmitter.Empty = function () {
    return new KunSoundEmitter('EMPTY');
};

/**
 * 
 */
function KunSounds_SetupCommands() {
    var _KunSounds_SetupCommands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunSounds_SetupCommands.call(this, command, args);
        if (KunSounds.command(command) && args.length > 0) {
            switch (args[0]) {
                case 'play':
                    if (args.length > 1) {
                        var playList = args[1].split(':');
                        KunSounds.play( playList.length > 1 ? playList[ Math.floor(Math.random() * playList.length) ] : playList[0]);
                        if (args.length > 2) {
                            var wait = parseInt(args[2]);
                            if( args.length > 3 && args[3] === 'import' && wait > 0 ){
                                wait = $gameVariables.value( wait );
                            }
                            this.wait( wait );
                            KunSounds.DebugLog(`Waiting ${wait} fps ...`);    
                        }
                    }
                    break;
                case 'wait':
                    if (args.length > 1) {
                        var wait = parseInt(args[1]);
                        if (args.length > 2 && args[2] === 'import' && wait > 0) {
                            wait = $gameVariables.value(wait);
                        }
                        this.wait(wait);
                        KunSounds.DebugLog(`Waiting ${wait} fps ...`);
                    }
                    break;
                case 'interrupt':
                    KunSounds.allowInterruption(args.length > 1 && args[1] === 'on');
                    break;
                case 'list':
                    KunSounds.sounds(true);
                    break;
            }
        }
    };
}

/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunSounds.Initialize();

    KunSounds_SetupCommands();
})( /* initializer */);



