//=============================================================================
// KunTraits.js
//=============================================================================
/*:
 * @plugindesc Kun Special Attributes
 * @filename KunTraits.js
 * @author Kun
 * @version 1.94
 * 
 * @help
 * 
 * COMMANDS
 * 
 *      KunTraits reset [actor_id] [attribute_name]
 *          Resets acgor's gauge to the original value
 * 
 *      KunTraits set [actor_id] [attribute_name] [amount] [import]
 *          Sets actor's gauge_name the provided amount. Use import to use a gameVariable value
 * 
 *      KunTraits add [actor_id] [attribute_name] [amount] [import]
 *          Adds actor's gauge_name the provided amount. Use import to use a gameVariable value
 * 
 *      KunTraits sub [actor_id] [attribute_name] [amount] [import]
 *          Substract actor's gauge_name the provided amount. Use import to use a gameVariable value
 * 
 *      KunTraits bind [actor_id] [attribute_name] [valueVar] [rangeVar] [import]
 *          Bind an attribute value and range to game variables to export immediate updates
 *      
 *      KunTraits unbind [actor_id] [attribute_name] [import]
 *          Clear all bindings to an attribute
 * 
 *      KunTraits maximum [actor_id] [attribute_name] [maximum] [import]
 *          Sets the maximum range of the selected attribute and updates the current value if required to fit the new range.
 * 
 *      KunTraits progress [actor_id] [attribute_name] [exportVar]
 *          Exports the selected attribute's percentage value into a Game Variable [exportVar]
 * 
 *      KunTraits export [actor_id] [attribute_name] [value_var] [maximum_var]
 *          Export actor_id attribute current value into value_var
 *          Export actor_id max attribute value using maximum_var
 * 
 *      KunTraits migrate [old_trait] [new_trait]
 * 
 *
 * @param debug
 * @text Debug
 * @desc Which text to show when the character arouses up
 * @type Boolean
 * @default false
 * 
 * @param attributes
 * @text Special Attributes
 * @desc Define here the list of special attributes for each char.
 * @type struct<Attribute>[]
 *
 */
/*~struct~Attribute:
 * @param name
 * @text Name
 * @type text
 * @desc Attribute Name
 * 
 * @param title
 * @text Display Name
 * @type text
 * @desc The display name for this attribute
 * 
 * @param icon
 * @text Icon
 * @type number
 * @min 0
 * @default 0
 *
 * @param display
 * @name Display
 * @desc Attribute display type
 * @type select
 * @option None
 * @value none
 * @option Counter
 * @value counter
 * @option Gauge
 * @value gauge
 * @option Full
 * @value full
 * @default full
 * 
 * @param maximum
 * @text Maximum
 * @type number
 * @min 1
 * @default 100
 * 
 * @param value
 * @text Default Value
 * @type number
 * @min 0
 * @default 0
 * 
 * @param reverse
 * @type boolean
 * @text Reverse
 * @desc define a negative progress bar below 0 to -max
 * @default false
 * 
 * @param color1
 * @text Base Color
 * @type number
 * @min 0
 * @max 32
 * @default 2
 * 
 * @param color2
 * @text Overlay Color
 * @type number
 * @min 0
 * @max 32
 * @default 5
 * 
 * @param actors
 * @text Actors
 * @desc List all exclusive actors who wanna use this attribute ;)
 * @type actor[]
 * 
 * @param events
 * @type struct<Event>[]
 * @text Rules
 * @desc Define a list of rules to perform special actions when an actor meets a condition
 * @default []
 * 
 */
/*~struct~Event:
 * @param value
 * @type number
 * @text Value
 * @desc check the target value for this condition
 * @min 0
 * @default 0
 * 
 * @param operation
 * @text Operation
 * @desc Select the proper operation to compare value to the current attribute
 * @type select
 * @option Greater
 * @value greater
 * @option Greater or Equal
 * @value greater-equal
 * @option Equal
 * @value equal
 * @option Less or Equal
 * @value less-equal
 * @option Less
 * @value less
 * @default equal
 * 
 * @param addState
 * @text Add State
 * @type state[]
 * @desc Add these states
 * 
 * @param remState
 * @text Remove State
 * @type state[]
 * @desc Remove these states
 * 
 * @param title
 * @text Set Attribute Title
 * @type text
 * 
 * @param icon
 * @text Set Attribute Icon
 * @type number
 * @default 0
 * 
 * @param colors
 * @text Set Bar Color
 * @desc Define one or two color values to set the attribute bar layout
 * @type number[]
 * 
 * @param message
 * @type text
 * @text Message
 * @desc Define here a message to display when this action is fired. Requires KunNotifier.
 * 
 * @param media
 * @text Play Media
 * @desc Play a Sound Effect when running this action
 * @type file
 * @dir audio/se/
 */
/**
 * @description JayaK Modules
 * @type JayaK
 */
var KUN = KUN || {};

function KunTraits() {
    throw `${this.constructor.name} is a Static Class`;
};
/**
 * 
 * @returns KunTraits
 */
KunTraits.Initialize = function () {

    var _parameters = KunTraits.PluginData();

    this._debug = _parameters.debug;

    this._traits = {
        //list attribute definition here
    };

    return this.Import(_parameters.attributes);
}
/**
 * @returns Object
 */
KunTraits.PluginData = function () {
    function _parsePluginData ( key , value ) {
        if (typeof value === 'string' && value.length ) {
            try {
                if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                    return JSON.parse(value, _parsePluginData );
                }
            } catch (e) {
                // If parsing fails or it's not an object/array, return the original value
            }
            if( value === 'true' || value === 'false'){
                return value === 'true';
            }
            if( !isNaN(value) ){
                return parseInt(value);
            }
        }
        else if( typeof value === 'object' && !Array.isArray(value) ){
            var _output = {};
            Object.keys( value ).forEach( function(key ){
                _output[key] = _parsePluginData( key , value[key] );
            });
            return _output;
        }
        return value;
    };

    return _parsePluginData( 'KunTraits', PluginManager.parameters('KunTraits'));
};

/**
 * @returns Boolean
 */
KunTraits.debug = function () {
    return this._debug;
}
/**
 * @param {String} attribute 
 * @returns Boolean
 */
KunTraits.has = function (attribute) {
    return typeof attribute === 'string' && attribute.length > 0 && this.traits().hasOwnProperty(attribute);
};

/**
 * @param {KunTrait} trait
 * @returns KunTraits
 */
KunTraits.add = function ( trait ) {

    if ( trait instanceof KunTrait && !this.has(trait.name())) {
        this._traits[trait.name()] = trait;
    }

    return this;
};

/**
 * List all attributes by actor
 * @param {Number} actor_id 
 * @param {Boolean} showAll 
 * @returns KunTrait[]
 */
KunTraits.actorTraits = function (actor_id, showAll) {
    showAll = typeof showAll === 'boolean' && showAll;
    return this.traits(true).filter(item => item.has(actor_id) && (showAll || item.display() !== KunTraits.DisplayType.NONE));
};
/**
 * @param {Boolean} list 
 * @returns Object|KunTrait[]
 */
KunTraits.traits = function (list) {
    return typeof list === 'boolean' && list ? Object.values(this._traits) : this._traits;
};
/**
 * @param {String} trait 
 * @returns KunTrait
 */
KunTraits.trait = function (trait) {
    return this.has(trait) ? this._traits[trait] : null;
};
/**
 * @param {Number} actor_id 
 * @returns Object
 */
KunTraits.createAttributes = function (actor_id) {
    var attributes = {};
    this.actorTraits(actor_id , true ).map( trait => trait.createAttribute()).forEach( function( attribute ){
        attributes[attribute.name()] = attribute;
    });
    return attributes;
};
/**
 * 
 * @param {Number} actor_id 
 * @param {String} oldAtt 
 * @param {String} newAtt 
 * @returns 
 */
KunTraits.importAmirian = function ( actor_id , oldAtt , newAtt ) {
    var actor = $gameActors.actor(actor_id);
    if( actor.hasOwnProperty(oldAtt) && actor._traits.hasOwnProperty(newAtt)){
        actor._traits[newAtt].value = actor[oldAtt];
        actor._traits[newAtt].max = 100;
        return true;
    }
    return false;
};
/**
 * 
 * @param {Object} input 
 * @returns KunTraits
 */
KunTraits.Import = function (input) {
    input.forEach(function (att) {
        if (att !== null) {
            //console.log( trait );
            var trait = new KunTrait(
                att.name,att.title,
                att.display,att.maximum,att.value,
                att.icon,att.color1,att.color2,
                att.reverse,att.actors);
            if(Array.isArray(att.events)){
                att.events.forEach( function( e ){
                    var rule = new KunTraitRule(
                        e.value , e.operation ,
                        e.title || '',
                        e.icon,
                        e.colors.length > 0 ? e.colors[0] : -1,
                        e.colors.length > 1 ? e.colors[1] : -1,
                        e.media, e.message );
                    trait.addRule( rule.addStates( e.addState ).dropStates( e.remState ) );
                });    
            }
            KunTraits.add( trait );
        }
    });

    return this;
};


/**
 * 
 */
function KunTraits_SetupActorAttributes() {
    /**
     * @returns Game_Actor[]
     */
    Game_Actors.prototype.list = function() {
        return this._data;
    };
    //OVERRIDE CHARACTER STATS
    var _KunTraits_InitMembers = Game_Actor.prototype.initMembers;
    Game_Actor.prototype.initMembers = function () {
        //vanilla
        //this._KunSpecialAttsInitCharacter();
        _KunTraits_InitMembers.call(this);

        this.setupAttributes();
    };
    Game_Actor.prototype.setupAttributes = function () {
        this._customAttributes = KunTraits.createAttributes(this._actorId);
        KunTraits.DebugLog(this._customAttributes);
    };
    /**
     * @param Boolean list
     * @returns {Object|Array}
     */
    Game_Actor.prototype.attributes = function (list) {
        if (!this.hasOwnProperty('_customAttributes')) {
            this.setupAttributes();
        }
        return typeof list === 'boolean' && list ? Object.values(this._customAttributes) : this._customAttributes;
    };
    /**
     * @param {String} attribute 
     * @returns Boolean
     */
    Game_Actor.prototype.hasAttribute = function (attribute) {
        return this.attributes().hasOwnProperty(attribute) && KunTraits.has(attribute);
    };
    /**
     * @param {String} attribute 
     * @returns KunAttribute
     */
    Game_Actor.prototype.attribute = function (attribute) {
        return this.hasAttribute(attribute) ? this.attributes()[attribute] : null;
    };
    /**
     * @param {String} attribute 
     * @param {Boolean} getDefault
     * @returns Number
     */
    Game_Actor.prototype.attributeMax = function (attribute , getDefault ) {
        return this.hasAttribute(attribute) ? this.attribute(attribute).range(getDefault) : 0;
    };
    /**
     * @param {String} attribute 
     * @returns Number
     */
    Game_Actor.prototype.attributeMin = function (attribute) {
        return this.hasAttribute(attribute) ? this.attribute(attribute).min() : 0;
    };
    /**
     * @param {String} name 
     * @param {Boolean} progress
     * @returns Number
     */
    Game_Actor.prototype.attributeValue = function (name , progress ) {
        if (this.hasAttribute(name)) {
            return this.attribute(name).value( typeof progress === 'boolean' && progress );
        }
        return 0;
    };
    /**
     * @param {String} name 
     * @returns Game_Actor
     */
    Game_Actor.prototype.unbindAttribute = function( name ){
        if( this.hasAttribute( name ) ){
            this.attribute(name).unbind();
        }
        return this;
    };
    /**
     * Update binded Game Variables
     * @param {String} name 
     * @param {Number} valueVar
     * @param {Number} rangeVar
     * @returns Game_Actor
     */
    Game_Actor.prototype.bindAttribute = function( name , valueVar , rangeVar ){
        if( this.hasAttribute(name )){
            //reset all present bindings
            if(typeof valueVar === 'number' && valueVar > 0 && typeof rangeVar === 'number' && rangeVar > 0 ){
                //add the value binding to a Game Variable
                this.attribute(name).bind( valueVar , rangeVar );
            }
        }
        return this;
    };
    /**
     * @param {String} name 
     * @param {Number} value 
     * @param {Boolean} setMaximum
     * @returns Number
     */
    Game_Actor.prototype.setAttribute = function (name, value, setMaximum) {
        if (this.hasAttribute(name)) {
            var attribute = this.attribute(name);
            if(typeof setMaximum === 'boolean' && setMaximum){
                return attribute.setRange(value);
            }
            else {
                attribute.set(value);
            }
            attribute.updateRules(this._actorId);
            return attribute.value();
        }
        return 0;
    };
    /**
     * @param {String} name 
     * @param {Boolean} fullReset
     * @returns Number
     */
    Game_Actor.prototype.resetAttribute = function ( name , fullReset ) {
        if( typeof fullReset === 'boolean' && fullReset ){
            this.setAttribute( name , this.attributeMax(name , true) , true );
        }
        return this.setAttribute( name , 0 );
        //return this.hasAttribute(name) ? this.attribute(name).reset( typeof fullReset === 'boolean' && fullReset ) : 0;
    };
    /**
     * @param {String} attribute 
     * @param {Number} amount 
     * @returns Number
     */
    Game_Actor.prototype.updateAttribute = function (name, amount) {
        amount = typeof amount === 'number' ? amount : 0;
        return amount !== 0 ? this.setAttribute( name ,  this.attributeValue(name) + amount ) : 0;
        //return amount !== 0 && this.hasAttribute(attribute) ? this.attribute(attribute).update(amount) : 0;
    };
};
/**
 * 
 */
function KunTraits_SetupCommands() {
    //override vanilla interpreter.
    var _KunSpecialAtts_GameInterPreter_Command = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunSpecialAtts_GameInterPreter_Command.call(this, command, args);
        if (command === 'KunTraits' && args.length >= 4) {
            //override with plugin command manager
            switch (args[0]) {
                case 'reset':
                    if (args.length > 2) {
                        var actor_id = parseInt(args[1]);
                        if(args.length > 3 && args[3] === 'import'){
                            actor_id = $gameVariables.value(actor_id);
                        }
                        kun_trait_reset( actor_id , args[2], true );
                    }
                    break;
                case 'bind':
                    if( args.length > 4 ){
                        //import actor from game variable?
                        var actor_id = parseInt(args[1]);
                        var value = parseInt(args[3]);
                        var range = parseInt(args[4]);
                        if( args.length > 5 && args[5] === 'import' ){
                            actor_id = $gameVariables.value(actor_id);
                        }
                        if( actor_id > 0 ){
                            $gameActors.actor( actor_id ).bindAttribute(
                                args[2] ,   //attribute name
                                value,      // value variable
                                range       // range variable
                            );
                        }
                    }
                    break;
                case 'unbind':
                    if( args.length > 2 ){
                        //import actor from game variable?
                        var actor_id = parseInt(args[1]);
                        if(  args.length > 3 && args[3] === 'import'  ){
                            actor_id = $gameVariables.value( actor_id );
                        }
                        if( actor_id > 0 ){
                            $gameActors.actor( actor_id ).unbindAttribute(args[2]);
                        }
                    }
                    break;
                case 'maximum':
                    var _import = args.length > 4 && args[4] === 'import';
                    if (args.length > 2) {
                        kun_trait_maximum(
                            _import ? $gameVariables.value(parseInt(args[1])) : parseInt(args[1]),
                            args[2],
                            _import ? $gameVariables.value(parseInt(args[3])) : parseInt(args[3]));
                    }
                    break;
                case 'set':
                    var _import = args.length > 4 && args[4] === 'import';
                    if (args.length > 3) {
                        kun_trait_set(
                            _import ? $gameVariables.value(parseInt(args[1])) : parseInt(args[1]),
                            args[2],
                            _import ? $gameVariables.value(parseInt(args[3])) : parseInt(args[3]));
                    }
                    break;
                case 'add':
                    var _import = args.length > 4 && args[4] === 'import';
                    if (args.length > 3) {
                        kun_trait_add(
                            _import ? $gameVariables.value(parseInt(args[1])) : parseInt(args[1]),
                            args[2],
                            _import ? $gameVariables.value(parseInt(args[3])) : parseInt(args[3]));
                    }
                    break;
                case 'sub':
                    var _import = args.length > 4 && args[4] === 'import';
                    if (args.length > 3) {
                        kun_trait_sub(
                            _import ? $gameVariables.value(parseInt(args[1])) : parseInt(args[1]),
                            args[2],
                            _import ? $gameVariables.value(parseInt(args[3])) : parseInt(args[3]));
                    }
                    break;
                case 'progress':
                    var _exportVar = args.length > 3 ? parseInt(args[3]) : 0;
                    var _actor = args.length > 1 ? $gameActors.actor(parseInt(args[1])) : null;
                    if (_actor !== null && _exportVar > 0) {
                        $gameVariables.setValue(_exportVar, _actor.attributeValue(args[2],true));
                    }
                    break;
                case 'export':
                    var _valueVar = args.length > 3 ? parseInt(args[3]) : 0;
                    var _maxVar = args.length > 4 ? parseInt(args[4]) : 0;
                    var actor = args.length > 1 ? $gameActors.actor(parseInt(args[1])) : null;
                    if (actor !== null && _valueVar > 0) {
                        $gameVariables.setValue(_valueVar, actor.attribute(args[2]));
                        if (_maxVar > 0) {
                            $gameVariables.setValue(_maxVar, actor.attributeMax(args[2]));
                        }
                    }
                    break;
                case 'migrate':
                    //migrate from amirian kun_trait_migrate(_lust , _lust )
                    if( args.length > 2){
                        kun_trait_migrate( args[1] , args[2] , args.length > 3 && args[3] === 'remove' );
                    }
                    break;
            }
        }
    };
}
/**
 * 
 */
function KunTraits_SetupWindows() {
    /**
     * @returns Number
     */
    Window_Status.prototype.getActorID = function () {
        return this._actor !== null ? this._actor._actorId : 0;
    };
    /**
     * @returns Game_Actor
     */
    Window_Status.prototype.hasActor = function () {
        return this._actor !== null;
    }
    Window_Status.prototype.drawBlock3 = function (y) {
        this.drawParameters(0, y);
        this.drawEquipments(240, y);
        this.drawKunTraits(456, this.lineHeight() * 7);
    };
    /**
     * Render Kun Attributes
     * @param {Number} x 
     * @param {Number} y 
     */
    Window_Status.prototype.drawKunTraits = function (x, y) {
        var lineHeight = this.lineHeight();
        //renedr gauges here.
        //var attributes = KunTraits.actorTraits(this.getActorID());
        var attributes = $gameActors.actor(this.getActorID()).attributes(true);
        var count = attributes.length;
        var split = count > 6; //define split display in 2 columns, or fullwidth
        for (var i = 0; i < attributes.length; i++) {
            this.drawKunTrait(
                split && i % 2 > 0 ? x + 140 : x,
                y + lineHeight * ( split ? Math.floor(i / 2) : i ),
                attributes[i] , !split);
        }
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @param {KunAttribute} attribute 
     * @param {Boolean} fullWidth
     * @returns 
     */
    Window_Status.prototype.drawKunTrait = function (x, y, attribute, fullWidth) {

        fullWidth = typeof fullWidth === 'boolean' && fullWidth;

        if( attribute instanceof KunAttribute && attribute.visible()){
            var width = fullWidth ? 270 : 135;

            var icon = attribute.icon();
            if (icon > 0) {
                this.drawIcon(icon, x, y + 10);
            }
            this.changeTextColor(this.systemColor());

            this.drawText( attribute.title(), icon > 0 ? x + Window_Base._iconWidth + 4 : x, y, 270);
            this.resetTextColor();

            if (attribute.showValue()) {
                this.drawText( Math.abs(attribute.value()), x, y, 270, 'right');
            }

            if (attribute.showGauge()) {
                var progress = attribute.value(true);
                var colors = attribute.color();
                var color1 = this.textColor(colors[0]); //get attribute color1
                var color2 = this.textColor(colors[1]); //get attribute color2
                //var progress = range > 0 ? Math.abs(value) / parseFloat(range) : 0;
                //console.log(color1,color2,progress,value,range);
                this.drawGauge(
                    icon > 0 ? x + Window_Base._iconWidth + 4 : x,
                    y + 4,
                    icon > 0 ? width - Window_Base._iconWidth - 4 : width,
                    progress,
                    color1, color2);
            }    
        }
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @param {String|KunTrait} attribute 
     * @param {Boolean} fullWidth
     * @returns 
     */
    Window_Status.prototype.drawKunTrait_OLD = function (x, y, attribute, fullWidth) {

        fullWidth = typeof fullWidth === 'boolean' && fullWidth;

        if( attribute instanceof KunTrait && attribute.display() !== KunTraits.DisplayType.NONE){
            var display = attribute.display();
            var width = fullWidth ? 270 : 135;
            var showValue = display === KunTraits.DisplayType.COUNTER || display === KunTraits.DisplayType.FULL;
            var showGauge = display === KunTraits.DisplayType.GAUGE || display === KunTraits.DisplayType.FULL;
            //var icon = attribute.icon();
            //var title = attribute.title();
            var value = attribute.value();
            var range = attribute.range();
            var layout = attribute.export( value );
            //console.log( layout );
    
            if (layout.icon > 0) {
                this.drawIcon(layout.icon, x, y + 10);
            }
            this.changeTextColor(this.systemColor());
            this.drawText( layout.title, layout.icon > 0 ? x + Window_Base._iconWidth + 4 : x, y, 270);
            this.resetTextColor();
            if (showValue) {
                this.drawText(value, x, y, 270, 'right');
            }
            if (showGauge) {
                var color1 = this.textColor(layout.color1); //get attribute color1
                var color2 = this.textColor(layout.color2); //get attribute color2
                var progress = range > 0 ? Math.abs(value) / parseFloat(range) : 0;
                //console.log(color1,color2,progress,value,range);
                this.drawGauge(
                    layout.icon > 0 ? x + Window_Base._iconWidth + 4 : x,
                    y + 4,
                    layout.icon > 0 ? width - Window_Base._iconWidth - 4 : width,
                    progress,
                    color1, color2);
            }    
        }
    };
}

/**
 * return Boolean
 */
KunTraits.CheckSetupUI = () => { return KUN.hasOwnProperty('SetupUI') && KUN.SetupUI.hasOwnProperty('actorStatus') && KUN.SetupUI.actorStatus; }
/**
 * @param {String} message 
 */
KunTraits.DebugLog = function (message) {
    if (KunTraits.debug()) {
        if (typeof message === 'object') {
            console.log('[ KunTraits ]', message );
        }
        else {
            console.log('[KunTraits]' + message);
        }
    }
};

KunTraits.DisplayType = {
    'NONE': 'none',
    'COUNTER': 'counter',
    'GAUGE': 'gauge',
    'FULL': 'full'
};



/**
 * @param {String} name 
 * @param {String} title
 * @param {String} display 
 * @param {Number} max 
 * @param {Number} value 
 * @param {Number} icon 
 * @param {Number} color1 
 * @param {Number} color2 
 * @param {Boolean} reverse
 * @param {Number[]} actors
 * @returns 
 */
function KunTrait(name, title, display, max, value, icon, color1, color2, reverse, actors) {

    this._name = name;
    this._title = title;
    this._display = display || KunTraits.DisplayType.NONE;
    this._max = max || 100;
    this._value = value || 0;
    this._icon = icon || 0;
    this._color1 = color1 || 2;
    this._color2 = color2 || 5;
    this._reverse = typeof reverse === 'boolean' && reverse;
    this._rules = [
        //add attribute events here
    ];
    this._actors = Array.isArray( actors ) ? actors.map( function( actor ){
        return {'actor_id': parseInt( actor ), 'valueVar': 0 , 'maxVar': 0 };
    } ) : [];

    return this;
}
/**
 * 
 * @param {Number} actor_id 
 * @returns KunTrait
 */
KunTrait.prototype.addActor = function( actor_id ){
    this._actors.push({
        'actor_id': actor_id,
        'valueVar':0,
        'maxVar': 0,
    });
    return this;
};
/**
 * @returns Number[]
 */
KunTrait.prototype.actors = function(){
    return this._actors.map( actor => actor.actor_id );
};
/**
 * @returns String
 */
KunTrait.prototype.name = function(){
    return this._name;
};
/**
 * @returns Boolean
 */
KunTrait.prototype.reverse = function(){
    return this._reverse;
};
/**
 * @returns String
 */
KunTrait.prototype.title = function(){

    return this._title;
};
/**
 * @returns String
 */
KunTrait.prototype.display = function(){
    return this._display;
};
/**
 * @returns Number
 */
KunTrait.prototype.value = function(){
    return this._value;
};
/**
 * @returns Number
 */
KunTrait.prototype.max = function(){
    return this._max;
};
/**
 * @returns Number
 */
KunTrait.prototype.icon = function(){
    return this._icon;
};
/**
 * @returns Number
 */
KunTrait.prototype.color1 = function(){
    return this._color1;
};
/**
 * @returns Number
 */
KunTrait.prototype.color2 = function(){
    return this._color2;
};
/**
 * @param {Number} actor_id 
 * @returns Boolean
 */
KunTrait.prototype.has = function (actor_id) {
    return actor_id === 0 || this.actors().length === 0 || this.actors().includes(actor_id);
};
/**
 * @returns KunAttribute
 */
KunTrait.prototype.createAttribute = function(){
    return new KunAttribute( this );
};
/**
 * @param {KunTraitRule} event 
 * @returns KunTrait
 */
KunTrait.prototype.addRule = function( event ){
    if( event instanceof KunTraitRule ){
        this._rules.push( event );
    }
    return this;
};
/**
 * @returns KunTraitRule[]
 */
KunTrait.prototype.rules = function( ){
    return this._rules;
};
/**
 * @param {String} text 
 * @returns String
 */
KunTrait.ParseName = (text) => typeof text === 'string' ? text.toLowerCase().replace(/[\s\_]/, '-') : text;
/** 
 * @returns KunTrait
 */
KunTrait.Invalid = function () {
    return new KunTrait('__INVALID__');
};

/**
 * @param {KunTrait} trait 
 */
function KunAttribute( trait ){
    if( trait instanceof KunTrait ){
        this._name = trait.name();
        this._value = trait.value();
        this._range = trait.max();
        
        this.unbind();
    }
};
/**
 * @returns KunTrait
 */
KunAttribute.prototype.template = function(){
    return KunTraits.trait(this.name());
};
/**
 * @returns String
 */
KunAttribute.prototype.name = function(){
    return this._name;
};
/**
 * @param {Boolean} getDefault
 * @returns Number
 */
KunAttribute.prototype.range = function( getDefault ){
    return typeof getDefault === 'boolean' && getDefault ? this.template().max() : this._range;
};
/**
 * @returns Number
 */
KunAttribute.prototype.min = function(){
    return this.template().reverse() ? -this._range : 0;
};
/**
 * @param {Boolean} progress
 * @returns Number
 */
KunAttribute.prototype.value = function( progress ){
    return typeof progress === 'boolean' && progress && this.range() > 0 ? Math.abs(this.value()) / this.range() : this._value;
    //return typeof progress === 'boolean' && progress && this.range() > 0 ? Math.floor(  Math.abs(this.value()) / this.range() * 100) : this._value;
};
/**
 * @param {Number} value 
 * @returns Number
 */
KunAttribute.prototype.clamp = function(value){
    return Math.max(Math.min(value, this.range()),this.min())
};
/**
 * @param {Number} maximum 
 * @returns Number
 */
KunAttribute.prototype.setRange = function( maximum ){
    this._range = typeof maximum === 'number' && maximum > 0 ? maximum : 1;
    this.set( this.value()); //refresh the current value if range has been reduced then fire all bound events
    return this.range();
};
/**
 * @param {Number} value 
 * @returns Number
 */
KunAttribute.prototype.set = function( value ){
    value = this.clamp(value);
    if( this._value !== value ){
        this._value = value;
        //this.updateRules().updateBindings( );
        this.updateBindings( );
    }
    return this.value();
};
/**
 * @param {Number} actor_id
 * @returns KunAttribute
 */
KunAttribute.prototype.updateRules = function( actor_id ){
    //var rules = this.template().rules().filter( event => event.match( this.value() ) );
    var match = this.matchRule();
    if( match !== null ){
        //get always the last event from the list
        match.run( actor_id );
    }
    return this;
};
/**
 * @returns KunAttribute
 */
KunAttribute.prototype.unbind = function(){
    this._binding = [];
    return  this;
};
/**
 * 
 * @param {Number} value 
 * @param {Number} range 
 * @returns KunAttribute
 */
KunAttribute.prototype.bind = function( value , range ){
    this.unbind();
    this._binding.push( value );
    this._binding.push( range );
    return this.updateBindings( true );
};
/**
 * @param {Boolean} fullExport
 * @returns KunAttribute
 */
KunAttribute.prototype.updateBindings = function( fullExport ){
    return this.export(
        this.boundValue() > 0 ? this.boundValue() : 0,
        typeof fullExport === 'boolean' && fullExport && this.boundRange() > 0 ? this.boundRange() : 0,
    );
};
/**
 * @returns Number
 */
KunAttribute.prototype.boundValue = function(){
    return this._binding.length > 0 && this._binding[0] > 0 ? this._binding[0] : 0;
};
/**
 * @returns Number
 */
KunAttribute.prototype.boundRange = function(){
    return this._binding.length > 1 && this._binding[1] > 0 ? this._binding[1] : 0;
};
/**
 * @param {Number} valueVar
 * @param {Number} rangeVar
 * @returns KunAttribute
 */
KunAttribute.prototype.export = function( valueVar , rangeVar ){
    if( typeof valueVar === 'number' && valueVar > 0 ){
        $gameVariables.setValue( valueVar , this.value() );
        if( typeof rangeVar === 'number' && rangeVar > 0 ){
            $gameVariables.setValue( rangeVar , this.range() );
        }
    }

    return this;
};
/**
 * @returns Boolean
 */
KunAttribute.prototype.showValue = function(){
    return this.template().display() === KunTraits.DisplayType.COUNTER || this.template().display() === KunTraits.DisplayType.FULL;
};
/**
 * @returns Boolean
 */
KunAttribute.prototype.showGauge = function(){
    return this.template().display() === KunTraits.DisplayType.GAUGE || this.template().display() === KunTraits.DisplayType.FULL;
};
/**
 * @returns Boolean
 */
KunAttribute.prototype.visible = function(){
    return this.template().display() !== KunTraits.DisplayType.NONE;
};
/**
 * @returns Number
 */
KunAttribute.prototype.icon = function(){
    var rule = this.matchRule();
    return rule !== null && rule.icon() > 0 ? rule.icon() : this.template().icon();
};
/**
 * @returns String
 */
KunAttribute.prototype.title = function(){
    var rule = this.matchRule();
    return rule !== null && rule.title().length > 0 ? rule.title() : this.template().title();
};
/**
 * @returns Number[]
 */
KunAttribute.prototype.color = function(){
    var rule = this.matchRule();
    return  [
        rule !== null && rule.color1() >= 0 ? rule.color1() : this.template().color1(),
        rule !== null && rule.color2() >= 0 ? rule.color2() : this.template().color2()
    ];
};
/**
 * @returns KunTraitRule
 */
KunAttribute.prototype.matchRule = function(){
    var value = this.value();
    var rules = this.template().rules().filter( event => event.match( value ) );
    return rules.length > 0 ? rules[rules.length - 1] : null;
};


/**
 * @param {Number} value 
 * @param {String} operation 
 * @param {String} newTitle
 * @param {Number} icon
 * @param {Number} color1
 * @param {Number} color2
 * @param {String} media
 * @param {String} message
 */
function KunTraitRule(value, operation , newTitle , icon, color1, color2 , media , message ) {
    this._value = value || 0;
    this._operation = operation || KunTraitRule.Operations.Equal;
    
    this._action = null;

    this._icon = typeof icon === 'number' && icon > 0 ? icon : 0;
    this._title = typeof newTitle === 'string' && newTitle.length > 0 ? newTitle : '';
    this._color1 = typeof color1 === 'number' && color1 >= 0 ? color1 : -1;
    this._color2 = typeof color2 === 'number' && color2 >= 0 ? color2 : -1;
    this._message = message || '';
    this._media = media || '';

    this._addStates = []; //Array.isArray(addState) ? addState.map( state => parseInt(state)) : [];
    this._remStates = []; //Array.isArray(remState) ? remState.map( state => parseInt(state)) : [];
}
/**
 * @param {Number[]} states 
 * @return KunTraitRule
 */
KunTraitRule.prototype.addStates = function( states ){
    this._addStates = Array.isArray(states) ? states.map( state => parseInt(state ) ) : [];
    return this;
};
/**
 * @param {Number[]} states 
 * @return KunTraitRule
 */
KunTraitRule.prototype.dropStates = function( states ){
    this._remStates = Array.isArray(states) ? states.map( state => parseInt(state ) ) : [];
    return this;
};
/**
 * @returns String
 */
KunTraitRule.prototype.toString = function(){
    return `${this._operation}(${this._value})`;
};
/**
 * @returns Number
 */
KunTraitRule.prototype.value = function () {
    return this._value;
};
/**
 * @param {Number} value 
 * @returns Boolean
 */
KunTraitRule.prototype.match = function (value) {
    switch (this._operation) {
        case KunTraitRule.Operations.GreaterThan:
            return value > this.value();
        case KunTraitRule.Operations.GreaterEqual:
            return value >= this.value();
        case KunTraitRule.Operations.Equal:
            return value === this.value();
        case KunTraitRule.Operations.LessEqual:
            return value <= this.value();
        case KunTraitRule.Operations.LessThan:
            return value < this.value();
        default:
            return false;
    }
};
/**
 * 
 */
KunTraitRule.Operations = {
    'GreaterThan': 'greater',
    'GreaterEqual': 'greater-equal',
    'Equal': 'equal',
    'LessEqual': 'less-equal',
    'LessThan': 'less',
};
/**
 * @param {Number} actor_id 
 * @returns KunTraitRule
 */
KunTraitRule.prototype.run = function( actor_id ){
    return this.applyStates(actor_id).showMessage(actor_id).playMedia();
};
/**
 * @returns string
 */
KunTraitRule.prototype.media = function(){
    return this._media;
};
/**
 * @returns string
 */
KunTraitRule.prototype.message = function(){
    return this._message;
};
/**
 * @returns KunTraitRule
 */
KunTraitRule.prototype.playMedia = function(){
    if( this.media().length ){
        var pitch = Math.floor(Math.random() * 10) + 95;
        AudioManager.playSe({ 'name': this.media(), 'pan': 0, 'pitch': pitch, 'volume': 80 });    
    }
    return this;
};
/**
 * @param {Number} actor_id
 * @returns KunTraitRule
 */
KunTraitRule.prototype.showMessage = function( actor_id ){
    if( this.message().length && typeof kun_notify === 'function' ){
        kun_notify( typeof actor_id === 'number' && actor_id > 0 ? `\\N[${actor_id}] ` + this.message()  : this.message( ) );
    }
    return this;
};
/**
 * @returns KunTraitRule
 */
KunTraitRule.prototype.applyStates = function( actorId ){
    if( typeof actorId === 'number' && actorId > 0 ){
        this._addStates.forEach( function( state ){
            $gameActors.actor(actorId).addState( state );
        });
        this._remStates.forEach( function( state ){
            $gameActors.actor(actorId).removeState( state );
        });
    }
    return this;
};
/**
 * @returns String
 */
KunTraitRule.prototype.title = function(){
    return this._title;
};
/**
 * @returns Number
 */
KunTraitRule.prototype.icon = function(){
    return this._icon;
}
/**
 * @returns Number
 */
KunTraitRule.prototype.color1 = function(){
    return this._color1;
}
/**
 * @returns Number
 */
KunTraitRule.prototype.color2 = function(){
    return this._color2;
}



/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @param {Number} maximum 
 * @returns 
 */
function kun_trait_maximum(actor_id, attribute, maximum) {
    return actor_id > 0 ? $gameActors.actor(actor_id).setAttribute(attribute, maximum, true) : 0;
};
/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @param {Number} value 
 * @returns Number
 */
function kun_trait_sub(actor_id, attribute, value) {
    return kun_trait_add(actor_id, attribute, -value );
}
/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @param {Number} value 
 * @returns Number
 */
function kun_trait_add(actor_id, attribute, value) {
    if (actor_id) {
        var actor = $gameActors.actor(actor_id);
        if (actor !== null) {
            return $gameActors.actor(actor_id).updateAttribute(attribute, value);
        }
    }
    return 0;
}
/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @param {Number} value (optional)
 * @returns 
 */
function kun_trait_set(actor_id, attribute, value) {
    return actor_id > 0 ? $gameActors.actor(actor_id).setAttribute(attribute, value) : 0;
}
/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @param {Boolean} fullReset
 * @returns 
 */
function kun_trait_reset(actor_id, attribute, fullReset) {
    return actor_id > 0 ? $gameActors.actor(actor_id).resetAttribute(attribute, fullReset) : 0;
}
/**
 * @param {Number} actor_id 
 * @param {String} attribute 
 * @returns 
 */
function kun_trait(actor_id, attribute) {
    return actor_id > 0 ? $gameActors.actor(actor_id).attribute(attribute) : 0;
}
/**
 * Migrate from old plugin attributes
 * @param {String} oldTrait 
 * @param {String} newTrait 
 * @param {Boolean} removeOld
 */
function kun_trait_migrate( oldTrait , newTrait , removeOld ){
        $gameActors.list().filter( actor => actor !== null && actor.hasOwnProperty(oldTrait)).forEach( function( actor ){
            if( actor.hasAttribute(newTrait)){
                actor.setAttribute( newTrait , actor[oldTrait] );
                KunTraits.DebugLog( `${actor.name()} has upgraded to KunTraits ${oldTrait} > ${newTrait}(${actor.attribute(newTrait).value()})` );
                if(typeof removeOld === 'boolean' & removeOld ){
                    delete actor[ oldTrait ];
                }
            }
        });
}


(function () {

    KunTraits.Initialize();


    KunTraits_SetupActorAttributes();
    KunTraits_SetupWindows();
    KunTraits_SetupCommands();
})();




