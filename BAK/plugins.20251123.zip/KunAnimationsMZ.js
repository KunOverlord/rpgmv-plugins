//=============================================================================
// KunAnimations.js
//=============================================================================
/*:
 * @filename KunAnimations.js
 * @plugindesc Kun Interactive Picture Animations - Animate pictures with custom framesets and commands, now featuring an interactive framework to click over specific hotspots depending on the frameset running.
 * @version 1.81
 * @author KUN Overlord
 * @target MZ
 * 
 * @help
 * 
 * COMMANDS:
 * 
 *      KunAnimations set animation-name [setName]
 *          Switch animation frameset setName for animation-name
 *          If offsetVarx and offsetVarY are defined, both vars will apply the defined offset
 *          Use offsetScale % to scale the offset displacement for each coordinate
 * 
 *      KunAnimations reset animation-name [replay]
 *          Resets the given animation
 *          Restarts the controller if replay is required
 * 
 *      KunAnimations fps animation-name [fps] [import]
 *          Set custom frames per second for the playing animation-name. Define import to use a Game Variable to grab the fps from
 * 
 *      KunAnimations pause animation-name
 *          Pause animation-name if playing
 * 
 *      KunAnimations resume animation-name
 *          Resume animation-name if paused
 * 
 *      KunAnimations target [random]
 *          Update to the next target in the list of touched spots
 * 
 *      KunAnimations mode [capture|touch|disabled]
 *          Set the mouse interactive mode. Set touch to activate the interactive events. Set capture to describe hotspot areas in the console (requires debug mode on). Set disable to turn off the event listener.
 * 
 *      KunAnimations clear [targets | alias]
 *          Clear the current target queue
 *          Clear targets or defined aliases
 * 
 *      KunAnimations alias [alias_name] [animation_name]
 *          Create an alias for a specific animation controller to ease picture swapping with the same tags
 * 
 *      KunAnimations play [sound_bank_name] [wait_seconds] [random_elapsed_seconds]
 *          Play a sound bank selection by name
 *          Set wait seconds to include a time waiting pause before running the next events
 *          Add random elapsed seconds to define a randomized timespan
 * 
 *      KunAnimations wait [elapsed_seconds] [random_elapsed_seconds]
 *          Wait for elapsed seconds before running the next routines in the event editor
 *          Add random elapsed seconds to define a randomized timespan
 * 
 * 
 * HIERARCHY:
 * 
 *  -> Scene
 *  ----> AnimationLayer
 *  --------> TouchSpot
 * 
 *  - Animation Controllers
 *    defined by the Selected Picture File.
 *    Here you can setup the columns and rows, to properly display the frames.
 * 
 *  - Animation Frameset Groups
 *    A list of frames to play, with a custom FPS, behavior and looping iterations.
 * 
 *  - Touch Spots
 *    Every frameset animates a list of frames, but you can define on these a list of specific spots
 *    to click and cause a reaction, update a Game Variable, play a custom sound effect,
 *    and change to another specific frameset.
 * 
 * 
 * @param debug
 * @text Debug Level
 * @desc Show debug info. Activate Trace Log to detail the imports and exports of data.
 * @type select
 * @option TraceLog
 * @value 2
 * @option Enabled
 * @value 1
 * @option Disabled
 * @value 0
 * @default 0
 * 
 * @param defaultFPS
 * @text Master Frame Time
 * @desc default frame time
 * @type number
 * @min 1
 * @default 10
 * 
 * @param touchVarCounter
 * @text Touch Counter Variable
 * @desc This variable handles the counter of enqueued interactions performed by the player
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchVarLimit
 * @parent touchVar
 * @text Touch Limit Variable
 * @desc How many interactions can be saved in the queue. Can be updated in game to increase the touch events.
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchMode
 * @parent touchVar
 * @text Touch Mode Switch
 * @desc Use it to track if the interactive mode is enabled. Use KunAnimations mode touch|disable to change it.
 * @type switch
 * @default 0
 * 
 * @param touchWait
 * @parent touchVar
 * @text Touch Wait
 * @desc how many frames to wait until the touch effect is fired
 * @type number
 * @min 0
 * @default 0
 * 
 * @param touchX
 * @text Touch X Var
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchY
 * @text Touch Y Var
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param touchSfx
 * @text Default Touch SE
 * @desc Define a default sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param cancelSfx
 * @text Don't Touch SE
 * @desc Define a no touch sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param controllers
 * @type struct<Controller>[]
 * @text Animation Scenes
 * @desc Define the DataBase of Animation Scene Controllers (keep it clean and easy!!)
 * 
 * @param soundBank
 * @type struct<SoundBank>[]
 * @text Sound Banks
 * @desc Define the list of Sound Effect Reactions and specific Framesets
 */
/*~struct~Controller:
 *
 * @param source
 * @text Bitmap Source
 * @desc SpriteSheet
 * @type file
 * @required 1
 * @dir img/pictures/
 * 
 * @param cols
 * @text Columns
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param rows
 * @text Rows
 * @type number
 * @min 1
 * @max 32
 * @default 1
 * 
 * @param fps
 * @text Frames Per Second
 * @desc Default FPS for this frameset (leave to 0 to get master FPS as default)
 * @type number
 * @min 0
 * @default 0
 * 
 * @param framesets
 * @type struct<FrameSet>[]
 * @text Framesets
 * @desc Frameset Collection
 * 
 */
/*~struct~FrameSet:
 * 
 * @param name
 * @text Name
 * @type string
 * @default new-frameset
 * 
 * @param frames
 * @text Frames
 * @type number[]
 * @min 0
 * @desc List of frames to play in this animation
 * 
 * @param type
 * @text Animation Type
 * @type select
 * @option Forward (default)
 * @value forward
 * @option Reverse
 * @value reverse
 * @option Ping-Pong
 * @value ping-pong
 * @option Static
 * @value static
 * @default forward
 * 
 * @param fps
 * @text Frames Per Second
 * @desc Default FPS for this frameset (leave to 0 to get master FPS as default)
 * @type number
 * @min 0
 * @default 0
 * 
 * @param loops
 * @type number
 * @text Loops
 * @desc number of times the animation will play before switching to the next animation. Leave it to 0 for endless loops (no next animation)
 * @default 0
 * 
 * @param next
 * @text Next FrameSets
 * @type text[]
 * @desc Define the next frameset to call. If more than one specified, they will be randomly called
 * 
 * @param offsetX
 * @text X Offset
 * @type number
 * @default 0
 * 
 * @param offsetY
 * @text Y Offset
 * @type number
 * @default 0
 * 
 * @param spots
 * @type struct<TouchSpot>[]
 * @text Touch Spots
 * @desc Interactive Spots to fire events
 * @default []
 * 
 * @param bank
 * @text Sound Bank
 * @desc Type in a defined sound bank name to play a special sound set each time this frameset is started.
 * @type string[]
 * @default []
 * 
 */
/*~struct~TouchSpot:
 * 
 * @param name
 * @text Name
 * @type string
 * @default touch-me-here
 * 
 * @param x1
 * @text X1
 * @type number
 * @min 0
 * @desc X origin coordinate
 * 
 * @param y1
 * @text Y1
 * @type number
 * @min 0
 * @desc Y origin coordinate
 * 
 * @param x2
 * @text X2
 * @type number
 * @min 0
 * @desc X destination coordinate
 * 
 * @param y2
 * @text Y2
 * @type number
 * @min 0
 * @desc Y destination coordinate
 * 
 * @param behavior
 * @text Update Behavior
 * @desc How to modify the value on Game Variable ID
 * @type select
 * @option Add (default)
 * @value add
 * @option Substract
 * @value sub
 * @option Set
 * @value set
 * @option Set Frame
 * @value frame
 * @option Ignore
 * @value ignore
 * @default add
 * 
 * @param varId
 * @parent behavior
 * @text Game Variable ID
 * @type variable
 * @min 0
 * @desc Game Variable Mutator. Leave to 0 to not update variables.
 * @default 0
 * 
 * @param amount
 * @parent behavior
 * @text Update Amount
 * @type number
 * @min 1
 * @default 1
 * 
 * @param trigger
 * @text On Click
 * @type select
 * @option Instant Run
 * @value instant
 * @option Queue
 * @value queue
 * @option Next Frame
 * @value frame
 * @option Ignore
 * @value ignore
 * @default queue
 * 
 * @param next
 * @parent trigger
 * @text Switch Frameset
 * @desc Jump to Frameset on touched (allow mrandom options when more than 1)
 * @type text[]
 * @default []
 * 
 * @param sfx
 * @parent trigger
 * @text Touch Audio SFX
 * @desc Define a specific sound effect
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 */
/*~struct~SoundBank:
 *
 * @param name
 * @text Name
 * @type text
 * @default new-sound-bank
 * 
 * @param round
 * @text Rounds
 * @type number
 * @desc Play a sound selection every N frameset loops
 * @min 0
 * @max 10
 * @default 0
 * 
 * @param chance
 * @text Chance
 * @type number
 * @min 1
 * @max 100
 * @default 100
 * 
 * @param sfx
 * @text Sound Effect
 * @type file[]
 * @desc Add a selection of sound effects to play in this sound bank
 * @require 1
 * @dir audio/se/
 * 
 * @param volume
 * @text Volume
 * @desc Define a single volume value, a random volume interpolation among 2 values, or a random volume from 3 or more values.
 * @type number[]
 * @min 0
 * @max 100
 * @default ["90"]
 * 
 * @param pitch
 * @text Pitch
 * @desc Define a single pitch value, a random pitch interpolation among 2 values, or a random pitch from 3 or more values.
 * @type number[]
 * @min 50
 * @max 150
 * @default ["100"]
 * 
 * @param pan
 * @text Pan
 * @desc Define a single pan value, a random pan interpolation among 2 values, or a random pan from 3 or more values.
 * @type number[]
 * @min -100
 * @max 100
 * @default ["0"]
 * 
 * @param interrupt
 * @text Interrupt other SE
 * @desc Stop playing other Sound Effects when this bank plays a selection
 * @type Boolean
 * @default false
 *
 */

/**
 * @description KUN Modules
 * @type KUN
 */
var KUN = KUN || {};

/**
 * 
 * @returns 
 */
function KunSceneManager() {
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 * @returns KunSceneManager
 */
KunSceneManager.Initialize = function(){

    var parameters = this.PluginParameters()

    this._debug = parseInt( parameters.debug || KunSceneManager.DebugMode().Disabled );
    this._fps = parseInt(parameters.defaultFPS );
    this._touchVar = parseInt(parameters.touchVarCounter || 0 );
    this._limitVar = parseInt(parameters.touchVarLimit || 0 );
    this._touchMode = parseInt(parameters.touchMode || 0 );
    this._varX = parseInt(parameters.touchX || 0 );
    this._varY = parseInt(parameters.touchY || 0 );
    this._touchWait = parseInt(parameters.touchWait || 0 );
    this._sfx = {
        'touch': parameters.touchSfx || '',
        'cancel': parameters.cancelSfx || '',
    };


    this._mode = KunSceneManager.Mode().Disabled;
    this._soundBanks = {};
    this._controllers = {};
    this._overrides = {};
    this._alias = {};
    this._targets = [];

    var framesets = parameters.controllers.length > 0 ? JSON.parse(parameters.controllers ) : [];
    var banks = parameters.soundBank.length > 0 ? JSON.parse(parameters.soundBank) : [];

    return this.ImportFrameSets( framesets ).ImportBanks( banks );
};
/**
 * @returns Object
 */
KunSceneManager.DebugMode = function(){
    return {
        'Disabled':0,
        'Enabled': 1,
        'TraceLog': 2,
    };
};
    /**
     * @returns Boolean
     */
    KunSceneManager.debug = function( level ){
        if( typeof level === 'number' && level > 0 ){
            return this._debug >= level;
        }
        return this._debug > KunSceneManager.DebugMode().Disabled;
    };
    /**
     * @param {Boolean} list 
     * @returns Object | Object[]
     */
    KunSceneManager.banks = function( list ){
        return typeof list === 'boolean' && list ? Object.values( this._soundBanks ) : this._soundBanks;
    };
    /**
     * @param {String} bank 
     * @returns Boolean
     */
    KunSceneManager.hasBank = function( bank ){
        return typeof bank === 'string' && bank.length > 0 && this._soundBanks.hasOwnProperty( bank );
    };
    /**
     * @param {KunSoundBank} bank 
     * @returns KunSceneManager
     */
    KunSceneManager.addBank = function( bank){
        if( bank instanceof KunSoundBank && !this.hasBank( bank ) ){
            this._soundBanks[ bank.name() ] = bank;
        }
        return this;
    };
    /**
     * @param {String} bank 
     * @returns KunSceneManager
     */
    KunSceneManager.playBank = function( bank ){
        if( this.hasBank( bank ) ){
            this.banks()[bank].play();
        }
        return this;
    };
    /**
     * @param {String} bank 
     * @returns KunSoundBank
     */
    KunSceneManager.soundBank = function( bank ){
        return this.hasBank( bank ) ? this.banks()[bank] : KunSoundBank.Empty();
    };
    /**
     * 
     * @param {String} alias 
     * @param {String} original 
     * @returns KunSceneManager
     */
    KunSceneManager.setAlias = function( alias , original ){
        this._alias[alias] = original;
        return this;
    };
    /**
     * @returns Number
     */
    KunSceneManager.elapsed = function( inMs ){
        return typeof inMs === 'boolean' && inMs ? this._touchWait * 1000 : this._touchWait;
    };
    /**
     * @param {String} alias 
     * @returns String
     */
    KunSceneManager.getAlias = function( alias ){
        return this._alias.hasOwnProperty(alias) ? this._alias[alias] : alias;
    }
    /**
     * 
     * @returns KunSceneManager
     */
    KunSceneManager.clearAlias = function(){
        this._alias = {};
        return this;
    };
    /**
     * @param {String} mode 
     * @returns KunSceneManager
     */
    KunSceneManager.setMode = function( mode ){
        this._mode = mode;
        switch( this._mode ){
            case KunSceneManager.Mode().Capture:
            case KunSceneManager.Mode().Touch:
                this.unlock(true);
                break;
            case KunSceneManager.Mode().Disabled:
            default:
                this.clearTargets().lock();
                break;
        }
        return this;
    };
    /**
     * @returns Object
     */
    KunSceneManager.dump = function(){
        return this;
    }
    /**
     * @returns String
     */
    KunSceneManager.sfx = function( name ){
        return typeof name === 'string' && name.length && this._sfx.hasOwnProperty(name) ? this._sfx[name] : this._sfx.touch;
    };
    /**
     * @returns Number
     */
    KunSceneManager.limit = function(){
        return this._limitVar > 0 ? $gameVariables.value( this._limitVar ) : 1;
    };
    /**
     * @param {Boolean} unlock
     * @returns KunSceneManager
     */
    KunSceneManager.unlock = function( unlock ){
        if( this._touchMode ){
            $gameSwitches.setValue( this._touchMode, typeof unlock === 'boolean' && unlock );
        }
        return this;
    };
    /**
     * @returns KunSceneManager
     */
    KunSceneManager.lock = function( ){
        return this.unlock(false);
    };
    /**
     * @returns Boolean
     */
    KunSceneManager.locked = function(){
        return this._mode === KunSceneManager.Mode().Disabled;
        return this._touchMode > 0 && !$gameSwitches.value(this._touchMode);
    };
    /**
     * @param {String} name 
     * @returns Object {X,Y}
     */
    KunSceneManager.offset = function( name ){
        var picture = this.get(name);
        if( picture !== null ){
            var fs = picture.current();
            if( fs !== null ){
                return {
                    'x':fs.offsetX(),
                    'y':fs.offsetY()
                };
            }
        }
        return {'x':0,'y':0};
    };
    /**
     * @param {String} controller
     * @param {String} spot
     * @param {Number} x 
     * @param {Number} y 
     * @returns Boolean
     */
    KunSceneManager.enqueue = function( controller , spot , x , y  ){
        if( this.targets().length < this.limit() ){
            this.targets().push({
                'controller':controller,
                'spot': spot,
                'x':x,
                'y':y,
                //'sx': typeof sx === 'number' && sx > 0 ? sx : x,
                //'sy': typeof sy === 'number' && sy > 0 ? sy : y,
            });
            this.updateTouchPoints( this.countTargets()).playFx();
            return true;
        }
        else{
            KunSceneManager.PlayFX(this.sfx('cancel'));
        }
        return false;
    };
    /**
     * @returns Array
     */
    KunSceneManager.targets = function(){
        return this._targets;
    };
    /**
     * @returns Number
     */
    KunSceneManager.countTargets = function(){
        return this._targets.length;
    }
    /**
     * 
     * @returns KunSceneManager
     */
    KunSceneManager.clearTargets = function(){
        this._targets = [];
        return this.updateTouchPoints();
    };
    /**
     * @param {Boolean} random 
     * @returns Object
     */
    KunSceneManager.nextSpot = function( random ){
        var spot = typeof random === 'boolean' && random && this.countTargets() > 1 ?
            this.targets().splice( Math.floor(Math.random() * this.countTargets( ) ), 1) :
            this.targets().shift();
        return Array.isArray(spot) ? spot[0] : spot;
    };
    /**
     * @param {Boolean} random
     * @returns KunSceneManager
     */
    KunSceneManager.target = function( random ){
        if(this.countTargets()){
            var spot = this.nextSpot( random );
            //console.log(spot);
            var controller = this.get(spot.controller);
            if( controller !== null ){
                var fs = controller.current();
                if( fs !== null ){
                        var target = fs.getSpot(spot.spot);
                        if( target !== null ){
                            target.update();
                            //export X and Y positions
                            this.exportPosition( spot.x , spot.y ).wait();
                            //jump to next frameset (if any)
                            controller.changeFrameSet( target.next() , true );
                        }
                }
                else{
                    KunSceneManager.DebugLog(`Invalid FrameSet ${spot.spot}`);    
                }
            }
            else{
                KunSceneManager.DebugLog(`Invalid Controller ${spot.controller}`);
            }
        }    
        return this.updateTouchPoints(this.countTargets());
    };
    /**
     * 
     * @returns KunSceneManager
     */
    KunSceneManager.wait = function(){
        for( var t = 0 ; t < this.elapsed(true) ; t++ );
        return this;
    };
    /**
     * @param {Number} x 
     * @param {Number} y 
     * @returns KunSceneManager
     */
    KunSceneManager.exportPosition = function( x  , y ){
        if( this._varX > 0 ){
            $gameVariables.setValue(this._varX,x);
        }
        if( this._varY > 0 ){
            $gameVariables.setValue(this._varY,y);
        }
        //KunSceneManager.DebugLog(`Event Clicked on ${x},${y}`);
        return this;
    };
    /**
     * @param {Number} counter 
     * @returns KunSceneManager
     */
    KunSceneManager.updateTouchPoints = function( counter ){
        if( this._touchVar > 0 ){
            $gameVariables.setValue(this._touchVar , counter  || 0 );
        }
        return this;
    };
    /**
     * @returns Boolean
     */
    KunSceneManager.canCapture = function(){
        return this._mode === KunSceneManager.Mode().Capture;
    };
    /**
     * @returns Boolean
     */
    KunSceneManager.canTouch = function(){
        return this._mode === KunSceneManager.Mode().Touch && !this.locked();
    };
    /**
     * @returns String
     */
    KunSceneManager.mode = function(){
        return this._mode;
    };
    /**
     * @returns Number
     */
    KunSceneManager.defaultFps = function(){
        return this._fps;
    };

    /**
     * @param {KunAnimationScene} controller 
     * @returns KunSceneManager
     */
    KunSceneManager.addController = function( controller ){
        if( controller instanceof KunAnimationScene && !this.has(controller.name()) ){
            this._controllers[controller.name()] = controller;
        }
        return this;
    };
    /**
     * @param {String} name 
     * @returns Boolean
     */
    KunSceneManager.has = function( name ){
        return this._controllers.hasOwnProperty( name );
    }
    /**
     * @param {String} name 
     * @returns Boolean
     */
    KunSceneManager.isPlaying = function( name ){
        return this.has( name ) && this.get( name ).playing();
    };
    /**
     * @returns Array
     */
    KunSceneManager.controllers = function( list ){
        return typeof list === 'boolean' && list ? Object.values( this._controllers ) : this._controllers;
    };
    /**
     * @param {String} pictureName 
     * @returns {KunAnimationScene}
     */
    KunSceneManager.get = function( pictureName ){
        return this.has( pictureName ) ? this._controllers[pictureName] : null;
    }
    /**
     * @param {String} pictureName 
     * @returns {KunSceneManager}
     */
    KunSceneManager.stop = function( pictureName ){
        return this;
    };
    /**
     * @param {String} picturename 
     * @param {Boolean} replay
     * @returns KunSceneManager
     */
    KunSceneManager.reset = function( picturename , replay  ){
        if( this.has( picturename)){
            this.get(picturename).reset( typeof replay === 'boolean' && replay );
        }
        return this;
    }
    /**
     * @param {String} pictureName 
     * @returns {KunSceneManager}
     */
    KunSceneManager.resume = function( pictureName ){
        return this;
    };

    /**
     * @param {String} pictureName 
     * @param {String} frameSetName 
     * @returns {KunSceneManager}
     */
    KunSceneManager.overrideSet = function( pictureName , frameSetName ){

        if( this.isPlaying( pictureName)){
            this._controllers[ pictureName ].changeFrameSet(frameSetName, true ) ;
            this.updateTouchPoints(this.countTargets());
        }

        return this;
    };
    /**
     * 
     * @param {String} pictureName 
     * @param {Number} fps 
     * @returns {KunSceneManager}
     */
    KunSceneManager.overrideFPS = function( pictureName , fps ){
        if( this.isPlaying( pictureName ) ){
            this._controllers[ pictureName ].setFps( fps );
        }
        return this;
    };
    /**
     * @param {String} sfx
     * @returns KunSceneManager
     */
    KunSceneManager.playFx = function( sfx ){
        KunSceneManager.PlayFX( typeof sfx === 'string' && sfx.length ? sfx : this.sfx() );
        return this;
    };

KunSceneManager.PluginParameters = function(){
    return PluginManager.parameters('KunAnimations');
};


/**
 * @param {Object[]} input 
 * @returns KunSceneManager
 */
KunSceneManager.ImportFrameSets = function( input ){

    var _spotCounter = 0;
    var _layerCounter = 0;
    var _pictureCounter = 0;

    ( input ).map( ctl => ctl.length > 0 ? JSON.parse( ctl ) : null ).forEach(function( ctl ){
        if( ctl !== null ){
            _pictureCounter++;
            var _controller = new KunAnimationScene(ctl.source,parseInt(ctl.cols),parseInt(ctl.rows),parseInt(ctl.fps || 0));
            var _framesets = ctl.framesets.length > 0 ? JSON.parse(ctl.framesets) : [];
            ( _framesets ).map( fs => fs.length > 0 ? JSON.parse(fs) : null ).forEach(function(fs){
                if( fs !== null ){
                    _layerCounter++;
                    var _frameSet = new KunAnimationLayer(
                        fs.name ,
                        fs.type ,
                        parseInt(fs.fps) ,
                        parseInt( fs.loops),
                        fs.next.length > 0 ? JSON.parse(fs.next) : '' ,
                        typeof fs.bank === 'string' && fs.bank.length > 0 ?  (/^\[.*\]$/.test(fs.bank) ? JSON.parse(fs.bank) : [fs.bank])   : [], //Match fix to the next update and backwards compatibility with a single string value
                        fs.offsetX, fs.offsetY );
                    ( fs.frames.length > 0 ? JSON.parse(fs.frames) : [] ).map( frame => parseInt( frame ) ).forEach(function( frame ){
                        _frameSet.add( frame );
                    });
                    //leave this here for debugging.
                    if( KunSceneManager.debug(KunSceneManager.DebugMode().TraceLog) ){
                        KunSceneManager.DebugLog(`Reading ${ctl.source}.${fs.name}`);
                    }

                    var _spots = fs.spots.length > 0 ? JSON.parse(fs.spots) : [];
                    _spotCounter += _spots.length;

                    ( _spots ).map( s => s.length > 0 ? JSON.parse(s) : null ).forEach(  function( s ){
                        var spot = new KunTouchSpot(
                            s.name,
                            s.x1,
                            s.y1,
                            s.x2,
                            s.y2,
                            s.varId,
                            s.amount || 1,
                            s.behavior || KunTouchSpot.Behavior.Increase,
                            s.trigger || KunTouchSpot.Trigger.Queue,
                            s.sfx,
                            s.next.length > 0 ? JSON.parse(s.next) : []  );
                        _frameSet.registerSpot(spot);
                    });
                    //KunSceneManager.DebugLog( _frameSet.spots() );

                    if( _frameSet.count() > 0 ){
                        _controller.add( _frameSet );
                    }
                }
            });

            if( _controller.countFrames() ){
                KunSceneManager.addController( _controller );
            }
        }
    });
                    //leave this here for debugging.
    if( KunSceneManager.debug(KunSceneManager.DebugMode().TraceLog) ){
        KunSceneManager.DebugLog(`Imported a total of ${_pictureCounter} animated pictures, ${_layerCounter} animation layers and ${_spotCounter} hotspots`);
    }

    return this;
};
/**
 * @param {Object[]} input 
 * @returns KunSceneManager
 */
KunSceneManager.ImportBanks = function( input ){
    (input).map( sb => sb.length > 0 ? JSON.parse( sb ) : null ).forEach( function( bank ){
        var sb = new KunSoundBank( bank.name , bank.chance , bank.interrupt === 'true' , parseInt( bank.round  ||  0 ) );
        (bank.pitch.length > 0 ? JSON.parse(bank.pitch) : []).map(pitch => parseInt( pitch )).forEach(function( pitch ){
            sb.addPitch( pitch );
        });
        (bank.pan.length > 0 ? JSON.parse(bank.pan) : []).map(pan => parseInt( pan )).forEach(function( pan ){
            sb.addPan( pan );
        });
        (bank.volume.length > 0 ? JSON.parse(bank.volume) : []).map(volume => parseInt( volume )).forEach(function( volume ){
            sb.addVol( volume );
        });
        (bank.sfx.length > 0 ? JSON.parse(bank.sfx) : []).forEach(function( se ){
            sb.addSe( se );
        });
        KunSceneManager.addBank( sb );
    });
    return this;
};
/**
 * @returns Object
 */
KunSceneManager.Mode = function(){
    return {
        'Disabled': 'disabled',
        'Touch': 'touch',
        'Capture': 'capture',
    };
};
KunSceneManager.Behavior = {
    'Forward': 'forward',
    'Reverse': 'reverse',
    'PingPong': 'ping-pong',
    'Static': 'static',
};

KunSceneManager.Capture = [];
/**
 * @param {String} sfx 
 * @param {Number} pitch
 * @param {Number} pan
 */
KunSceneManager.PlayFX = function( sfx , pitch , pan ){
        if(  sfx.length ){
            if( typeof pitch !== 'number' ){
                pitch = 90 + Math.floor(Math.random() * 20);
            }
            if( typeof pan !== 'number' ){
                pan = Math.floor(Math.random() * 20) - 10;
            }
            this.AudioManager( sfx , 100 , pitch , pan );
            //AudioManager.playSe({name: sfx , pan: pan, pitch: pitch, volume: 100});
        }
};
/**
 * 
 * @param {String} se 
 * @param {Number} volume 
 * @param {Number} pitch 
 * @param {Number} pan 
 * @param {Boolean} interrupt
 */
KunSceneManager.AudioManager = function( se , volume , pitch , pan , interrupt ){
    if( se.length ){
        if( typeof interrupt === 'boolean' && interrupt ){
            AudioManager.stopSe();
        }
        //KunSceneManager.DebugLog( `Playing ${se} at vol ${volume}, pitch ${pitch} and pan ${pan} ${interrupt}` );
        AudioManager.playSe({name: se , pan: pan || 0, pitch: pitch || 100, volume: volume || 90 } );
    }
};
/**
 * @param {String} message 
 */
KunSceneManager.DebugLog = function( message ){
    if( KunSceneManager.debug() ){
        console.log( typeof message === 'object' ? message : `[ KunSceneManager ] ${message.toString()}` );
    }
};
/**
 * 
 */
function KunAnimationScene(){
    this.initialize.apply( this , arguments );
}

KunAnimationScene.prototype.initialize = function( name , cols , rows , fps ){

    this._name = name;
    this._cols = cols || 1;
    this._rows = rows || 1;
    this._frameSets = {};
    this._elapsed = 0;
    this._loopCount = 0;
    this._forward = true;
    this._playing = false;

    this._index = 0;
    this._current = '';

    //this one can be overriden
    this._fps = fps || KunSceneManager.defaultFps();
    this._touching = false;
    //this._touch = [];
    //use this to capture coordinates in Dev Mode
    this._capture = [];
};
KunAnimationScene.prototype.toString = function(){ return this.name(); };
/**
 * @returns String
 */
KunAnimationScene.prototype.name = function(){ return this._name; };
/**
 * 
 * @param {String} name 
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.duplicate = function( name ){
    var _copy = { ...this };
    _copy._name = name;
    return _copy;
};
/**
 * @returns KunAnimationLayer
 */
KunAnimationScene.prototype.current = function(){ return this.has(this._current) ? this._frameSets[this._current] : null; };
/**
 * @returns Boolean
 */
KunAnimationScene.prototype.canTouch = function(){
    var current = this.current();
    return current !== null ? current.canTouch() : false;
};
/**
 * 
 * @param {Number} x 
 * @param {Number} y 
 * @returns KunTouchSpot
 */
KunAnimationScene.prototype.getTouched = function( x , y ){

    var current = this.current();
    return current !== null ? current.touchSpot( x , y ) : null;
};
/**
 * 
 * @param {Number} x 
 * @param {Number} y 
 * @param {Number} sx
 * @param {Number} sy
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.touch = function( x  , y , sx , sy){
    //console.log(`${x},${y} (${sx},${sy})`);
    //console.log(this.current().name());
    var spot = this.getTouched(x , y);
    //console.log( spot );
    if( spot !== null ){
        switch( spot.trigger() ){
            case KunTouchSpot.Trigger.Queue:
                //KunSceneManager.enqueue( `${this.name()}.${spot.name()}` , x , y , sx , sy );
                KunSceneManager.enqueue( this.name() , spot.name() , sx , sy );
                break;
            case KunTouchSpot.Trigger.Instant:
                //perform spot update
                spot.update();
                //export X and Y positions
                KunSceneManager.exportPosition( sx , sy );
                //jump to next frameset (if any)
                this.changeFrameSet( spot.next(), true );
                break;
            case KunTouchSpot.Trigger.Frame:
                this.changeFrameSet(spot.next());
                spot.setValue(this.current().first()).touchSfx();
                break;
        }
        
    }
    return this;
};
/**
 * @returns Array
 */
KunAnimationScene.prototype.capture = function(){
    return this._capture;
};
/**
 * @param {Number} x 
 * @param {Number} y 
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.captureFrom = function( x , y ){
    this._capture = [x , y];
    return this;
};
/**
 * 
 * @param {Number} x 
 * @param {Number} y 
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.captureTo = function( x , y ){
    if( this._capture.length === 2 ){
        this._capture.push(x);
        this._capture.push(y);
        //sort and arrrange
        if( this._capture[0] > this._capture[2]){
            var mx = this._capture[0];
            this._capture[0] = this._capture[2];
            this._capture[2] = mx;
        }
        if( this._capture[1] > this._capture[3]){
            var my = this._capture[1];
            this._capture[1] = this._capture[3];
            this._capture[3] = my;
        }
        KunSceneManager.DebugLog( `Capture Coords: ${this._capture.join( ' ' )}` );
    }
    return this.clearCapture();
};
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.clearCapture = function(){
    this._capture = [];
    return this;
};
/**
 * @returns Boolean
 */
KunAnimationScene.prototype.playing = function(){ return this._playing; }
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.stop = function(){
    this._playing = false;
    return this;
};
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.resume = function(){
    this._playing = true;
    return this;
};
/**
 * @returns Number
 */
KunAnimationScene.prototype.getFrame = function(){
    return this.has(this._current) ? this._frameSets[this._current].getFrame( this._index) : 0;
};
/**
 * @returns Number
 */
KunAnimationScene.prototype.index = function(){ return this._index; }
/**
 * @returns Number
 */
KunAnimationScene.prototype.cols = function(){ return this._cols; }
/**
 * @returns Number
 */
KunAnimationScene.prototype.rows = function(){ return this._rows; }
/**
 * @returns Number
 */
KunAnimationScene.prototype.totalFrames = function(){ return this._cols * this._rows; };
/**
 * @param {String} fs 
 * @returns Boolean
 */
KunAnimationScene.prototype.has = function( fs ){ return fs.length > 0 && this._frameSets.hasOwnProperty( fs ); }
/**
 * @param {KunAnimationLayer} frameSet 
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.add = function( frameSet ){
    if( frameSet instanceof KunAnimationLayer ){
        this._frameSets[ frameSet.name() ] = frameSet;
        if( this._current.length === 0 ){
            this.changeFrameSet( frameSet.name());
            //this._current = frameSet.name();
        }
    }
    return this;
};
/**
 * @param {Number} fps 
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.setFps = function( fps ){
    switch( true ){
        case typeof fps === 'number' && fps > 0:
            this._fps = fps;
            break;
        case this.has(this._current):
            this._fps = this._frameSets[this._current].fps();
            break;
        default:
            this._fps = KunSceneManager.defaultFps();
            break;
    }
    return this;
};
/**
 * @param {Boolean} list 
 * @returns KunAnimationLayer[] | Object
 */
KunAnimationScene.prototype.frameSets = function( list ){
    return typeof list === 'boolean' && list ? Object.values( this._frameSets ) : this._frameSets;
}
/**
 * @returns Boolean
 */
KunAnimationScene.prototype.empty = function(){
    return this.frameSets(true).length === 0;
};
/**
 * @returns {Number}
 */
KunAnimationScene.prototype.countFrames = function(){
    return this.has(this._current) ? this.current().count() : 0;
};
/**
 * @param {String} fs 
 * @param {Boolean} play
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.changeFrameSet = function( setName , play ){
    if( this.has( setName ) ){
        this._current = setName;
        return this.setFps().reset( typeof play === 'boolean' && play );
    }
    return this;
}
/**
 * @param {Boolean} replay
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.next = function( replay ){
    var next = this.has(this._current) ? this.current().getNext() : '';
    if( next.length > 0 ){
        return this.changeFrameSet( next , true );
    }
    if( typeof replay === 'boolean' && replay ){
        //return this.changeFrameSet( this._current , true );
        return this.reset(true);
    }
    else{
        this._playing = false;
    }
    return this;
};
/**
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.first = function(){
    if(!this.empty()){
        return this.changeFrameSet(this.frameSets(true)[0].name(), true );
    }
    return this;
};
/**
 * @param {Boolean} play
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.reset = function( play ){
    this._loopCount = this.current().loops();
    switch(this.current().behavior()){
        case KunSceneManager.Behavior.Reverse:
            this._forward = false;
            this._index = this.countFrames() - 1;
            break;
        case KunSceneManager.Behavior.Forward:
            this._forward = true;
            break;
        case KunSceneManager.Behavior.PingPong:
            this._forward = true;
            break;
        case KunSceneManager.Behavior.Static:
            break;
    }
    this._playing = (typeof play === 'boolean' && play ) || this._playing;
    return this.playBank();
}
/**
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.playBank = function(){
    if( this.playing() ){
        this.current().playBank();
    }
    return this;
};
/**
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.playBankByRound = function( loop ){
    if( this.playing() ){
        this.current().getSoundBank().playRound( loop );
    }
    return this;
};
/**
 * @returns Number
 */
KunAnimationScene.prototype.FPS = function(){
    return this._fps;
};
/**
 * @returns {KunAnimationScene}
 */
KunAnimationScene.prototype.update = function(){
    if( this.playing() ){
        this._elapsed = ++this._elapsed % this.FPS();
        if( this._elapsed === 0 ){
            switch( this.current().behavior() ){
                case KunSceneManager.Behavior.PingPong:
                    this.updatePingPong();
                    break;
                case KunSceneManager.Behavior.Reverse:
                    this.updateReverse();
                    break;
                case KunSceneManager.Behavior.Static:
                    //do not change
                    break;
                case KunSceneManager.Behavior.Forward:
                default:
                    this.updateForward();
                    break;
            }
            //this.changeFrameSet(KunSceneManager.getOverride(this._name));
    
            return true;
        }    
    }
    return false;
};
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.updatePingPong = function(){
    var frameCount = this.countFrames();
    if( this._forward ){
        this._index = ++this._index % frameCount;
        if( this._index === frameCount - 1 ){
            this._forward = false;
        }
    }
    else if(this._index > 0){
        //reverse
        this._index--;
    }
    //after complete the round
    if( this._index === 0 && !this._forward ){
        if( this._loopCount > 0 ){
            this._loopCount--;
            if( this._loopCount === 0 ){
                //change state
                return this.next(true);
            }
            this.playBankByRound(this._loopCount);
        }
        this._forward = true;
    }
    return this;
}
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.updateReverse = function(){
    if( this._index > 0 ){
        this._index--;
    }
    else{
        if( this._loopCount > 0 ){
            this._loopCount--;
            if( this._loopCount === 0 ){
                //change state
                return this.next(true);
            }
            this.playBankByRound(this._loopCount);
        }
        this._index = this.countFrames()-1;
    }
    return this;
}
/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.updateForward = function(){
    var frameCount = this.countFrames()
    this._index = ++this._index % frameCount;
    if( this._index === frameCount - 1 ){
        if( this._loopCount > 0 ){
            this._loopCount--;
            if( this._loopCount === 0 ){
                //change state
                return this.next(true);
            }
            this.playBankByRound(this._loopCount);
        }
        this._index = 0;
    }
    return this;
}

/**
 * @returns KunAnimationScene
 */
KunAnimationScene.prototype.instance = function(){
    var copy = new KunAnimationScene( this._name, this._cols,this._rows );
    copy._current = this._current;
    copy._frameSets = this._frameSets;
    return copy.reset();
};
KunAnimationScene.prototype.dump = function(){
    return this;
};





function KunAnimationLayer(){ this.initialize.apply( this , arguments ); };
//KunAnimationLayer.prototype = Object.create(Sprite.prototype);
/**
 * 
 * @param {String} name 
 * @param {String} type 
 * @param {Number} fps 
 * @param {Number} loops 
 * @param {String} next 
 * @param {String} bank
 * @param {Number} offsetX
 * @param {Number} offsetY
 */
KunAnimationLayer.prototype.initialize = function( name , type , fps, loops , next , bank , offsetX , offsetY ){
    this._name = name.toLowerCase().replace(/[\s\_]/,'-');
    this._fps = typeof fps === 'number' && fps > 0 ? fps : 0;
    this._frames = [];
    this._type = type || KunSceneManager.Behavior.Default;
    this._loops = loops || 0;
    this._offset = {'x': offsetX || 0,'y': offsetY || 0};
    this._spots = {
        //interactive spots to touch
    };
    this._next = Array.isArray( next ) ? next  : ( typeof next === 'string' && next.length ? [next] : [] );
    this._bank = Array.isArray(bank) ? bank : ( typeof bank === 'string' && bank.length ? [bank] : []) ;
};
/**
 * @param Number scale
 * @returns Number
 */
KunAnimationLayer.prototype.offsetX = function( scale ){
    if( typeof scale !== 'number'){
        scale = 1;
    }
    return parseInt( this._offset.x * scale );
};
/**
 * @param Number scale
 * @returns Number
 */
KunAnimationLayer.prototype.offsetY = function( scale ){
    if( typeof scale !== 'number'){
        scale = 1;
    }
    return parseInt( this._offset.y * scale );
};
/**
 * @returns Boolean
 */
KunAnimationLayer.prototype.canTouch = function(){
    return this.spots(true).length > 0;
};
/**
 * 
 * @param {KunTouchSpot} spot 
 * @returns KunAnimationLayer
 */
KunAnimationLayer.prototype.registerSpot = function( spot ){

    if( spot instanceof KunTouchSpot && !this._spots.hasOwnProperty(spot.name()) ){
        //
        this._spots[spot.name()] = spot;
    }

    return this;
};
/**
 * List all spots as array or object ids
 * @param {Boolean} list 
 * @returns Object | KunTouchSpot[]
 */
KunAnimationLayer.prototype.spots = function( list ){
    return typeof list === 'boolean' && list ? Object.values( this._spots ) : this._spots;
}
/**
 * @param {String} spot 
 * @returns Boolean
 */
KunAnimationLayer.prototype.hasSpot = function( spot ){
    return this._spots.hasOwnProperty(spot);
}
/**
 * @param {String} spot 
 * @returns KunTouchSpot
 */
KunAnimationLayer.prototype.getSpot = function( spot ){
    return this.hasSpot(spot) ? this._spots[spot] : null;
}
/**
 * Check if any spot was touched
 * @param {Number} x 
 * @param {Number} y 
 * @returns KunTouchSpot 
 */
KunAnimationLayer.prototype.touchSpot = function( x , y ){
    var hotspots = this.spots(true);
    for( var i in hotspots ){
        //hotspots[i].test( x , y );
        if( hotspots[i].touched( x , y ) ){
            //console.log( `${hotspots[i]} touched on ${x},${y}` );
            return hotspots[i];
        }
    }
    return null;
};
/**
 * @returns String
 */
KunAnimationLayer.prototype.behavior = function(){
    return this._type;
};
/**
 * @param {Number} frame 
 * @returns KunAnimationLayer
 */
KunAnimationLayer.prototype.add = function( frame ){
    this._frames.push( frame );
    return this;
};
/**
 * @returns Number
 */
KunAnimationLayer.prototype.fps = function(){
    return this._fps > 0 ? this._fps : KunSceneManager.defaultFps();
};
/**
 * @returns Number
 */
KunAnimationLayer.prototype.loops = function(){
    return this._loops;
};
/**
 * @returns Number
 */
KunAnimationLayer.prototype.frames = function( ){
    return this._frames.length > 0 ? this._frames : [0];
}
/**
 * @returns Number
 */
KunAnimationLayer.prototype.first = function(){
    return this.frames().length > 0 ? this.frames()[0] : 0;
};
KunAnimationLayer.prototype.getFrame = function( index ){
    return this._frames.length > index ? this._frames[index] : 0;
};
KunAnimationLayer.prototype.count = function(){
    return this.frames().length;
};
KunAnimationLayer.prototype.name = function(){
    return this._name;
};
/**
 * @returns String
 */
KunAnimationLayer.prototype.getNext = function(){
    var next = this._next.length > 1 ? Math.floor( Math.random() * this._next.length ) : 0;    
    return this._next.length > 0 ? this._next[ next ] : '';
}
/**
 * @returns Boolean
 */
KunAnimationLayer.prototype.hasSoundBank = function(){
    return this._bank.length > 0;
};
/**
 * @returns String
 */
KunAnimationLayer.prototype.selectSoundBank = function(){
    if( this.hasSoundBank() ){
        var selection = this._bank.length > 1 ? Math.floor(Math.random() * this._bank.length) : 0;
        //KunSceneManager.DebugLog( `Playing ${this._bank[selection]}` );
        return this._bank[selection];
    }
    return '';
    return this.hasSoundBank() ? ( this._bank.length > 1 ? Math.floor(Math.random() * this._bank.length) : this._bank[0] ) : '';
};
/**
 * @returns KunAnimationLayer
 */
KunAnimationLayer.prototype.playBank = function(){
    KunSceneManager.playBank( this.selectSoundBank() );
    return this;
};
/**
 * @returns KunAnimationLayer
 */
KunAnimationLayer.prototype.getSoundBank = function( ){
    return KunSceneManager.soundBank( this.selectSoundBank() );
};

/**
 * 
 * @param {String} name 
 * @param {Number} x1 
 * @param {Number} y1 
 * @param {Number} x2 
 * @param {Number} y2 
 * @param {Number} varId
 * @param {String} behavior
 * @param {String} sfx
 * @param {String} next
 */
function KunTouchSpot( name , x1 , y1 , x2 , y2 , varId , amount , behavior, trigger, sfx , next  ){

    this._name = name;
    this._x1 = parseInt( x1 );
    this._y1 = parseInt(y1);
    this._x2 = parseInt(x2);
    this._y2 = parseInt(y2);
    this._varId = parseInt(varId || 0 );
    this._amount = typeof amount === 'number' && amount > 0 ? amount : 1;
    this._behavior = typeof behavior === 'string' && behavior.length ? behavior : KunTouchSpot.Behavior.Add;
    this._trigger = typeof trigger === 'string' && trigger.length ? trigger : KunTouchSpot.Trigger.Queue;
    this._sfx = sfx || '';
    this._next = next || [];
    //this._reactionSfx = Array.isArray( reactionSfx ) ? reactionSfx : [];
    //this._reactionSfxMod = Array.isArray(reactionSfxMod) ? reactionSfxMod.map( value => parseInt( value ) ) : [];
}
/**
 * @returns String
 */
KunTouchSpot.prototype.toString = function(){
    return `${this.name()} (${this._x1} ${this._y1} ${this._x2} ${this._y2})`;
}
/**
 * @returns String
 */
KunTouchSpot.prototype.name = function(){
    return this._name;
};
/**
 * @returns String
 */
KunTouchSpot.prototype.next = function(){
    var jumpTo = this._next.length > 1 ? Math.floor( Math.random() * this._next.length) : 0;
    return this._next.length > 0 ? this._next[ jumpTo ] : '';
};
/**
 * @returns Number
 */
KunTouchSpot.prototype.amount = function(){
    return this._amount;
};
/**
 * @returns String
 */
KunTouchSpot.prototype.behavior = function(){
    return this._behavior;
};
/**
 * @returns String
 */
KunTouchSpot.prototype.trigger = function(){
    return this._trigger;
};
/**
 * @returns KunTouchSpot
 */
KunTouchSpot.prototype.touchSfx = function(){
    if( this._sfx.length ){
        KunSceneManager.PlayFX( this._sfx );
    }
    return this;
}
/**
 * @returns String
 */
KunTouchSpot.prototype.getReactionFx = function(){
    if( this._reactionSfx.length > 1 ){
        return this._reactionSfx[ Math.floor( Math.random() * this._reactionSfx.length ) ];
    }
    else if( this._reactionSfx.length > 0 ){
        return this._reactionSfx[0];
    }
    return '';
};
/**
 * @returns Number
 */
KunTouchSpot.prototype.getReactionMod = function(){
    if( this._reactionSfxMod.length > 2 ){
        return this._reactionSfxMod[ Math.floor( Math.random() * this._reactionSfxMod.length ) ];
    }
    if( this._reactionSfxMod.length > 1 ){
        return Math.floor( Math.random() * (this._reactionSfxMod[1] - this._reactionSfxMod[0]) ) + this._reactionSfxMod[0];
    }
    else if( this._reactionSfxMod.length > 0 ){
        return this._reactionSfxMod[0];
    }
    else{
        return 100;
    }
};
/**
 * @returns KunTouchSpot
 */
KunTouchSpot.prototype.reactionSfx = function(){

    var sfx = this.getReactionFx();
    var mod = this.getReactionMod();
    if( sfx.length > 0 ){
        KunSceneManager.PlayFX( sfx , mod + 100 );
    }

    return this;
};
KunTouchSpot.prototype.setValue = function( value ){
    if( this._varId > 0 ){
        $gameVariables.setValue( this._varId , value );
    }
    return this;
};
/**
 * @returns KunTouchSpot
 */
KunTouchSpot.prototype.update = function(){
    if( this._varId > 0 ){
        switch( this.behavior()){
            case KunTouchSpot.Behavior.Add:
            case KunTouchSpot.Behavior.Increase: //deprecated
                this.setValue( $gameVariables.value(this._varId) + this.amount() );
                break;
            case KunTouchSpot.Behavior.Substract:
                var amount = $gameVariables.value(this._varId) - this._amount();
                this.setValue( amount > 0 ? amount : 0 );
                break;
            case KunTouchSpot.Behavior.Set:
                this.setValue( this.amount() );
                break;
            //case KunTouchSpot.Behavior.Frame:
                //this.setValue( $gameVariables.value(this._varId) + 1 );
            //    break;
        }
    }
    return this;
}
/**
 * 
 * @param {Number} x 
 * @param {Number} y 
 * @returns 
 */
KunTouchSpot.prototype.touched = function( x , y ){
    return (this._x1 <= x && this._x2 >= x) && (this._y1 <= y && this._y2 >= y);
};
/**
 * 
 * @param {Number} x 
 * @param {Number} y 
 * @returns KunTouchSpot
 */
KunTouchSpot.prototype.test = function( x , y){
    console.log( `${this.name()} X(${this._x1} >= ${x} <= ${this._x2}) Y(${this._y1} >= ${y} <= ${this._y2})` );
    return this;
};
/**
 * 
 */
KunTouchSpot.Behavior = {
    'Increase': 'increase',
    'Add': 'add',
    'Substract': 'sub',
    'Set': 'set',
    'Frame': 'frame', //DEPRECATED
};
/**
 * 
 */
KunTouchSpot.Trigger = {
    'Instant': 'instant',
    'Queue': 'queue',
    'Ignore': 'ignore',
    'Frame': 'frame',
};

/**
 * Use this class instead KunTouchSpot to ease the hotspot definition with the plugin manager.
 * Names MUST BE UNIQUE within the Animated Picture Setup.
 * 
 * @param {String} name 
 * @param {Number} x1 
 * @param {Number} y1 
 * @param {Number} x2 
 * @param {Number} y2 
 */
function KunHotSpot( name, x1,y1,x2,y2){
    this._name = name;
    this._x = x1;
    this._y = y1;
    this._x2 = x2;
    this._y2 = y2;
};
/**
 * @returns String
 */
KunHotSpot.prototype.toString = function(){
    return `${this._name}: ${this._x1} ${this._y1} ${this._x2} ${this._y2}`;
};
/**
 * @returns KunHotSpot
 */
KunHotSpot.prototype.clone = function(){
    return new KunHotSpot(this._name,this,_x1,this._y1,this._x2,this._y2);
};
/**
 * 
 * @param {Number} x1 
 * @param {Number} y1 
 * @param {Number} x2 
 * @param {Number} y2 
 */
KunHotSpot.Capture = function( x1,y1,x2,y2){
    new KunHotSpot(
        (new Date()).getTime().toString(),
        x1 > x2 ? x2 : x1,
        y1 > y2 ? y2 : y1
        );
};


/**
 * @param {String} name 
 * @param {Number} chance
 * @param {Boolean} interrupt
 * @param {Number} round
 */
function KunSoundBank( name , chance , interrupt , round ){
    this._name = name || '';
    this._chance = chance || 100;
    this._interrupt = typeof interrupt === 'boolean' && interrupt;
    this._se = [];
    this._volume = [];
    this._pitch = [];
    this._pan = [];
    this._round = round || 0;
};
/**
 * @returns String
 */
KunSoundBank.prototype.toString = function(){
    return this.name();
};
/**
 * @returns String
 */
KunSoundBank.prototype.name = function(){
    return this._name;
};
/**
 * @returns Number
 */
KunSoundBank.prototype.round = function(){
    return this._round;
};
/**
 * @returns Boolean
 */
KunSoundBank.prototype.interrupt = function(){
    return this._interrupt;
};
/**
 * @returns Number
 */
KunSoundBank.prototype.chance = function( ){
    return this._chance > Math.floor( Math.random() * 100 );
};
/**
 * 
 * @param {String} se 
 * @returns KunSoundBank
 */
KunSoundBank.prototype.addSe = function( se ){
    if( typeof se === 'string' && se.length ){
        this._se.push( se );
    }
    return this;
};
/**
 * @param {Number} vol 
 * @returns KunSoundBank
 */
KunSoundBank.prototype.addVol = function( vol ){
    if( typeof vol === 'number' && vol ){
        this._volume.push(vol);
    }
    return this;
};
/**
 * @param {Number} pitch 
 * @returns KunSoundBank
 */
KunSoundBank.prototype.addPitch = function( pitch ){
    if( typeof pitch === 'number' && pitch ){
        this._pitch.push(pitch);
    }
    return this;
};
/**
 * @param {Number} pan 
 * @returns KunSoundBank
 */
KunSoundBank.prototype.addPan = function( pan ){
    if( typeof pan === 'number' && pan ){
        this._pan.push(pan);
    }
    return this;
};
/**
 * @returns Number
 */
KunSoundBank.prototype.pan = function(){
    switch( this._pan.length ){
        case 0: return 0;
        case 1: return this._pan[0];
        case 2:
            var min = this._pan[0] < this._pan[1] ? this._pan[0] : this._pan[1];
            var max = this._pan[1] > this._pan[0] ? this._pan[1] : this._pan[0];
            return min + Math.floor(Math.random() * (max - min ));
        default:
            return this._pan[ Math.floor(Math.random() * this._pan.length) ];
    }
};
/**
 * @returns Number
 */
KunSoundBank.prototype.pitch = function(){
    switch( this._pitch.length ){
        case 0: return 100;
        case 1: return this._pitch[0];
        case 2:
            var min = this._pitch[0] < this._pitch[1] ? this._pitch[0] : this._pitch[1];
            var max = this._pitch[1] > this._pitch[0] ? this._pitch[1] : this._pitch[0];
            return min + Math.floor(Math.random() * (max - min ));
        default:
            return this._pitch[ Math.floor(Math.random() * this._pitch.length) ];
    }
};
/**
 * @returns Number
 */
KunSoundBank.prototype.volume = function(){
    switch( this._volume.length ){
        case 0: return 50;
        case 1: return this._volume[0];
        case 2:
            var min = this._volume[0] < this._volume[1] ? this._volume[0] : this._volume[1];
            var max = this._volume[1] > this._volume[0] ? this._volume[1] : this._volume[0];
            return min + Math.floor(Math.random() * (max - min ));
        default:
            return this._volume[ Math.floor(Math.random() * this._volume.length) ];
    }
};
/**
 * @returns String
 */
KunSoundBank.prototype.select = function(){
    switch( this._se.length ){
        case 0: return '';
        case 1: return this._se[0];
        default: return this._se[ Math.floor(Math.random() * this._se.length)];
    }
};
/**
 * @returns KunSoundBank
 */
KunSoundBank.prototype.play = function(){
    if( this.canPlay() && this.chance() ){
        var selection = this.select();
        if( selection.length ){
            KunSceneManager.AudioManager( selection, this.volume(), this.pitch() , this.pan() , this.interrupt());
        }    
    }
    return this;
};
/**
 * @returns KunSoundBank
 */
KunSoundBank.prototype.playRound = function( round ){
    if( this.canPlay() && this.round() > 0 && round % this.round() === 0 ){
        this.play();
    }
    return this;
};
/**
 * @returns Boolean
 */
KunSoundBank.prototype.canPlay = function(){
    return this._se.length > 0;
};
/**
 * 
 * @returns KunSoundBank
 */
KunSoundBank.Empty = function(){
    return new KunSoundBank('EMPTY');
};


/**
 * 
 */
function KunAnimations_RegisterManagers(){

    var _kunAnimations_Initialize_Sprite = Sprite_Picture.prototype.initialize;
    Sprite_Picture.prototype.initialize = function( pictureId ){
        _kunAnimations_Initialize_Sprite.call(this,pictureId);
        this._touching = false;
    };

    var _kunAnimations_Load_Bitmap = Sprite_Picture.prototype.loadBitmap;
    Sprite_Picture.prototype.loadBitmap = function() {
        _kunAnimations_Load_Bitmap.call(this);
        if( this.isAnimated() ){
            //this.bitmap.addLoadListener(this.updateAnimatedPictureFrame.bind(this));
            this.animationScene().reset(true); //initialize and play
            this.bitmap.addLoadListener(this.updateAnimation.bind(this,true));
        }
        else{
            //this.bitmap.addLoadListener(this.resetFrame.bind(this));
        }
    };

    var _kunAnimations_Update_Sprite = Sprite_Picture.prototype.update;
    Sprite_Picture.prototype.update = function(){
        _kunAnimations_Update_Sprite.call( this );
        //update the animation controller
        this.updateAnimation();
        this.processTouch();
    };
    /**
     * @param {Boolean} force
     * @returns Boolean
     */
    Sprite_Picture.prototype.updateAnimation = function( force ){
        //if(  this.isLoaded() && this.isAnimated() ){
        var _controller = this.animationScene();
        if( _controller !== null ){
            if( _controller.update() || force ){
                var index = _controller.getFrame();
                var w = this.bitmap.width / _controller.cols();
                var h = this.bitmap.height / _controller.rows();
                var x = index % _controller.cols() * w;
                var y = Math.floor(index / _controller.cols()) * h;
                this.setFrame( x, y, w, h);
                return true;                    
            }
        }
        return false;
    };
    /**
     * @returns KunAnimationScene
     */
    Sprite_Picture.prototype.animationScene = function(){
        return KunSceneManager.get(this._pictureName);
    };
    /**
     * @returns Boolean
     */
    Sprite_Picture.prototype.isAnimated = function(){
        return KunSceneManager.has(this._pictureName);
    }
    /**
     * @returns Boolean
     */
    Sprite_Picture.prototype.isLoaded = function(){
        return typeof this.bitmap !== 'undefined' && this.bitmap !== null;
    };

    Sprite_Picture.prototype.isInteractive = function(){
        //capture from plugin animation data
        return this.animationScene().isInteractive();
    };
    /**
     * @param {Number} x 
     * @returns Number
     */
    Sprite_Picture.prototype.offsetX = function( x ){
        return this.picture().scaleX() > 0 ? Math.floor((x - this.picture().x()) * 100 / this.picture().scaleX()) : 0;
    };
    /**
     * @param {Number} y 
     * @returns Number
     */
    Sprite_Picture.prototype.offsetY = function( y ){
        return this.picture().scaleY() > 0 ? Math.floor((y - this.picture().y()) * 100 / this.picture().scaleY()) : 0;
    };
    /**
     * @returns Boolean
     */
    Sprite_Picture.prototype.validScale = function(  ){
        return this.picture().scaleX() > 0 && this.picture().scaleY() > 0
    }
    /**
     * @returns Boolean
     */
    Sprite_Picture.prototype.processTouch = function() {
        if( this.isAnimated() ){
            if (TouchInput.isTriggered()) {
                if( !this._touching ){
                    this._touching = true;
                }
                if(KunSceneManager.canCapture()){
                    this.animationScene().captureFrom( this.offsetX(TouchInput._x), this.offsetY(TouchInput._y));
                }
            }
            if (TouchInput.isReleased()) {
                if (this._touching) {
                    this._touching = false;
                    //console.log( `Touch ${TouchInput._x},${TouchInput._y} (${this.validScale()})` );
                    //var picture = this.picture();
                    if(KunSceneManager.canCapture()){
                        this.animationScene().captureTo(this.offsetX(TouchInput._x), this.offsetY(TouchInput._y));    
                    }
                    else if( KunSceneManager.canTouch() && this.validScale( ) ){
                        var X = TouchInput._x;
                        var Y = TouchInput._y;
                        this.animationScene().touch(this.offsetX(X), this.offsetY(Y), X, Y);
                    }
                }
            }
        }
        return this._touching;
    };

    //OVERRIDE Game_Picture move method to capture the picture offset when required
    var _kunAnimations_Game_Picture_Move = Game_Picture.prototype.move;
    Game_Picture.prototype.move = function(origin, x, y, scaleX, scaleY, opacity, blendMode, duration) {

        //capture X and Y offset from picture name
        if( this._name.length ){
            //import offset from currently active picture's frameset controller plus the scale
            var _offset = KunSceneManager.offset(this._name);
            //then apply the transformations
            x -= parseInt( _offset.x * (scaleX / 100) );
            y -= parseInt( _offset.y * (scaleY / 100) );
        }

        _kunAnimations_Game_Picture_Move.call(this,origin,x,y,scaleX,scaleY,opacity,blendMode,duration);
    };
}
/**
 * 
 */
function KunAnimations_SetupCommands(){
    var _KunAnimations_SetupCommands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function(command, args) {
        _KunAnimations_SetupCommands.call(this, command, args);
        if (command === 'KunAnimations' && args.length > 0 ) {
            switch( args[0] ){
                case 'alias':
                    if( args.length > 2 ){
                        KunSceneManager.setAlias( args[1] , args[2] );
                    }
                    break;
                case 'clear':
                    if( args.length > 1 ){
                        switch( args[1]){
                            case 'targets':
                                KunSceneManager.clearTargets();
                                break;
                            case 'alias':
                                KunSceneManager.clearAlias();
                                break;
                            case 'all':
                                KunSceneManager.clearAlias().clearTargets();
                                break;
                        }
                    }
                    else{
                        KunSceneManager.clearTargets();
                    }
                    break;
                case 'fps':
                    if( args.length > 2 ){
                        var fps = parseInt( args[2] );
                        if( args.length > 3 && args[3] === 'import' ){
                            fps = $gameVariables.value( fps );
                        }
                        KunSceneManager.overrideFPS( KunSceneManager.getAlias(args[1]) ,  fps );
                        //KunSceneManager.DebugLog(`FPS updated to ${fps}`);
                    }
                    break;
                case 'reset':
                    if( args.length > 1 ){
                        KunSceneManager.reset( KunSceneManager.getAlias(args[1]) , args.length > 2 && args[2] === 'replay' );
                    }
                    break;
                case 'set':
                    if( args.length > 2 ){
                        var frameSet = args[2].split('.');
                        var name = KunSceneManager.getAlias(args[1]);
                        if( frameSet.length > 1 ){
                            KunSceneManager.overrideSet( name , frameSet[ Math.floor( Math.random() * frameSet.length ) ] );
                        }
                        else{
                            KunSceneManager.overrideSet( name , frameSet );
                        }
                        if( args.length > 3 && args[3] === 'wait'){
                            if ( args.length > 4 ){
                                var wait = args[4].split(':').map( count => parseInt(count));
                                this.wait( wait.length > 1 ? wait[0] + Math.floor( Math.random() * ( wait[1] - wait[0] ) ) : wait[0] );
                            }
                        }
                    }
                    break;
                case 'pause':
                    if( args.length > 1 ){
                        KunSceneManager.stop( KunSceneManager.getAlias(args[1]) );
                        //KunSceneManager.DebugLog('Animation Paused');
                    }
                    break;
                case 'resume':
                    if( args.length > 1 ){
                        KunSceneManager.resume( KunSceneManager.getAlias(args[1]) );
                        //KunSceneManager.DebugLog('Animation Resumed');
                    }
                    break;
                case 'wait':
                    if( args.length > 1 ){
                        var wait = parseInt(args[1]);
                        if( args.length > 2 && args[2] === 'import' && wait > 0 ){
                            wait = $gameVariables.value( wait );
                        }
                        this.wait( wait );
                        KunSceneManager.DebugLog(`Waiting ${wait} fps ...`);
                    }
                    break;
                case 'target':
                    KunSceneManager.target(args.length > 1 && args[1] === 'random');
                    break;
                case 'play':
                    if( args.length > 1 ){
                        KunSceneManager.playBank(args[1]);
                        if( args.length > 2 ){
                            KunSceneManager.Wait( parseInt(args[2]) , args.length > 3 ? parseInt(args[3]) : 0 );
                        }
                    }
                    break;
                case 'mode':
                    KunSceneManager.setMode( args.length > 1  ? args[1] : KunSceneManager.Mode().Disabled );
                    if( KunSceneManager.canCapture() ){
                        KunSceneManager.DebugLog(`Capture Mode ON. Click and drag over a picture spot, then release to define the target area.`);
                    }
                    else{
                        KunSceneManager.DebugLog(`${KunSceneManager.mode()} mode on`);
                    }
                    break;
            }
        }
    };

}

/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

 (function( /* args */ ){

    KunSceneManager.Initialize();

    KunAnimations_RegisterManagers();

    KunAnimations_SetupCommands();
})( /* initializer */ );



