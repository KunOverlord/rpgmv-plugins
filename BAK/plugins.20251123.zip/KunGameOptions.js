//=============================================================================
// KunGameOptions.js
//=============================================================================
/*:
 * @plugindesc KunGameOptions
 * @filename KunGameOptions.js
 * @author KUN
 * @version 1.02
 * 
 * @param debug
 * @text Debug
 * @desc Show debug data in console
 * @type Boolean
 * @default false
 * 
 * @param fullOptionWindow
 * @text Fullview Option Window
 * @type boolean
 * @default false
 * 
 * @param switches
 * @type struct<GameSwitch>[]
 * @string Game Switches
 * 
 * @param variables
 * @type struct<GameVariable>[]
 * @string Game Variables
 */
/*~struct~GameSwitch:
 * @param name
 * @text Name
 * @type string
 * 
 * @param switch
 * @text Switch
 * @type switch
 * @min 0
 * @default 0
 * 
 * @param title
 * @text Title
 * @type string
 * 
 * @param value
 * @type boolean
 * @text Default Value
 * @default false
 */
/*~struct~GameVariable:
 * @param name
 * @text Name
 * @type string
 * 
 * @param variable
 * @text Game Variable
 * @type variable
 * @min 0
 * @default 0
 * 
 * @param title
 * @text Title
 * @type string
 * 
 * @param value
 * @type number
 * @text Default Value
 * @min 0
 * @default 0
 * 
 * @param maximum
 * @type number
 * @text Maximum Value
 * @min 1
 * @default 100
 */

function KunGameOptions(){
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 */
KunGameOptions.Initialize = function(){

    var parameters = this.parameters();

    this._debug = parameters.debug === 'true';
    this._fullOptionWindow = parameters.fullOptionWindow === 'true';

    this._switches = {};
    this._variables = {};

    this.importSwitches( parameters.switches.length ? JSON.parse(parameters.switches) : [] );
    this.importVariables( parameters.variables.length ? JSON.parse(parameters.variables) : [] );
   
};
/**
 * @returns Boolean
 */
KunGameOptions.debug = function(){
    return this._debug;
};
/**
 * @returns Boolean
 */
KunGameOptions.fullOptionWindow = function(){
    return this._fullOptionWindow;
};
/**
 * @param {String|Object} message
 */
KunGameOptions.DebugLog = function( message ){
    if( this.debug()){
        console.log( typeof message === 'object' ? message : `[ KunGameOptions ] : ${message}` );

    }
};
/**
 * @param {String} name
 * @param {String} title
 * @param {Number} gameSwitch
 * @param {Number} value
 */
KunGameOptions.addSwitch = function( name, title, gameSwitch , value ){
    if( !this.hasGameSwitch(name)){
        this._switches[name] = {
            'title': title,
            'name': name,
            'id': gameSwitch,
            'value': value,
        };
    }
};
/**
 * @param {String} name
 * @param {String} title
 * @param {Number} gameVar
 * @param {Number} value
 * @param {Number} maximum
 */
KunGameOptions.addVariable = function( name, title, gameVar , value , maximum ){
    if( !this.hasVariable(name)){
        this._variables[name] = {
            'title': title,
            'name': name,
            'id': gameVar,
            'value': value,
            'maximum': maximum,
        };
    }
};
/**
 * @param {String} gs 
 * @returns Boolean
 */
KunGameOptions.hasGameSwitch = function( gs ){
    return this._switches.hasOwnProperty( gs );
};
/**
 * @param {String} gv 
 * @returns Boolean
 */
KunGameOptions.hasVariable = function( gv ){
    return this._variables.hasOwnProperty( gv );
};
KunGameOptions.importSwitches = function( switches ){
    if( switches.length > 0 ){
        switches.map( gs => JSON.parse(gs) )
            .filter( gs => parseInt(gs.switch) > 0 && !KunGameOptions.hasGameSwitch(gs.name ) )
            .forEach( function( gs ){
                KunGameOptions.addSwitch( gs.name, gs.title , parseInt( gs.switch ) , gs.value === 'true' );
            });
    }
};
KunGameOptions.importVariables = function( variables ){
    if( variables.length > 0 ){
        variables.map( gv => JSON.parse(gv) )
            .filter( gv => parseInt(gv.variable) > 0 && !KunGameOptions.hasGameSwitch(gv.name ) )
            .forEach( function( gv ){
                KunGameOptions.addVariable( gv.name, gv.title , parseInt( gv.variable ) , parseInt(gv.value), parseInt(gv.maximum) );
            });
    }
};
KunGameOptions.importDefaults = function(){
    this.switches(true).forEach( function( gameSwitch ){
        KunGameOptions.setGameSwitch( gameSwitch.name , gameSwitch.value );
    });
    this.variables(true).forEach( function( gameVar ){
        KunGameOptions.setGameVar( gameVar.name , gameVar.value );
    });
};
/**
 * @returns Object
 */
KunGameOptions.parameters = function(){
    return  PluginManager.parameters('KunGameOptions');
};
/**
 * @param {Boolean} list
 * @returns Object
 */
KunGameOptions.variables = function( list ){
    return typeof list === 'boolean' && list ?  Object.values(this._variables) : this._variables;
};
/**
 * @param {Boolean} list
 * @returns Object[]
 */
KunGameOptions.switches = function( list ){
    return typeof list === 'boolean' && list ?  Object.values(this._switches) : this._switches;
};
/**
 * @param {String} gameVar 
 * @returns Number
 */
KunGameOptions.getGameVar = function( gameVar ){
    return this.hasVariable( gameVar ) ? $gameVariables.value( this.variables()[gameVar].id ) : 0;
};
/**
 * @param {String} gameSwitch 
 * @returns Boolean
 */
KunGameOptions.getGameSwitch = function( gameSwitch ){
    return this.hasGameSwitch( gameSwitch ) ? $gameSwitches.value( this.switches()[gameSwitch].id ) : false;
};
/**
 * @param {String} gameVar 
 * @param {Number} value 
 */
KunGameOptions.setGameVar = function( gameVar , value ){
    if( this.hasVariable( gameVar )){
        var gv = this.variables()[gameVar].id;
        var max = this.variables()[gameVar].maximum;
        KunGameOptions.DebugLog(`${gv}: ${value}/${max}`);
        $gameVariables.setValue( gv , value.clamp( 0 , max ) );
    }
};
/**
 * @param {String} gameSwitch 
 * @param {Boolean} value 
 */
KunGameOptions.setGameSwitch = function( gameSwitch , value ){
    if( this.hasGameSwitch( gameSwitch )){
        var gs = this.switches()[gameSwitch].id;
        $gameSwitches.setValue( gs , value );
    }
};

function KunGameOptions_MainMenu(){
    var _KunGameOptions_SceneTitle_Start = Scene_Title.prototype.start;
    Scene_Title.prototype.start = function() {
        _KunGameOptions_SceneTitle_Start.call(this);
        KunGameOptions.importDefaults();
    };
}

function KunGameOptions_CommandList(){
    var _KunGameOptions_makeCommandList = Window_Options.prototype.makeCommandList;
    Window_Options.prototype.makeCommandList = function() {
        
        this.addSwitchOptions();

        this.addVariableOptions();

        _KunGameOptions_makeCommandList.call(this);
    };    

    Window_Options.prototype.addSwitchOptions = function() {
        var variables = KunGameOptions.variables(true);
        for( var i = 0 ; i < variables.length ; i++ ){
            //KunGameOptions.DebugLog(`${variables[i].title} : ${variables[i].name}`);
            this.addCommand( variables[i].title , variables[i].name );
        }
    };
    Window_Options.prototype.addVariableOptions = function() {
        var switches = KunGameOptions.switches(true);
        for( var i = 0 ; i < switches.length ; i++ ){
            //KunGameOptions.DebugLog(`${switches[i].title} : ${switches[i].name}`);
            this.addCommand( switches[i].title , switches[i].name );
        }
    };
    /**
     * @param {String} symbol 
     * @returns Boolean
     */
    Window_Options.prototype.isNumericSymbol = function(symbol) {
        return KunGameOptions.hasVariable( symbol ) || this.isVolumeSymbol( symbol );
    }
    /**
     * @param {String} symbol 
     * @returns Number
     */
    Window_Options.prototype.maximum = function(symbol) {
        return KunGameOptions.hasVariable(symbol) ? KunGameOptions.variables()[symbol].maximum : 100;
    };
    /**
     * @param {String} symbol 
     * @returns Number
     */
    Window_Options.prototype.valueOffset = function(symbol) {
        return !KunGameOptions.hasVariable(symbol) ? this.volumeOffset() : 1;
    };
    
    /// OVERRIDES
    Window_Options.prototype.statusText = function(index) {
        var symbol = this.commandSymbol(index);
        var value = this.getConfigValue(symbol);
        if (this.isNumericSymbol(symbol)) {
            return !KunGameOptions.hasVariable( symbol) ? this.volumeStatusText(value) : value.toString();
        } else {
            return this.booleanStatusText(value);
        }
    };

    Window_Options.prototype.processOk = function() {
        var index = this.index();
        var symbol = this.commandSymbol(index);
        var value = this.getConfigValue(symbol);
        if (this.isNumericSymbol(symbol)) {
            var max = this.maximum(symbol);
            value = value < max ? (value + this.valueOffset(symbol)).clamp(0, max) : 0;
            this.changeValue(symbol, value);
        } else {
            this.changeValue(symbol, !value);
        }
    };

    Window_Options.prototype.cursorRight = function(wrap) {
        var index = this.index();
        var symbol = this.commandSymbol(index);
        var value = this.getConfigValue(symbol);
        switch( true ){
            case KunGameOptions.hasVariable( symbol ) || this.isVolumeSymbol( symbol ):
                value = (value + this.valueOffset( symbol )).clamp(0, this.maximum(symbol));
                break;
            default:
                value = true;
                break;
        }
        this.changeValue(symbol, value)
    };
    
    Window_Options.prototype.cursorLeft = function(wrap) {
        var index = this.index();
        var symbol = this.commandSymbol(index);
        var value = this.getConfigValue(symbol);
        switch( true ){
            case KunGameOptions.hasVariable( symbol ) || this.isVolumeSymbol( symbol ):
                value = ( value - this.volumeOffset()).clamp(0, 100);
                break;
            default:
                value = false;
                break;
        }
        this.changeValue(symbol, value );
    };

    Window_Options.prototype.getConfigValue = function(symbol) {
        switch( true ){
            case KunGameOptions.hasVariable( symbol ):
                return KunGameOptions.getGameVar( symbol );
            case KunGameOptions.hasGameSwitch( symbol ):
                return KunGameOptions.getGameSwitch( symbol );
            default:
                return ConfigManager[symbol];
        }
    };
    
    Window_Options.prototype.setConfigValue = function(symbol, value ) {
        switch( true ){
            case KunGameOptions.hasVariable( symbol ) && typeof value === 'number':
                return KunGameOptions.setGameVar( symbol , value );
            case KunGameOptions.hasGameSwitch( symbol ) && typeof value === 'boolean':
                return KunGameOptions.setGameSwitch( symbol , value );
            default:
                ConfigManager[symbol] = value;
        }
    };
    //override with full view when required
    Window_Options.prototype.updatePlacement = function() {
        if( KunGameOptions.fullOptionWindow() ){
            this.x = 12;
            this.y = 12;
        }
        else{
            this.x = (Graphics.boxWidth - this.width) / 2;
            this.y = (Graphics.boxHeight - this.height) / 2;    
        }
    };
    /**
     * @returns Number
     */
    Window_Options.prototype.windowWidth = function() {
        return KunGameOptions.fullOptionWindow() ? Graphics.boxWidth - 24 : 400;
    };
    /**
     * @returns Number
     */
    Window_Options.prototype.windowHeight = function() {
        return KunGameOptions.fullOptionWindow() ? Graphics.boxHeight - 24 : this.fittingHeight(this.numVisibleRows());
    };
};

/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunGameOptions.Initialize();

    KunGameOptions_CommandList();
    KunGameOptions_MainMenu();

})( /* initializer */);

