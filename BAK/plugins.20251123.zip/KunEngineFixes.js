//=============================================================================
// KunEngineFixes.js
//=============================================================================
/*:
 * @filename KunEngineFixes.js
 * @plugindesc Fixes issues with the RPG Maker MV engine
 * @version 1.1
 * @author KUN
 * @target MV
 * 
 * @help
 * 
 * Thanks to Dunnask for finding this tip ^_^
 * 
 * URL:
 * https://forums.rpgmakerweb.com/index.php?threads/rpg-maker-mv-games-graphics-will-freeze-but-sound-keeps-playing-the-problem-the-solution.151887/
 * 
 * 
 *
 * @param debug
 * @text Debug
 * @type boolean
 * @default false
 * 
 * @param renderFix
 * @text Graphics Render Patch
 * @type boolean
 * @desc Enables the graphics render patch to avoid freezing on specific computer framerates
 * @default true
 * 
 * @param mouseWheelFix
 * @text MouseWheel Fix
 * @type boolean
 * @desc Adds scroll mouse wheel passive event listener support for chrome.
 * @default false
 * 
 */

function KunEngineFixes(){
    throw `${this.constructor.name} is a Static Class`;
};

KunEngineFixes.initialize = function(){
    var parameters = PluginManager.parameters('KunEngineFixes');

    this._debug = parameters.debug === 'true' || false;
    this._renderFix = parameters.renderFix === 'true' || true;
    this._mouseWheelFix = parameters.mouseWheelFix === 'true' || false;


    if( this._renderFix ){
        this.graphicsRenderFix();
    }
    if( this._mouseWheelFix ){
        KunEngineFixes.TouchInputWheelFix();
    }
};

KunEngineFixes.DebugLog = function( message ){
    if( this._debug){
        console.log( typeof message ===  'object' ? message : `[KunEngineFixes] ${message}` );
    }
};

/**
 * Overrides the Graphics.render with a fix to prevent frames going below 0
 */
KunEngineFixes.graphicsRenderFix = function(){
    var _KunGraphicsRenderFix = Graphics.render;
    Graphics.render = function(stage) {
        if( this._skipCount < 0 ){
            this._skipCount = 0;
            KunEngineFixes.DebugLog('Graphics.render bug catched and fixed!');
        }
        _KunGraphicsRenderFix.call(this,stage);
    };
};
/**
 * 
 */
KunEngineFixes.TouchInputWheelFixOLD = function(){
    /**
     * @static
     * @method _onWheel
     * @param {WheelEvent} event
     * @private
     */
    TouchInput._onWheel = function(event) {
        this._events.wheelX += event.deltaX;
        this._events.wheelY += event.deltaY;
        //event.preventDefault();
    };    
};
/**
 * 
 */
KunEngineFixes.TouchInputWheelFix = function(){
    /**
     * @static
     * @method _setupEventHandlers
     * @private
     */
    TouchInput._setupEventHandlers = function() {
        var isSupportPassive = Utils.isSupportPassiveEvent();
        document.addEventListener('mousedown', this._onMouseDown.bind(this));
        document.addEventListener('mousemove', this._onMouseMove.bind(this));
        document.addEventListener('mouseup', this._onMouseUp.bind(this));
        //added passive event listener to wheel on chrome too
        document.addEventListener('wheel', this._onWheel.bind(this), isSupportPassive ? {passive: false} : false);
        document.addEventListener('touchstart', this._onTouchStart.bind(this), isSupportPassive ? {passive: false} : false);
        document.addEventListener('touchmove', this._onTouchMove.bind(this), isSupportPassive ? {passive: false} : false);
        document.addEventListener('touchend', this._onTouchEnd.bind(this));
        document.addEventListener('touchcancel', this._onTouchCancel.bind(this));
        document.addEventListener('pointerdown', this._onPointerDown.bind(this));
    };   
};

(function(){
    KunEngineFixes.initialize();
})();
