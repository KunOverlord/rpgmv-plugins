//=============================================================================
// KunPerks.js
//=============================================================================
/*:
 * @plugindesc KunPerks
 * @filename KunPerks.js
 * @author KUN
 * @version 1.00
 * 
 * @help
 * 
 * COMMANDS
 * 
 * KunPerks perk [actor_id:tags...] Title 1,Title 2,Title 3, ...
 *      Add perks to an actor by actor_id
 *      Add 1 or more perk at once, separated by commas
 *      Tag a specific perk or list of perks
 * 
 * KunPerks reset [actor_id:tag] | all
 *      Reset actor_id's titles, or all actors' titles
 *      Reset a scope of perks by tags
 * 
 * @param debug
 * @text Debug
 * @desc Show debug info
 * @type Boolean
 * @default false
 * 
 */

function KunPerks(){
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 */
KunPerks.Initialize = function(){

    var parameters = this.parameters();

    this._debug = parameters.debug === 'true';
};
/**
 * @returns Object
 */
KunPerks.parameters = function(){
    return  PluginManager.parameters('KunPerks');
};
/**
 * @returns Boolean
 */
KunPerks.debug = function(){
    return this._debug;
};
/**
 * @returns Boolean
 */
KunPerks.displayNickName = function(){
    return this._nickname;
};

/**
 * 
 */
function KunPerks_GameActor(){

    var _KunPerks_GameActor_Initialize = Game_Actor.prototype.initialize;
    Game_Actor.prototype.initialize = function(actorId) {
        
        _KunPerks_GameActor_Initialize.call(this,actorId);
        
        this.resetPerks();
    };

    var _KunPerks_GameActor_SetNickName = Game_Actor.prototype.setNickname;
    Game_Actor.prototype.setNickname = function(nickname) {
        var title = nickname.split(':');
        if( title.length > 1 ){
            //do not update the nickname, add to the filtered title list
            this.addPerk( title[title.length - 1 ] , title.slice(0,title.length - 1 ) );
        }
        else{
            //add as a normal nickname and register in the title list
            _KunPerks_GameActor_SetNickName.call( this, title[0] );
            this.addPerk( title[0] );
        }
    };

    /**
     * @param {String} tag
     * @returns Game_Actor
     */
    Game_Actor.prototype.resetPerks = function( tag ) {
        if( typeof tag === 'string' && tag.length ){
            var perks = this._perks.filter( perk => !perk.tags.includes(tag));
            console.log(perks);
            this._perks = perks;
        }
        else{
            this._perks = [];
        }
        return this;
    };
    /**
     * 
     * @param {String} title 
     * @returns Boolean
     */
    Game_Actor.prototype.hasPerk = function( title ) {
        return this.perks().filter( t => t === title ).length > 0;
    }
    /**
     * @param {String} title 
     * @param {String|String[]} tags 
     * @returns Game_Actor
     */
    Game_Actor.prototype.addPerk = function( title , tags ) {
        if( !this.hasPerk(title)){
            this._perks.push({
                'title':title,
                'tags': Array.isArray(tags) && tags.length ? tags : (typeof tags === 'string' && tags.length ? tags.split(':') : []),
            });                
        }
        return this;
    };
    /**
     * @returns String[]
     */
    Game_Actor.prototype.perks = function( tag ) {
        return (typeof tag === 'string' && tag.length ?
            this._perks.filter( t => t.tags.includes(tag) ) :
            this._perks.filter( t => t.tags.length === 0)).map( t => t.title );
    };
    /**
     * @param {String} tag 
     * @returns String
     */
    Game_Actor.prototype.perk = function( tag ) {
        var selection = this.perks( tag );
        return selection.length > 0 ? selection[ Math.floor(Math.random() * selection.length )] : this.nickname();
    };
    /**
     * @param {Number} amount
     * @param {String} tag
     * @returns String
     */
    Game_Actor.prototype.displayPerks = function( amount , tag ){
        return this.perks( tag ).slice(0, typeof amount === 'number' && amount > 1 ? amount : 1).join(', ');
    };
}

/**
 * 
 */
function KunPerks_PluginCommands(){
    var _KunPerks_CommandInterpreter = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunPerks_CommandInterpreter.call(this, command, args);
        if( command === 'KunPerks' && args.length > 1 ){
            switch( args[0] ){
                case 'perk':
                    var target = args[1].split(':');
                    var nicknames = args.slice( 2 , args.length).join(' ').split(',');
                    var actor_id = parseInt(target.shift());
                    if( !Number.isNaN(actor_id) && actor_id > 0 ){
                        nicknames.forEach( function(nn){
                            $gameActors.actor(actor_id).addPerk( nn , target );
                        });    
                    }
                    break;
                case 'reset':
                    //reset short and last names (do it after loading a saved game)
                    if( args.length > 1 ){
                        var tags = args.length > 2 ? args.slice(2, args.length) : [];
                        console.log(tags);
                        if( args[1] === 'all'){
                            $gameActors._data.filter( actor => actor !== null ).forEach( function( actor ){
                                actor.resetPerks(tags.length > 0 ? tags[0] : '');
                            });
                        }
                        else{
                            var actor_id = parseInt(args[1]);
                            if( !isNaN(actor_id) ){
                                //console.log( actor_id,tags);
                                $gameActors.actor(actor_id).resetPerks(tags.length > 0 ? tags[0] : '' );
                            }    
                        }
                    }
                    break;
            }
        }
    }
}
/**
 * 
 */
function KunPerks_EscapeChars(){
    var _KunPerks_EscapeCharacters = Window_Base.prototype.convertEscapeCharacters;

    Window_Base.prototype.convertEscapeCharacters = function (text) {
        var parsed = _KunPerks_EscapeCharacters.call(this, text);

        parsed = parsed.replace(/\x1bAN\[(.+)\]/gi, function () {
            return this.displayPerk( parseInt(arguments[1] ));
            return this.displayNickName( parseInt( arguments[1]));
        }.bind(this));

        parsed = parsed.replace(/\x1bAT\[(.+)\]/gi, function () {
            var selection = arguments[1].split(':');
            var actor_id = parseInt(selection.shift());
            return this.displayPerk( actor_id , selection.length > 0 ? selection[0] : '' );
        }.bind(this));

        parsed = parsed.replace(/\x1bAT2\[(.+)\]/gi, function () {
            var selection = arguments[1].split(':');
            var actor_id = parseInt(selection.shift());
            return this.displayPerks( actor_id , 2 , selection.length > 0 ? selection[0] : '' );
        }.bind(this));

        parsed = parsed.replace(/\x1bAT23\[(.+)\]/gi, function () {
            var selection = arguments[1].split(':');
            var actor_id = parseInt(selection.shift());
            return this.displayPerks( actor_id , 3 , selection.length > 0 ? selection[0] : '' );
        }.bind(this));

        return parsed;
    };

    Window_Base.prototype.displayNickName = function ( actor_id  ) {
        return $gameActors.actor( actor_id ).nickname(  );
    };

    Window_Base.prototype.displayPerk = function ( actor_id , tags ) {
        return $gameActors.actor( actor_id ).perk( tags );
    };

    Window_Base.prototype.displayPerks = function ( actor_id, amount , tag ) {
        return $gameActors.actor( actor_id ).perks( tag ).slice(0, typeof amount === 'number' && amount > 1 ? amount : 1).join(', ');
    };
}

/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunPerks.Initialize();

    KunPerks_GameActor();
    KunPerks_PluginCommands();
    KunPerks_EscapeChars();

})( /* initializer */);

