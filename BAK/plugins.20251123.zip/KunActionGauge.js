//=============================================================================
// KunActionGauge.js
//=============================================================================
/*:
 * @filename KunActionGauge.js
 * @author KUN
 * @version 2.21
 * @plugindesc Show an Action Gauge using assigned variables.
 * 
 * TODO: Override the $gameVariables.setValue method to implement a hook to count the selected variables
 * 
 * @help
 * 
 *  COMMANDS:
 *  KunActionGauge display name [location|reset|fill] [amount]
 *      Show gauge by name
 *      Define an alternative location to render the gauge [top|bottom|left|right]
 *      Define reset to setup the game variables before display (value = 0)
 *      Define fill to setup the game variables before display (value = limit)
 *      Set the amount to reset the gauges
 *  KunActionGauge close [name]
 * 
 * 
 * @param debug
 * @text Debug
 * @type boolean
 * @default false
 * 
 * @param background
 * @text Gauge Background
 * @type select
 * @option None
 * @value 2
 * @option Dim
 * @value 1
 * @option Window
 * @value 0
 * @default 0
 * 
 * @param weight
 * @text Gauge Weight
 * @desc Setup the gauge thickness
 * @type number
 * @min 8
 * @max 48
 * @default 12
 * 
 * @param offsets
 * @text Gauge Offsets
 * @desc x, y, length , weight
 * @min -100
 * @max 100
 * @type number[]
 * @default []
 * 
 * @param profiles
 * @text Gauge Profiles
 * @desc Define here the list of all available gauges
 * @type struct<Gauge>[]
 *
 */
/*~struct~Gauge:
 *
 * @param name
 * @text Name
 * @type text
 * @default action-gauge
 * 
 * @param location
 * @text Location
 * @type select
 * @option Left
 * @value left
 * @option Right
 * @value right
 * @option Top
 * @value top
 * @option Bottom
 * @value bottom
 * @option Center
 * @value center
 * @default left
 * 
 * @param valueVar
 * @text Value Variable
 * @desc The gauge value and current state
 * @type variable
 * @min 0
 * @default 0
 *
 * @param targetVar
 * @text Target Variable
 * @desc The gauge's limit or maximum value
 * @type variable
 * @min 0
 * @default 0
 *
 * @param color1
 * @text Default Color 1
 * @desc Pick the base color
 * @type number
 * @min 0
 * @max 31
 * @default 1
 *
 * @param color2
 * @text Default Color 2
 * @desc Pick the overlay color
 * @type number
 * @min 0
 * @max 31
 * @default 4
 * 
 * @param rules
 * @type struct<Rule>[]
 * @text Rules
 * @desc Change gauge colors when meeting a certain condition
 * @default []
 *
 */
/*~struct~Rule:
 *
 * @param value
 * @text Value
 * @type number
 * @min 0
 * @max 100
 * @default 0
 *
 * @param operation
 * @text Operation
 * @desc Select the proper operation to compare value to the current attribute
 * @type select
 * @option Greater
 * @value greater
 * @option Greater or Equal
 * @value greater_equal
 * @option Equal
 * @value equal
 * @option Less or Equal
 * @value less_equal
 * @option Less
 * @value less
 * @default equal
 * 
 * @param color1
 * @text Change Color 1
 * @desc Set the new gauge color when aplying this rule.
 * @type number
 * @min 0
 * @max 31
 * @detault 0
 * 
 * @param color2
 * @text Change Color 2
 * @desc Set the new gauge color when aplying this rule.
 * @type number
 * @min 0
 * @max 31
 * @detault 0
 */

/**
 * @description KUN Modules
 * @type KUN
 */
var KUN = KUN || {};

function KunActionGauge() { throw new Error('This is a static class'); }
/**
 * 
 */
KunActionGauge.initialize = function () {

    var parameters = this.PluginData();
    this._debug = parameters.debug;
    this._background = parameters.background || 0;
    this._weight = parameters.weight || 12;
    this._offsets = parameters.offsets || [];
    this._gauges = {
        //add here all gauges
    };
    this.import( Array.isArray(parameters.profiles) > 0 ? parameters.profiles : []);
};
/**
 * @returns Number
 */
KunActionGauge.offsetX = function(){
    return this._offsets.length ? this._offsets[0] : 0;
};
/**
 * @returns Number
 */
KunActionGauge.offsetY = function(){
    return this._offsets.length > 1 ? this._offsets[1] : 0;
};
/**
 * @returns Number
 */
KunActionGauge.offsetLength = function(){
    return this._offsets.length > 2 ? this._offsets[2] : 0;
};
/**
 * @returns Number
 */
KunActionGauge.offsetWeight = function(){
    return this._offsets.length > 3 ? this._offsets[3] : 0;
};
/**
 * @param {Boolean} list 
 * @returns {Object|KunGauge[]}
 */
KunActionGauge.gauges = function( list ){
    return typeof list === 'boolean' && list ? Object.values( this._gauges ) : this._gauges;
};
/**
 * @param {String} gauge 
 * @returns Boolean
 */
KunActionGauge.has = function (gauge) {
    return this.gauges().hasOwnProperty(gauge);
};
/**
 * Register gauge templates here
 * @param {KunGauge} gauge
 * @returns {KunActionGauge}
 */
KunActionGauge.add = function ( gauge ) {
    if( gauge instanceof KunGauge && gauge.isValid() && !this.has(gauge.name()) ){
        this._gauges[ gauge.name() ] = gauge;
    }
    return this;
};
/**
 * @param {Object[]} gauges
 * @returns KunActionGauge
 */
KunActionGauge.import = function ( gauges ) {
    gauges.forEach(function (tpl) {
        var gauge = new KunGauge(
            tpl.name ,
            tpl.location,
            tpl.valueVar,
            tpl.targetVar,
            tpl.color1,
            tpl.color2
        );
        if( Array.isArray( tpl.rules ) ){
            tpl.rules.forEach( function( rule ){
                gauge.addRule( new KunGaugeRule(rule.value,rule.operation,rule.color1,rule.color2) );
            })
        }
        KunActionGauge.add( gauge );
    });
};

/**
 * @returns Number
 */
KunActionGauge.weight = function () {
    return this._weight;
};

/**
 * @param {String} gauge 
 * @returns Boolean
 */
KunActionGauge.isActive = function (gauge) {
    return this.has(gauge) && this.gauges()[gauge].visible();
};
/**
 * @param {String} gauge 
 * @param {Boolean} active 
 * @param {String} location
 * @param {Number} amount
 * @returns KunActionGauge
 */
KunActionGauge.display = function (name, active, location = '' , amount = 0 ) {
    if (this.has(name)) {
        var gauge = this.gauges()[name];
        if( typeof active === 'boolean' && active ){
            const position = KunActionGauge.isLocation(location) ? location : gauge.location();
            const fill = location === 'fill';
            const reset = location === 'reset' || fill;
            if( reset ){
                gauge.reset( amount || gauge.target() , fill );
            }
            if( !gauge.visible() ){
                gauge.display(this.countByLocation(position),position);
            }
        }
        else{
            gauge.close();
        }
    }
    return this;
};
/**
 * @returns {KunActionGauge}
 */
KunActionGauge.closeAll = function () {
    this.active().forEach(function (gauge) {
        gauge.close();
    });
    return this;
};
/**
 * @returns {KunGauge[]}
 */
KunActionGauge.active = function () {
    return this.gauges(true).filter(gauge => gauge.visible());
};
/**
 * @param {Number} gameVar 
 * @returns 
 */
KunActionGauge.updateGauges = function ( gameVar ) {
    this.active().filter(gauge => gauge.has( gameVar ) ).forEach( gauge => gauge.refresh() );
    return this;
};
/**
 * @param {string} location 
 * @returns Number
 */
KunActionGauge.countByLocation = function (location) {
    return this.active().filter(gauge => gauge.location() === location).length;
};

KunActionGauge.dump = function () { return _gauge; }
KunActionGauge.debug = function () { return this._debug; };
KunActionGauge.background = function () { return this._background; };

KunActionGauge.Color = {
    'Base': 1,
    'Overlay': 4
};

KunActionGauge.Location = {
    'TOP': 'top',
    'BOTTOM': 'bottom',
    'LEFT': 'left',
    'RIGHT': 'right',
    'CENTER': 'center',
};
/**
 * @param {String} location 
 * @returns Boolean
 */
KunActionGauge.isLocation = function (location) {
    return typeof location === 'string' && location.length && Object.values(KunActionGauge.Location).includes(location);
};
/**
 * @returns Object
 */
KunActionGauge.PluginData = function () {
    function _parsePluginData ( key , value ) {
        if (typeof value === 'string' && value.length ) {
            try {
                if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                    return JSON.parse(value, _parsePluginData );
                }
            } catch (e) {
                // If parsing fails or it's not an object/array, return the original value
            }
            if( value === 'true' || value === 'false'){
                return value === 'true';
            }
            if( !isNaN(value) ){
                return parseInt(value);
            }
        }
        else if( typeof value === 'object' && !Array.isArray(value) ){
            var _output = {};
            Object.keys( value ).forEach( function(key ){
                _output[key] = _parsePluginData( key , value[key] );
            });
            return _output;
        }
        return value;
    };

    return _parsePluginData( 'KunActionGauge', PluginManager.parameters('KunActionGauge'));    
};
/**
 * @param {String|Object} message 
 */
KunActionGauge.DebugLog = (message) => {
    if (KunActionGauge.debug()) {
        console.log('[ KunActiojnGauge ] ' , message );
    }
};

/**
 * @param {String} name 
 * @param {String} location 
 * @param {Number} valueVar 
 * @param {Number} targetVar 
 * @param {Number} color1 
 * @param {Number} color2 
 */
function KunGauge(name, location, valueVar, targetVar, color1, color2) {
    this._name = name.toLowerCase().replace(/\-\s/, '_');
    this._location = location || KunActionGauge.Location.TOP;
    this._valueVar = valueVar;
    this._targetVar = targetVar;
    this._color1 = color1 || 1;
    this._color2 = color2 || 4;
    this._rules = [
        //add rules here
    ];
    this._window = null;
};
/**
 * @param {Number} amount
 * @param {Boolean} fill
 * @returns {KunGauge}
 */
KunGauge.prototype.reset = function( amount , fill = false ){
    
    if( typeof amount === 'number' && amount ){
        $gameVariables.setValue( this.target(true) , amount );
        $gameVariables.setValue( this.value( true ), fill ? amount : 0);
    }

    return this;
};
/**
 * @param {Number} index 
 * @param {String} location 
 * @returns KunGauge
 */
KunGauge.prototype.display = function (index, location) {
    var colors = this.colors();
    this._window = new Window_ActionGauge(
        this.name(),
        location || this._location,
        this.value(true),
        this.target(true),
        colors[0], colors[1], index);
    //register the gauge in the scene
    SceneManager._scene.addChild(this._window);
    return this;
};
/**
 * @returns KunGauge
 */
KunGauge.prototype.close = function () {
    if (this.visible()) {
        this._window.close();
        this._window = null;
    }
    return this;
};
/**
 * @returns KunGauge
 */
KunGauge.prototype.refresh = function(){
    if( this.visible() ){
        this._window.renderGauge();
    }
    return this;
};
/**
 * @returns Boolean
 */
KunGauge.prototype.visible = function () {
    return this._window !== null;
};
/**
 * @param {Boolean} validate
 * @returns KunGaugeRule[]
 */
KunGauge.prototype.rules = function (validate) {
    if (typeof validate === 'boolean' && validate) {
        var progress = this.progress();
        return this.rules().filter(rule => rule.match(progress));
    }
    return this._rules;
};
/**
 * @returns KunGauge
 */
KunGauge.prototype.addRule = function (rule) {
    if (rule instanceof KunGaugeRule) {
        this._rules.push(rule);
    }
    return this;
};
/**
 * @returns String
 */
KunGauge.prototype.toString = function () {
    return this.name();
};
/**
 * @returns String
 */
KunGauge.prototype.name = function () {
    return this._name;
};
/**
 * Returns the current display location, which can be the original gauge's location or a user custom location
 * @returns String
 */
KunGauge.prototype.location = function(){
    return this.visible() ? this._window.location() : this._location;
};
/**
 * @param {Boolean} getVar Get the game variable instead the value
 * @returns Number
 */
KunGauge.prototype.value = function ( getVar ) {
    return typeof getVar === 'boolean' && getVar ? this._valueVar : $gameVariables.value(this._valueVar);
};
/**
 * @param {Boolean} getVar Get the game variable instead the value
 * @returns Number
 */
KunGauge.prototype.target = function ( getVar ) {
    return typeof getVar === 'boolean' && getVar ? this._targetVar : $gameVariables.value(this._targetVar);
};
/**
 * @param {Number} gameVariable 
 * @returns Boolean
 */
KunGauge.prototype.has = function( gameVariable ){
    return this.value(true) === gameVariable || this.target(true) === gameVariable;
}
/**
 * @returns {Number|Float|Int}
 */
KunGauge.prototype.progress = function () {
    return this.target() > 0 ? Math.floor(this.value() / parseFloat(this.target()) * 100) : 0;
};
/**
 * @returns Number
 */
KunGauge.prototype.color1 = function () {
    return this._color1;
};
/**
 * @returns Number
 */
KunGauge.prototype.color2 = function () {
    return this._color2;
};
/**
 * @returns Number[]
 */
KunGauge.prototype.colors = function () {
    var rules = this.rules(true);
    return rules.length ? rules[0].colors() : [this.color1(), this.color2()];
};
/**
 * @returns Boolean
 */
KunGauge.prototype.isValid = function () {
    return this.value(true) > 0 && this.target(true) > 0;
};

/**
 * @param {Number} progress % 
 * @param {String} operation 
 * @param {Number} color1 
 * @param {Number} color2 
 */
function KunGaugeRule(progress, operation, color1, color2) {
    this._progress = progress || 0;
    this._operation = operation || KunGaugeRule.Operation.Equal;
    this._color1 = color1 || 0;
    this._color2 = color2 || 4
};
/**
 * @returns Number
 */
KunGaugeRule.prototype.color1 = function () {
    return this._color1;
};
/**
 * @returns Number
 */
KunGaugeRule.prototype.color2 = function () {
    return this._color2;
};
/**
 * @returns Number[]
 */
KunGaugeRule.prototype.colors = function () {
    return [this.color1(), this.color2()];
};
/**
 * @returns String
 */
KunGaugeRule.prototype.operation = function () {
    return this._operation;
};
/**
 * @returns Number
 */
KunGaugeRule.prototype.progress = function () {
    return this._progress;
};
/**
 * @param {Number} value 
 * @returns Boolean
 */
KunGaugeRule.prototype.match = function (value) {
    switch (this.operation()) {
        case KunGaugeRule.Operation.Greater:
            return value > this.progress();
        case KunGaugeRule.Operation.GreaterEqual:
            return value >= this.progress();
        case KunGaugeRule.Operation.Equal:
            return value === this.progress();
        case KunGaugeRule.Operation.LowerEqual:
            return value <= this.progress();
        case KunGaugeRule.Operation.Lower:
            return value < this.progress();
    }
    return false;
};
/**
 * 
 */
KunGaugeRule.Operation = {
    'Greater': 'greater',
    'GreaterEqual': 'greater_equal',
    'Equal': 'equal',
    'LowerEqual': 'less_equal',
    'Lower': 'less',
};

/********************************************************************************************************************
 * 
 * INTERFACE MODS
 * 
 *******************************************************************************************************************/

function Window_ActionGauge() {
    this.initialize.apply(this, arguments);
}

Window_ActionGauge.prototype = Object.create(Window_Base.prototype);
Window_ActionGauge.prototype.constructor = Window_Message;

Window_ActionGauge.prototype.initialize = function (name , location, valueVar, targetVar, color1, color2, index) {

    this._name = name;
    this._index = typeof index === 'number' && index > 0 ? index : 0;
    this._location = location || KunActionGauge.Location.BOTTOM;
    this._valueVar = valueVar || 0;
    this._targetVar = targetVar || 0;
    this._baseColor = color1 >= 0 ? color1 : KunActionGauge.Color.Base;
    this._overlayColor = color2 >= 0 ? color2 : KunActionGauge.Color.Overlay;

    var width = this.getLocationWidth(this.location())
    var height = this.getLocationHeight(this.location())
    var x = this.getLocationX(this.location(), this._index)
    var y = this.getLocationY(this.location(), this._index)

    Window_Base.prototype.initialize.call(this, x, y, width, height);

    this.initMembers();
    this.setBackgroundType(this._background);
    this.renderGauge();
};
/**
 * @returns String
 */
Window_ActionGauge.prototype.name = function(){
    return this._name;
};
/**
 * @returns KunGauge
 */
Window_ActionGauge.prototype.getGauge = function(){
    return KunActionGauge.has( this.name() ) ? KunActionGauge.gauges()[this.name()] : null;
};
/**
 * @returns Number[]
 */
Window_ActionGauge.prototype.colors = function(){
    var gauge = this.getGauge();
    return gauge !== null ? gauge.colors() : [this._baseColor,this._overlayColor];
};
/**
 * @returns String
 */
Window_ActionGauge.prototype.location = function(){
    return this._location;
};

Window_ActionGauge.prototype.initMembers = function () {
    this._imageReservationId = Utils.generateRuntimeId();
    this._background = KunActionGauge.background();
    this._positionType = 2;
    this._waitCount = 0;
    this._faceBitmap = null;
    this._textState = null;

    //this.clearFlags();
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.progress = function () {
    var value = this.value();
    var target = this.target();
    if ( target > 0) {
        return value < target ? value / parseFloat(target) : 1;
    }
    return 0;
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.value = function(){
    //prevent negative values for rendering progress
    return this._valueVar > 0 ? Math.abs($gameVariables.value(this._valueVar)) : 0;
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.target = function(){
    return this._targetVar > 0 ? Math.abs($gameVariables.value(this._targetVar)) : 1;
};
/**
 * 
 */
Window_ActionGauge.prototype.renderGauge = function () {
    var colors = this.colors();
    var color1 = this.textColor(colors[0]);
    var color2 = this.textColor(colors[1]);
    var x = 0;
    var y = 0;
    var progress = this.progress();

    switch (this.location()) {
        case KunActionGauge.Location.TOP:
        case KunActionGauge.Location.BOTTOM:
        case KunActionGauge.Location.CENTER:
            this.drawHorizontalGauge(x, y, this.getGaugeWidth(), progress, color1, color2);
            break;
        case KunActionGauge.Location.LEFT:
        case KunActionGauge.Location.RIGHT:
            this.drawVerticalGauge(x, y, this.getGaugeHeight(), progress, color1, color2);
            break;
    }
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.getGridWidth = function(){
    return Graphics.boxWidth / 12;
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.getGridHeight = function(){
    return Graphics.boxHeight / 12;
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.getGaugeWeight = function(){
    return KunActionGauge.weight();
};
/**
 * @returns Number
 */
Window_ActionGauge.prototype.getGaugeWidth = function(){
    return this.getGridWidth() * 6 + KunActionGauge.offsetLength();
}
/**
 * @returns Number
 */
Window_ActionGauge.prototype.getGaugeHeight = function(){
    return this.getGridHeight() * 6 + KunActionGauge.offsetLength();
};

Window_ActionGauge.prototype.getLocationWidth = function (location) {
    switch (location) {
        case KunActionGauge.Location.TOP:
        case KunActionGauge.Location.BOTTOM:
        case KunActionGauge.Location.CENTER:
            return this.getGaugeWidth();
        case KunActionGauge.Location.RIGHT:
        case KunActionGauge.Location.LEFT:
            return this.getGaugeWeight() * 2;
    }
    return this.getGaugeWidth();
};
Window_ActionGauge.prototype.getLocationHeight = function (location) {
    switch (location) {
        case KunActionGauge.Location.TOP:
        case KunActionGauge.Location.BOTTOM:
        case KunActionGauge.Location.CENTER:
            return this.getGaugeWeight() * 2;
        case KunActionGauge.Location.RIGHT:
        case KunActionGauge.Location.LEFT:
            return this.getGaugeHeight();
    }
    return 0;
};
Window_ActionGauge.prototype.getLocationX = function (location, index) {
    index = typeof index === 'number' && index > 0 ? index * 2 : 0;
    switch (location) {
        case KunActionGauge.Location.TOP:
        case KunActionGauge.Location.BOTTOM:
        case KunActionGauge.Location.CENTER:
            return this.getGridWidth() * 3;
        case KunActionGauge.Location.RIGHT:
            return Graphics.boxWidth - (this.getGaugeWeight() * (index + 3)) - KunActionGauge.offsetX();
        case KunActionGauge.Location.LEFT:
            return this.getGaugeWeight() * (index + 1) + KunActionGauge.offsetX();
        //return (Graphics.boxWidth / 12) - Window_ActionGauge.getGaugeWeight();
    }
    return 0;
};
Window_ActionGauge.prototype.getLocationY = function (location, index) {
    index = typeof index === 'number' && index > 0 ? index * 2 : 0;
    switch (location) {
        case KunActionGauge.Location.TOP:
            return this.getGridHeight() + (this.getGaugeWeight() * index) + KunActionGauge.offsetY();
        case KunActionGauge.Location.BOTTOM:
            return this.getGridHeight() * 10 - (this.getGaugeWeight() * index) - KunActionGauge.offsetY();
        case KunActionGauge.Location.CENTER:
            return this.getGridHeight() * 5 + (this.getGaugeWeight() * index);
            //return this.getGridHeight() + (5 + Window_ActionGauge.getGaugeWeight() * index);
        case KunActionGauge.Location.RIGHT:
        case KunActionGauge.Location.LEFT:
            return this.getGridHeight() * 2 + KunActionGauge.offsetY();
    }
    return 0;
};

Window_ActionGauge.prototype.drawHorizontalGauge = function (x, y, width, progress, color1, color2) {
    var progressBar = Math.floor(width * progress);
    var weight = this.getGaugeWeight();
    this.contents.fillRect(x, y, width, weight, this.gaugeBackColor());
    this.contents.gradientFillRect(x, y, progressBar, weight, color1, color2);
};

Window_ActionGauge.prototype.drawVerticalGauge = function (x, y, height, progress, color1, color2) {
    var progressBar = Math.floor(height * progress);
    var weight = this.getGaugeWeight();
    this.contents.fillRect(x, y, weight, height, this.gaugeBackColor());
    this.contents.gradientFillRect(x, y + height - progressBar, weight, progressBar, color1, color2);
};

Window_ActionGauge.prototype.standardFontSize = function(){
    return this.getGaugeWeight();
};
Window_ActionGauge.prototype.standardPadding = function(){
    return this.getGaugeWeight() / 2;
};
Window_ActionGauge.prototype.textPadding = function(){
    return this.getGaugeWeight() / 2;
};

/********************************************************************************************************************
 * 
 * FUNCTIONS
 * 
 *******************************************************************************************************************/

/**
 * 
 */
function KunActionGauge_HookVariables() {
    //override game variables
    var _KunActionGauge_GameVariables_SetValue = Game_Variables.prototype.setValue;
    Game_Variables.prototype.setValue = function( variableId , value ){
        _KunActionGauge_GameVariables_SetValue.call(this , variableId , value );
        KunActionGauge.updateGauges( variableId );
    };
    /*Game_Variables.prototype.setValue = function (variableId, value) {
        //vanilla
        if (variableId > 0 && variableId < $dataSystem.variables.length) {
            if (typeof value === 'number') {
                value = Math.floor(value);
            }
            this._data[variableId] = value;
            this.onChange();
        }
        KunActionGauge.updateGauges(variableId);
    };*/
}
/**
 * 
 */
function KunActionGauge_SetupCommands() {
    var KunGaugePluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        KunGaugePluginCommand.call(this, command, args);
        if (command === 'KunActionGauge') {
            if (args && args.length) {
                switch (args[0]) {
                    case 'show':
                    case 'display':
                        if (args.length > 1) {
                            var gauges = args[1].split(':');
                            var location = args.length > 2 ? args[2] : '';
                            var values = args.length > 3 ? args[3].split(':').map( v => parseInt(v)) : [0];
                            var amount = values.length > 1 ? values[Math.floor(Math.random() * values.length)] : values[0];
                            gauges.forEach(function (gauge) {
                                KunActionGauge.display(gauge, true, location, amount );
                            });
                        }
                        break;
                    case 'close':
                        if (args.length > 1) {
                            var gauges = args[1].split(':');
                            gauges.forEach(function (gauge) {
                                KunActionGauge.display(gauge, false);
                            });
                        }
                        else {
                            KunActionGauge.closeAll();
                        }
                        break;
                }
            }
        }
    };
};


/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunActionGauge.initialize();
    //KunActionGauge.DebugLog( 'ready!' );
    KunActionGauge_HookVariables();
    //OVERRIDE COMMAND INTERPRETER
    KunActionGauge_SetupCommands();

})( /* initializer */);


