//=============================================================================
// KunGuests.js
//=============================================================================
/*:
 * @filename KunGuests.js
 * @plugindesc Add Randomly generated Hirelings by class and generic NPCs to the party. Handle the party max size in game!
 * @version 1.25
 * @author Kun
 * 
 * @help
 * 
 * Add Guest Actors to the Followers queue.
 * 
 * They won't fight, they can be joined several times (as much as Maximum Guests are allowed).
 * 
 * Define the guests which can be joined in Allowed Followers list.
 * 
 * Set the actor 
 * 
 * COMMANDS
 * 
 *  KunGuest add actor_id [amount]
 *  - Add an actor ID to the guest followers.
 *  - Define how many by number if required.
 * 
 *  KunGuest remove actor_id [all]
 *  - Remove an actor from the guest followers
 *  - Remove them all if required. (optional)
 * 
 *  KunGuest count game_var actor_id
 *  - Count how many guests are in party
 *  - Filter guest count by actor_id
 * 
 *  KunGuest max game_var
 *  - Export the maximum available guests in party
 * 
 * @param maxGuests
 * @text Maximum Guests
 * @desc How many guests can follow?
 * @type number
 * @min 0
 * @max 10
 * @default 0
 * 
 * @param allowed
 * @text Allowed Guests
 * @desc Allow to "guest" these followers only.
 * @type actor[]
 * 
 * @param debug
 * @text Debug Mode
 * @type Boolean
 * @default false
 * 
 * 
 */

function KunGuests() {
    throw `${this.constructor.name} is a Static Class`;
}

KunGuests.Initialize = function () {

    var _parameters = this.pluginData();

    this._debug = _parameters.debug === 'true';
    this._max = parseInt(_parameters.maxGuests);
    this._guests = (_parameters.allowed.length > 0 ? JSON.parse(_parameters.allowed) : []).map(actor_id => parseInt(actor_id));
};
/**
 * @returns Boolean
 */
KunGuests.debug = function () {
    return this._debug;
};
/**
 * @param {String|Object} message 
 */
KunGuests.DebugLog = function( message ){
    if( this.debug() ){
        console.log('[ KunGuests ] ' , message );
    }
};
/**
 * @returns Number
 */
KunGuests.max = function () {
    return this._max;
};
/**
 * @returns Number
 */
KunGuests.guests = function () {
    return this._guests;
};
/**
 * @returns Boolean
 */
KunGuests.has = function (actor_id) {
    return typeof actor_id === 'number' && actor_id > 0 ? this.guests().includes(actor_id) : false;
};
/**
 * @returns Object
 */
KunGuests.pluginData = function () {
    return PluginManager.parameters('KunGuests');
};
/**
 * 
 */
KunGuests_SetupGameParty = function () {
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.isGuest = function () {
        return KunGuests.has(this.actorId());
    };
    /**
     * @param {Number} actorId 
     */
    const _KunGuests_GameParty_Initialize = Game_Party.prototype.initialize;
    Game_Party.prototype.initialize = function () {
        _KunGuests_GameParty_Initialize.call(this);
        this.setupGuests();
    };
    /**
     * @returns Number
     */
    Game_Party.prototype.maxGuests = function(){
        return KunGuests.max();
    };
    /**
     * 
     */
    Game_Party.prototype.setupGuests = function(){
        this._guests = [];
        for(var i = 0 ; i < this.maxGuests() ; i++ ){
            this._guests.push(0);
        }
    };
    /**
     * @param {Number} actorId 
     * @returns Boolean
     */
    Game_Party.prototype.addGuest = function( actorId ){
        if( KunGuests.has(actorId)){
            for(var i = 0; i < this._guests.length ; i++ ){
                if( this._guests[i] < 1 ){
                    this._guests[i] = actorId;
                    return true;
                }
            }
        }
        return false;
    };
    /**
     * @param {Number} actorId 
     * @returns Boolean
     */
    Game_Party.prototype.removeGuest = function( actorId ){
        var found = false;
        if( KunGuests.has(actorId) && this._guests.includes( actorId ) ){
            for( var i = 0 ; i < this._guests.length ; i++ ){
                if( this._guests[i] === actorId ){
                    found = true;
                }
                if( found ){
                    this._guests[ i ] = i < this._guests.length - 1 ? this._guests[ i + 1] : 0;
                }
            }
        }
        return found;
    };
    /**     * @returns Number[] | Array
     */
    Game_Party.prototype.guests = function( ){
        return this._guests.filter( actorId => actorId > 0 );
    };
    /**
     * @param {Number} guestId 
     * @returns Number
     */
    Game_Party.prototype.countGuests = function( guestId ){
        return (typeof guestId === 'number' && guestId > 0 ?
            this.guests().filter( actorId => actorId === guestId ) :
            this.guests() ).length;
    };
    /**
     * @param {Number} actorId 
     */
    const _KunGuests_GameParty_AddActor = Game_Party.prototype.addActor;
    Game_Party.prototype.addActor = function (actorId) {
        if (KunGuests.has(actorId)) {
            this.addGuest( actorId );
            $gamePlayer.refresh();
            $gameMap.requestRefresh();
            KunGuests.DebugLog(`Joined Guest ${actorId}`);
        }
        else{
            _KunGuests_GameParty_AddActor.call(this,actorId);
            KunGuests.DebugLog(`Joined Actor ${actorId}`);
        }
    };
    /**
     * @param {Number} actorId 
     */
    const _KunGuests_GameParty_RemoveActor = Game_Party.prototype.removeActor;
    Game_Party.prototype.removeActor = function (actorId) {
        if (KunGuests.has(actorId)) {
            this.removeGuest( actorId );
            $gamePlayer.refresh();
            $gameMap.requestRefresh();
            KunGuests.DebugLog(`Removed Guest ${actorId}`);
        }
        else{
            _KunGuests_GameParty_RemoveActor.call(this,actorId);
            KunGuests.DebugLog(`Removed Actor ${actorId}`);
        }
    };
    /**
     * @param {Boolean} includeGuests
     * @return Number[]|Array
     */
    Game_Party.prototype.followers = function( includeGuests  ){
        //const followers = this.size() > 0 ? this._actors.slice(1).map( (id,idx) => idx ) : [];
        const followers = this.size() > 0 ? this._actors.slice(1) : [];
        return typeof includeGuests === 'boolean' ? followers.concat( this.guests() ) : followers;
    };
    /**
     * @returns Number
     */
    Game_Party.prototype.maxFollowers = function(){
        //remove the party leader
        return this.maxBattleMembers() + this.maxGuests() - 1;
    };

    //////////////////////////////////////////////////////////////////////////////////////////////
    //// GAME FOLLOWERS 
    //////////////////////////////////////////////////////////////////////////////////////////////
    var _KunGuests_GameFollowers_Initialize = Game_Followers.prototype.initialize;
    Game_Followers.prototype.initialize = function () {

        _KunGuests_GameFollowers_Initialize.call(this);

        for (var i = 0; i < $gameParty.maxGuests(); i++) {
            //add guest slots (reset to 0)
            this._data.push(new Game_Follower(-1));
        }
    };
    /**
     * Override
     */
    Game_Followers.prototype.refresh = function() {
        var followers = $gameParty.followers( true );
        var memberCount = $gameParty.followers( ).length;
        for( var i = 0 ; i < this._data.length ; i++ ){
            if( i < memberCount ){
                //refresh all party members
                this._data[i].reset( i + 1 , false );
            }
            else if( i < followers.length ){
                //refresh all guests
                this._data[i].reset( followers[ i ] , true );
            }
            else{
                //reset and hide all remaining instances
                this._data[i].reset();
            }
            this._data[i].refresh();
        }
        KunGuests.DebugLog(this._data.map(d => d._memberIndex )) ;
        //vanilla
        /*this.forEach(function(follower) {
            return follower.refresh();
        }, this);*/
    };

    //OVERRIDING GAME FOLLOWER

    var _KunGuests_GameFollower_Initialize = Game_Follower.prototype.initialize;
    Game_Follower.prototype.initialize = function(memberIndex){
        this._guest = false;
        _KunGuests_GameFollower_Initialize.call(this,memberIndex);
    };

    var _KunGuests_GameFollower_isVisible = Game_Follower.prototype.isVisible;
    Game_Follower.prototype.isVisible = function(){
        //define visible if is guest or call the default method if not
        return this.isGuest() || _KunGuests_GameFollower_isVisible.call(this);
    };
    /**
     * @returns Number
     */
    Game_Follower.prototype.memberIndex = function () {
        return this._memberIndex;
    };
    /**
     * @param {Number} memberIndex 
     * @param {Boolean} guest 
     */
    Game_Follower.prototype.reset = function( memberIndex , guest ){
        this._memberIndex = typeof memberIndex === 'number' && memberIndex > 0 ? memberIndex : -1;
        this._guest = typeof guest === 'boolean' && guest;
    };
    /**
     * Here's the big deal, a guest can use a party member slot below maxBattleMembers when the party is not full.
     * If we added the guests after the maxBattleMembers always, the guests would leave empty party character slots ;R
     * 
     * @param {Number} actorId (optional to check actorId verification)
     * @returns Boolean
     */
    Game_Follower.prototype.isGuest = function ( actorId ) {
        //member index must be more than 0 to validate
        if( this._guest && KunGuests.has(this.memberIndex()) ){
            return typeof actorId === 'number' && actorId > 0 ? this.memberIndex() === actorId : true;
        }
        return false;
    };
    /**
     * And here's another big gap
     * visible members defined my maxBattleMembers
     * invisible members are in background, not rendered
     * then come the guest members ;D which are visible again, but the party slot id gaps are big.
     * 
     * 
     * @returns Game_Actor
     */
    const _KunGuests_GameFollower_Actor =  Game_Follower.prototype.actor;
    Game_Follower.prototype.actor = function () {
        return this.isGuest() ?
            //return guest from GameActors
            $gameActors.actor(this.memberIndex()) :
            //return member from GameParty
            _KunGuests_GameFollower_Actor.call(this);
    };
    var _KunGuests_GameFollower_Update = Game_Follower.prototype.update;
    Game_Follower.prototype.update = function () {
        _KunGuests_GameFollower_Update.call(this);
        this.setStepAnime(this.isGuest());
    }
}


/**
 * 
 */
function KunGuests_SetupCommands() {
    var _KunGuests_Commands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunGuests_Commands.call(this, command, args);
        if (command === 'KunGuest' || command === 'KunGuests' ) {
            if (args && args.length) {
                switch (args[0]) {
                    case 'count':
                        if (args.length > 1) {
                            var gameVar = parseInt(args[1]);
                            var guests = $gameParty.countGuests(args.length > 2 ? parseInt(args[2]) : 0);
                            //var count = $gamePlayer.followers().countGuests(args.length > 2 ? parseInt(args[2]) : 0);
                            $gameVariables.setValue(gameVar, guests);
                        }
                        break;
                    case 'max':
                        if (args.length > 1) {
                            var gameVar = parseInt(args[1]);
                            $gameVariables.setValue(gameVar, $gameParty.maxGuests());
                        }
                        break;
                }
            }
        }
    };
}

(function () {

    KunGuests.Initialize();
    KunGuests_SetupGameParty();
    KunGuests_SetupCommands();

})();

















