//=============================================================================
// KunFullNames.js
//=============================================================================
/*:
 * @plugindesc KunFullNames
 * @filename KunFullNames.js
 * @author KUN
 * @version 1.05
 * 
 * @help
 * 
 * COMMANDS
 * 
 * KunFullNames title actor_id Title 1,Title 2,Title 3, ...
 *      Add titles to an actor by actor_id
 *      Add 1 or more titles at once, separated by commas
 * 
 * KunFullNames shortname actor_id ShortName
 *      Set actor_id's short name
 * 
 * KunFullNames lastname actor_id LastName
 *      Set actor_id's last name
 * 
 * KunFullNames import actor_id
 *      Import actor_id's full name (short name and last name) from the actor db template name
 *      Type in ActorName [ShortName] and LastName in the actor character data
 * 
 * KunFullNames reset actor_id|all import
 *      Reset actor_id's last name and short name
 *      Important to run after loading a saved game before activating the plugin to initialize the attributes
 *      Use import to reset the full name format according to the character data template definition
 * 
 * 
 * 
 * @param debug
 * @text Debug
 * @desc Show debug info
 * @type Boolean
 * @default false
 * 
 * @param pool
 * @text Name Generator Pool
 * @type struct<NameGen>[]
 * 
 * @param inputNameLimit
 * @text Input Name Size
 * @desc Override Input Name Size Limit
 * @type number
 * @min 0
 * @max 48
 * @default 0
 * 
 */
/*~struct~NameGen:
 * @param actor
 * @text Actor
 * @type actor
 * @min 0
 * @default 0
 * 
 * @param name
 * @text First Name
 * @type string[]
 * 
 * @param lastname1
 * @text Last Name 1
 * @type string[]
 * 
 * @param lastname2
 * @text Last Name 2
 * @type string[]
 * 
 * @param nickname1
 * @type string[]
 * @text Nick Name 1
 * 
 * @param nickname2
 * @type string[]
 * @text Nick Name 2
 */

function KunFullNames(){
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 */
KunFullNames.Initialize = function(){

    var parameters = this.parameters();

    this._debug = parameters.debug === 'true';
    this._inputNameLimit = parseInt(parameters.inputNameLimit);
    this._actors = [];

    return this.Import( (parameters.pool.length ? JSON.parse( parameters.pool ) : []).map( tpl => JSON.parse(tpl)) );
};
/**
 * @returns Number
 */
KunFullNames.InputNameLimit =function (){
    return this._inputNameLimit;
};
/**
 * @param {Number} actor_id 
 */
KunFullNames.ImportFullName = function( actor_id ){
    if( actor_id ){
        var fullName = $gameActors.actor(actor_id).name().split(' ');
        console.log(fullName);
        $gameActors.actor(actor_id).setName( fullName[0]);
        if( fullName.length > 2 ){
            $gameActors.actor(actor_id).setShortName( fullName[1]);
            $gameActors.actor(actor_id).setLastName( fullName[2]);
        }
        else if( fullName.length > 1 ){
            $gameActors.actor(actor_id).setLastName( fullName[1]);
        }    
    }
};
/**
 * 
 * @param {Object[]} pool 
 * @returns KunFullNames
 */
KunFullNames.Import = function( pool )
{
    pool.forEach( function( tpl ){
        KunFullNames.addActor(new KunCharTemplate(
            parseInt( tpl.actor ) ,
            tpl.name.length ? JSON.parse(tpl.name) : [''] ,
            tpl.lastname1.length ? JSON.parse(tpl.lastname1) : [''],
            tpl.lastname2.length ? JSON.parse(tpl.lastname2) : [''],
            tpl.nickname1.length ? JSON.parse(tpl.nickname1) : [''],
            tpl.nickname2.length ? JSON.parse(tpl.nickname2) : ['']
        ) );
    });

    return this;
};
/**
 * @returns KunCharTemplate[]
 */
KunFullNames.actors = function(){
    return this._actors;
};
/**
 * @param {KunCharTemplate} template
 * @returns KunFullNames
 */
KunFullNames.addActor = function( template ){
    if( template instanceof KunCharTemplate ){
        this._actors.push( template );
    }
    return this;
};
/**
 * @param {Number} actor_id 
 * @returns Object
 */
KunFullNames.generate = function( actor_id ){
    actor_id = typeof actor_id === 'number' && actor_id > 0 ? actor_id : 0;
    var pool = this.actors().filter( actor => actor.actorId() === actor_id );
    if( pool.length ){
        return pool.length > 1 ? pool[ Math.floor( Math.random() * pool.length )].export() : pool[0].export();
    }
    return {};
};
/**
 * @returns Object
 */
KunFullNames.parameters = function(){
    return  PluginManager.parameters('KunFullNames');
};
/**
 * 
 * @param {Number} actor_id
 * @param {String[]} name 
 * @param {String[]} last_name1 
 * @param {String[]} last_name2 
 * @param {String[]} nick_name1 
 * @param {String[]} nick_name2 
 */
function KunCharTemplate( actor_id , name, last_name1, last_name2,nick_name1,nick_name2){
    this._actor_id = actor_id || 0;
    this._first_name = Array.isArray( name ) && name.length ? name : ( typeof name === 'string' ? [name] : [''] );
    this._last_name1 = Array.isArray( last_name1 ) && last_name1.length  ? last_name1 : ( typeof last_name1 === 'string' ? [last_name1] : [''] );
    this._last_name2 = Array.isArray( last_name2 ) && last_name2.length  ? last_name2 : ( typeof last_name2 === 'string' ? [last_name2] : [''] );
    this._nickname1 = Array.isArray( nick_name1 ) && nick_name1.length  ? nick_name1 : ( typeof nick_name1 === 'string' ? [nick_name1] : [''] );
    this._nickname2 = Array.isArray( nick_name2 ) && nick_name2.length  ? nick_name2 : ( typeof nick_name2 === 'string' ? [nick_name2] : [''] );
};
/**
 * @returns String
 */
KunCharTemplate.prototype.toString = function(){
    return this.fullName();
};
/**
 * @param {Boolean} showTitle
 * @returns String
 */
KunCharTemplate.prototype.fullName = function( showTitle ){
    return typeof showTitle === 'boolean' && showTitle ?
        `${this.firstName()} ${this.lastName()}, ${this.nickName()}` :
        `${this.firstName()} ${this.lastName()}`;
};
/**
 * @returns Object
 */
KunCharTemplate.prototype.export = function(){
    return {
        'first_name': this.firstName(),
        'last_name': this.lastName(),
        'nick_name': this.nickName(),
    };
};
/**
 * @returns Number
 */
KunCharTemplate.prototype.actorId = function(){
    return this._actor_id;
};
/**
 * @returns String
 */
KunCharTemplate.prototype.firstName = function(){
    return this._first_name[ this._first_name.length > 1 ? Math.floor( Math.random() * this._first_name.length) : 0 ];
};
/**
 * @returns String
 */
KunCharTemplate.prototype.lastName = function(){
    var ln1 = this._last_name1[ this._last_name1.length > 1 ? Math.floor( Math.random() * this._last_name1.length) : 0 ];
    var ln2 = this._last_name2[ this._last_name2.length > 1 ? Math.floor( Math.random() * this._last_name2.length) : 0 ];
    switch( true ){
        case ln1.length > 0 && ln2.length > 0 && ln1 !== ln2:
            return Math.floor(Math.random() * 2 ) ? ln1 + ln2.toLowerCase() : ln2 + ln1.toLowerCase();
        case ln1.length > 0:
            return ln1;
        case ln2.length > 0:
            return ln2;
        default:
            return '';
    }
};
/**
 * @returns String
 */
KunCharTemplate.prototype.nickName = function(){
    var nn1 = this._nickname1[ this._nickname1.length > 1 ? Math.floor( Math.random() * this._nickname1.length) : 0 ];
    var nn2 = this._nickname2[ this._nickname2.length > 1 ? Math.floor( Math.random() * this._nickname2.length) : 0 ];
    switch( true ){
        case nn1.length > 0 && nn2.length > 0 && nn1 !== nn2:
            return nn1 + ' ' + nn2;
        case nn1.length > 0:
            return nn1;
        case nn2.length > 0:
            return nn2;
        default:
            return '';
    }
};
/**
 * 
 */
function KunFullNames_GameActor(){

    var _KunFullNames_GameActor_Init = Game_Actor.prototype.initMembers;
    Game_Actor.prototype.initMembers = function() {
        _KunFullNames_GameActor_Init.call(this);
        this.resetFullName();
        this.resetTitles();
    };
    /**
     * 
     * @returns Game_Actor
     */
    Game_Actor.prototype.resetFullName = function(){
        this._lastName = '';
        this._shortName = '';
        return this;
    };
    /**
     * @param {String} tag
     * @returns Game_Actor
     */
    Game_Actor.prototype.resetTitles = function( tag ) {
        this._kunTitles = typeof tag === 'string' && tag.length ? this.titles().filter( nn => !nn.tags.includes(tag)) : [];
        return this;
    };
    /**
     * @returns String
     */
    Game_Actor.prototype.lastName = function(){
        return this._lastName;
    };
    /**
     * @returns String
     */
    Game_Actor.prototype.shortName = function(){
        return this._shortName;
    };
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.hasLastName = function(){
        return this.lastName().length > 0;
    };
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.hasNickName = function(){
        return this.nickname().length > 0;
    };
    /**
     * @param {String} nickname 
     */
    Game_Actor.prototype.setNickname = function(nickname) {
        if( this._nickname.length > 0 ){
            this.addTitle(this._nickname);
        }
        this._nickname = nickname;
    };
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.hasShortName = function(){
        return this.shortName().length > 0;
    };
    /**
     * @param {String} lastName
     * @returns Game_Actor
     */
    Game_Actor.prototype.setLastName = function( lastName ){
        if( typeof lastName === 'string' && lastName.length > 0 && lastName !== this.lastName() ){
            this._lastName = lastName;
        }
        return this;
    };
    /**
     * @param {String} shortName
     * @returns Game_Actor
     */
    Game_Actor.prototype.setShortName = function( shortName ){
        if( typeof shortName === 'string' && shortName.length > 0 && shortName !== this.shortName() ){
            this._shortName = shortName;
        }
        return this;
    };
    /**
     * @param {Boolean} showNickName
     * @returns String
     */
    Game_Actor.prototype.fullName = function( showNickName ){
        showNickName = this.hasNickName() && typeof showNickName === 'boolean' && showNickName;
        switch( true ){
            case this.hasLastName() && showNickName:
                return `${this.name()} ${this.lastName()}, ${this.nickname()}`;
            case this.hasLastName():
                return `${this.name()} ${this.lastName()}`;
            case showNickName:
                return `${this.name()} ${this.nickname()}`;
            default:
                return this.name();
        }
    };
    /**
     * 
     * @param {String} title 
     * @returns Boolean
     */
    Game_Actor.prototype.hasTitle = function( title ) {
        return this.titles().map( nn => nn.title ).filter( nn => nn === title ).length > 0;
    }
    /**
     * @param {String} title 
     * @param {String|String[]} tags 
     * @returns Game_Actor
     */
    Game_Actor.prototype.addTitle = function( title , tags ) {
        if( !this.hasTitle()){
            this._kunTitles.push({
                'title':title,
                'tags': Array.isArray(tags) && tags.length ? tags : (typeof tags === 'string' && tags.length ? tags.split(':') : []),
            });                
        }
        return this;
    };
    /**
     * @returns String[]
     */
    Game_Actor.prototype.titles = function( ) {
        return this._kunTitles;
    };
    /**
     * @param {String} tag 
     * @returns String
     */
    Game_Actor.prototype.selectTitle = function( tag ) {
        var selection = typeof tag === 'string' && tag.length ?
            this.titles().filter( nn => nn.tags.includes(tag)).map( nn => nn.title ) :
            this.titles().filter( nn => nn.tags.length === 0 ).map( nn => nn.title );
        selection.push( this._nickname);
        return selection.length > 1 ? selection[ Math.floor(Math.random() * selection.length )] : selection[0];
    };
    /**
     * @returns String
     */
    Game_Actor.prototype.title = function( tag ) {
        return typeof tag === 'string' ? this.selectTitle( tag ) : this.nickname();
    };    
}
/**
 * 
 */
function KunFullNames_PluginCommands(){
    var _KunFullNames_CommandInterpreter = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunFullNames_CommandInterpreter.call(this, command, args);
        if( command === 'KunFullNames' && args.length > 1 ){
            switch( args[0] ){
                case 'title':
                    var target = args[1].split(':');
                    var nicknames = args.slice( 2 , args.length).join(' ').split(',');
                    var actor_id = parseInt(target.shift());
                    if( !Number.isNaN(actor_id) && actor_id > 0 ){
                        nicknames.forEach( function(nn){
                            $gameActors.actor(actor_id).addTitle( nn , target );
                        });    
                    }
                    break;
                case 'shortname':
                    var actor_id = parseInt( args[1] );
                    if( args.length > 2 && !Number.isNaN(actor_id) && actor_id > 0 ){
                        $gameActors.actor(actor_id).setShortName( args[2] );
                    }
                    break;
                case 'lastname':
                    var actor_id = parseInt( args[1] );
                    if( args.length > 2 && !Number.isNaN(actor_id) && actor_id > 0 ){
                        $gameActors.actor(actor_id).setLastName( args[2] );
                    }
                    break;
                case 'import':
                    //import from the base game name character template
                    if( args.length > 1 ){
                        KunFullNames.ImportFullName( parseInt(args[1]));
                    }
                    break;
                case 'reset':
                    //reset short and last names (do it after loading a saved game)
                    if( args.length > 1 ){
                        if( args[1] === 'all'){
                            var importFullName = args.leader > 2 && args[2] === 'import';
                            $gameActors._data.filter( actor => actor !== null ).forEach( function( actor ){
                                actor.resetFullName().resetTitles();
                                if(importFullName){
                                    KunFullNames.ImportFullName( actor.actorId() );
                                }
                            });
                        }
                        else{
                            var actor_id = parseInt(args[1]);
                            if( actor_id ){
                                $gameActors.actor(actor_id).resetFullName().resetTitles();
                                if(args.length > 2 && args[2] === 'import' ){
                                    KunFullNames.ImportFullName( actor_id );
                                }
                            }    
                        }
                    }
                    break;
            }
        }
    }
}
/**
 * 
 */
function KunFullNames_EscapeChars(){
    var _KunFullNames_EscapeCharacters = Window_Base.prototype.convertEscapeCharacters;

    Window_Base.prototype.convertEscapeCharacters = function (text) {
        var parsed = _KunFullNames_EscapeCharacters.call(this, text);
        
        parsed = parsed.replace(/\x1bAN\[(.+)\]/gi, function () {
            return this.displayNickName(parseInt(arguments[1]) );
        }.bind(this));

        parsed = parsed.replace(/\x1bAT\[(.+)\]/gi, function () {
            var scope = arguments[1].split(':');
            return this.displayTitle(parseInt(scope[0]),scope.length > 1 ? scope[1] : '' );
        }.bind(this));

        parsed = parsed.replace(/\x1bFN\[(.+)\]/gi, function () {
            var actor_id = parseInt(arguments[1]);
            return this.displayFullName( actor_id );
        }.bind(this));

        parsed = parsed.replace(/\x1bFNN\[(.+)\]/gi, function () {
            var actor_id = parseInt(arguments[1]);
            return this.displayFullName( actor_id , true );
        }.bind(this));

        parsed = parsed.replace(/\x1bSN\[(.+)\]/gi, function () {
            var actor_id = parseInt(arguments[1]);
            return this.displayShortName( actor_id );
        }.bind(this));

        parsed = parsed.replace(/\x1bANL\[(.+)\]/gi, function () {
            var actor_id = parseInt(arguments[1]);
            return this.displayTitleList( actor_id );
        }.bind(this));

        return parsed;
    };

    Window_Base.prototype.displayShortName = function ( actor_id ) {
        return $gameActors.actor( actor_id ).shortName( );
    };

    Window_Base.prototype.displayNickName = function ( actor_id ) {
        return $gameActors.actor( actor_id ).nickname( );
    };

    Window_Base.prototype.displayTitle = function ( actor_id , tags ) {
        return $gameActors.actor( actor_id ).title( tags );
    };

    Window_Base.prototype.displayTitleList = function ( actor_id ) {
        return $gameActors.actor( actor_id ).titles().map( t => t.title ).join(', ');
    };

    Window_Base.prototype.displayFullName = function ( actor_id , showTitle ) {
        return $gameActors.actor( actor_id ).fullName( showTitle );
    };

}

//-----------------------------------------------------------------------------
// Scene_LastName
//
// The scene class of the name input screen.
function KunFullNames_SceneFullName(){
    //override size limit
    Scene_Name.prototype.prepare = function(actorId, maxLength) {
        this._actorId = actorId;
        this._maxLength = KunFullNames.InputNameLimit() || maxLength;
    };
    //override to capture last name
    Scene_Name.prototype.onInputOk = function() {
        var fullName = this._editWindow.name().split(' ');
        console.log( fullName);
        this._actor.setName(fullName[0]);
        if( fullName.length > 1 ){
            //add last name on space selection
            if( fullName.length > 2 ){
                //add shortname if 3 or more words
                this._actor.setShortName(fullName[1]);
                this._actor.setLastName(fullName[2]);
            }
            else{
                this._actor.setLastName(fullName[1]);
            }
        }
        this.popScene();
    };
    //override window width if added more space for name
    Window_NameEdit.prototype.windowWidth = function() {
        return KunFullNames.InputNameLimit() > 16 ? Graphics.boxWidth - 64 : 480;
    };

    Window_NameEdit.prototype.drawFullNameTips = function(){
        this.changeTextColor(this.textColor(8));
        this.makeFontSmaller();
        this.drawText( 'FirstName (ShortName) LastName', 164 , 96 , this.windowWidth() - 144 );
        this.makeFontBigger();
        this.resetTextColor();
    };

    var _KunFullNames_WindowNameEdit_Refresh = Window_NameEdit.prototype.refresh;
    Window_NameEdit.prototype.refresh = function() {
        _KunFullNames_WindowNameEdit_Refresh.call(this);
        this.drawFullNameTips();
    };


    Window_Base.prototype.drawActorName = function(actor, x, y, width) {
        width = width || 168;
        this.changeTextColor(this.hpColor(actor));
        this.drawText(actor.fullName(), x, y, width);
    };    
};

/********************************************************************************************************************
 * 
 * INITIALIZER
 * 
 *******************************************************************************************************************/

(function ( /* args */) {

    KunFullNames.Initialize();

    KunFullNames_GameActor();
    KunFullNames_PluginCommands();
    KunFullNames_EscapeChars();
    KunFullNames_SceneFullName();


})( /* initializer */);

