//=============================================================================
// KunsLog.js
//=============================================================================
/*:
 * @plugindesc Kun's Quest Log Manager
 * @filename KunQuestLog.js
 * @version 1.1b
 * @author KUN
 * 
 * @help
 * 
 * @param debug
 * @text Debug Mode
 * @desc Show debug info and hidden quests
 * @type boolean
 * @on Enable
 * @off Disable
 * @default false
 * 
 * @param categories
 * @text Quest Categories
 * @desc Define a format for the quest categories
 * @type struct<Category>[]
 * @default []
 * 
 * @param questIcon
 * @text Default Quest Icon
 * @desc Default icon used for quest openers
 * @type Number
 * @default 0
 * 
 * @param activeIcon
 * @parent questIcon
 * @text Active Quest Icon
 * @desc Default icon used for Active quests
 * @type Number
 * @default 0
 * 
 * @param completedIcon
 * @parent questIcon
 * @text Completed Quest Icon
 * @desc Default icon used for Completed quests
 * @type Number
 * @default 0
 * 
 * @param failedIcon
 * @parent questIcon
 * @text Failed Quest Icon
 * @desc Default icon used for Failed quests
 * @type Number
 * @default 0
 * 
 * @param questSe
 * @text Quest Start FX
 * @desc Default Audio used for new Quests
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param updateSe
 * @parent questFx
 * @text Quest Update FX
 * @desc Default Audio used for Updated quests
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param completeSe
 * @parent questFx
 * @text Quest Complete FX
 * @desc Default Audio used for Completed quests
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param cancelSe
 * @parent questFx
 * @text Quest Fail FX
 * @desc Default Audio used for Failed quests
 * @type file
 * @require 1
 * @dir audio/se/
 * 
 * @param rewardText
 * @text Reward Text
 * @desc Append this text to the reward messsage in the quest window
 * @type text
 * 
 * @param detailChars
 * @text Detail's length
 * @desc Define the line length of the quest and stage details.
 * @type number
 * @default 50
 * 
 * @param menuText
 * @text Player Menu Text
 * @desc Show this text in menu to topen the Quest Log
 * @type text
 * @default Quests
 * 
 * @param commandMenu
 * @parent commandText
 * @text Display in Player Menu
 * @desc Select the questlog status in Command Menu
 * @type select
 * @option Enabled
 * @value enabled
 * @option Disabled
 * @value disabled
 * @option Hidden
 * @value hidden
 * @default active
 * 
 * @param onGetQuestItemEvent
 * @text Quest Item Event ID
 * @desc Select the custom event to run after getting an item which will hook all item based quests
 * @type common_event
 * @default 0
 * 
 * @param itemVarId
 * @parent onGetQuestItemEvent
 * @text Item Var ID
 * @desc Var ID used to capture the gained item
 * @type Variable
 * @min 0
 * @default 0
 * 
 * @param amountVarId
 * @parent onGetQuestItemEvent
 * @text Amount Var ID
 * @desc Var ID used to capture the item amount
 * @type Variable
 * @min 0
 * @default 0
 */
/*~struct~Category:
 * @param category
 * @text Category
 * @desc Unique category name to organize the quests
 * @type text
 * @default Main
 * 
 * @param title
 * @text Category Title
 * @desc Category Text to show in the quest log header
 *
 * @param quests
 * @type struct<Quest>[]
 * @text Quests
 * @desc Define here all the quests for your category :)
 * 
 * @param color
 * @text Color
 * @type Number
 * @min 0
 * @max 32
 * @default 0
 *
 * @param icon
 * @text Icon
 * @type Number
 * @min 0
 * @default 0
 * 
 */
/*~struct~Quest:
 * @param quest
 * @text Quest Name
 * @type text
 * @desc Unique quest name (ie: mainquest01 )
 * @default newquest01
 * 
 * @param title
 * @type text
 * @default New Quest
 * 
 * @param details
 * @text Details
 * @desc Add here the quest description
 * @type note
 *
 * @param type
 * @desc How this quest works
 * @type select
 * @option Default
 * @value default
 * @option Linear
 * @value linear
 * @option Optional
 * @value optional
 * @default default
 *
 * @param icon
 * @type number
 * @default 0
 *
 * @param stages
 * @text Quest Stages
 * @desc add all stages here
 * @type struct<Stage>[]
 */
/*~struct~Stage:
 * @param stage
 * @text Stage Name
 * @type text
 * @desc Unique stage key within this quest (ie: getcoins01 )
 * 
 * @param title
 * @type text
 * @default new stage
 *
 * @param details
 * @type note
 * @desc Type in quest progress details here
 *
 * @param objective
 * @desc Define the number of objectives to fulfill in this stage (ie: get 10 coins), default is 1.
 * @type number
 * @min 1
 * @max 999
 * @default 1
 * 
 * @param changeStatus
 * @text Set Quest Status
 * @desc change quest status on complete this stage
 * @type list
 * @option None
 * @value none
 * @option Complete
 * @value completed
 * @option Cancel
 * @value cancel
 * @option Reset
 * @value reset
 * @default none
 * 
 * @param actions
 * @text Run Actions
 * @desc Run these actions when this stage is set
 * @type struct<Action>[]
 * 
 * @param location
 * @text Locations
 * @type text[]
 * @desc Set the currently active location for this stage
 * 
 * @param bindItems
 * @text Quest Items
 * @desc Check for these invetory items to update the stage progress   
 * @type item[]
 */
/*~struct~Reward:
 * @param reward
 * @text Reward
 * @type text
 * 
 * @param icon
 * @text Reward Display Icon
 * @desc Show some cute icon on popup the reward
 * 
 * @param coins
 * @text Reward Coins
 * @type number
 * @min 0
 * @default 0
 * 
 * @param items
 * @text Reward Items
 * @type item[]
 * @default 0
 * 
 * @param actions
 * @text Reward Actions
 * @type struct<Action>
 * @desc Toggle switches and game variables
 */
/*~struct~Action:
 * @param gamevar
 * @text Update Variable
 * @type variable
 * @min 0
 * 
 * @param value
 * @type number
 * @text Amount
 * @min 0
 * @default 0
 * 
 * @param operator
 * @text Operator
 * @type list
 * @option Set
 * @value set
 * @option Add
 * @value add
 * @option Substract
 * @value sub
 * @default set
 * 
 * @param on
 * @text Switch ON
 * @desc mark ON all these switches
 * @type switch[]
 * 
 * @param off
 * @text Switch Off
 * @desc Mark OFF all these switches
 * @type switch[]
 */

/**
 * @class {QuestLog}
 */
class QuestLog {
    /**
     * @returns {QuestLog}
     */
    constructor() {
        if (QuestLog.__instance) {
            return QuestLog.__instance;
        }
        QuestLog.__instance = this.initialize();
    }
    /**
     * @returns {QuestLog}
     */
    initialize() {

        const _parameters = QuestLog.pluginData();

        //console.log( parameters);
        this._categories = [
            //quest category definitions
        ];
        this._questData = [
            //here will be the base quest templates
        ];
        this._quests = [
            //this is the list of gameplay quests (for status loading/saving)
        ];

        this._debug = _parameters.debug || false;
        this._jumpTo = _parameters.enableJumpTo || false;
        this._questItemEvent = _parameters.onGetQuestItemEvent || 0;
        this._itemVar = _parameters.itemVarId || 0;
        this._questItemAmountId = _parameters.amountVarId || 0;
        this._detailsLength = _parameters.detailChars || 50;
        this._settings = {
            menu: this._parameters.commandMenu || QuestLog.Menu.Enabled,
        };
        this._muted = false;
        this._layoutSize = 4;
        this._icons = {
            active: _parameters.activeIcon || 0,
            completed: _parameters.completedIcon,
            failed: _parameters.failedIcon,
            default: _parameters.questIcon
        };
        this._media = {
            start: _parameters.questSe || '',
            update: _parameters.updateSe || '',
            complete: _parameters.completeSe || '',
            fail: _parameters.cancelSe || '',
        };
        this._strings = {
            command: _parameters.menuText || '',
            reward: _parameters.rewardText || '',
        };

        return this.importContent(_parameters.categories || []);
    }
    /**
     * @returns {Boolean}
     */
    debug() { return this._debug; }
    /**
     * @returns {Boolean}
     */
    enableJumpTo(){ return this._jumpTo; }
    /**
     * @returns {String}
     */
    setting(setting = '') { return setting && this._settings[setting] || ''; '' }
    /**
     * @setting {String} setting 
     * @param {String|Number|Boolean|Object} value 
     * @returns {QuestLog}
     */
    set(setting, value = '') {
        if (this._settings.hasOwnProperty(setting)) {
            this._settings[setting] = value;
        }
        return this;
    };
    /**
     * @param {Object} data 
     * @returns {QuestLog}
     */
    load(data = null) {
        this.reset();
        if (data) {
            Object.keys(data.quests || {}).forEach(name => {
                const quest = this.quest(name) || null;
                if (quest) {
                    const stages = content.stages || {};
                    quest.set(content.status || Quest.Status.Hidden);
                    quest.moveto(content.current || quest.first());
                    quest.stages()
                        .filter(stage => Object.keys(stages).includes(stage.name()))
                        .forEach(stage => stage.set(stages[stage.name()] || 0));
                }
            });
        }
        return this;
    }
    /**
     * @returns {Object}
     */
    content() {
        const _quests = {};
        this.quests().forEach(quest => _quests[quest.name()] = quest.content());
        return {
            quests: _quests,
            settings: this._settings
        };
    }

    /**
     * @param {Boolean} mapNames
     * @returns {QuestCategory[]|String[]}
     */
    categories(mapNames = false) {
        return mapNames ? this._categories.map( cat => cat.name() ) : this._categories;
    }
    /**
     * @returns {QuestData[]}
     */
    questData() { return this._questData; }
    /**
     * 
     */
    reset() { this._quests = []; }
    /**
     * @param {Boolean} mapNames 
     * @returns {Quest[],String[]}
     */
    quests(mapNames = false) { return mapNames ? this._quests.map(quest => quest.name()) : this._quests; }
    /**
     * @param {String} quest 
     * @returns {Boolean}
     */
    has(quest = '') { return quest && this.quests(true).includes(quest); }
    /**
     * @param {QuestData} data 
     * @returns {Quest}
     */
    template(name = '') {
        const base = name && this.questData().find(quest => quest.name() === name) || null;
        if (base) {
            const quest = new Quest(base._name, base._title, base._details, base._icon, base._type);
            quest.categorize(base.category());
            base.stages().forEach(stage => quest.addStage(stage.clone()));
            this._quests.push(quest);
            return quest;
        }
        return null;
    }
    /**
     * Gets a quest from the game quests, or attempts to create it from the quest templates
     * @param {String} name
     * @returns {Quest}
     */
    quest(name = '') { return this.quests().find(quest => quest.name() === name) || this.template(name); };
    /**
     * @param {Object[]} content 
     * @returns {QuestLog}
     */
    importContent(content = []) {
        content.forEach(data => {
            const category = new QuestCategory(
                data.category,
                data.title || '',
                data.icon || 0,
                data.color || 0,
            );
            this._categories[category.name()] = category;
            this.importQuests(data.quests || [], category);
        });
        return this;
    }
    /**
     * @param {Object[]} content 
     * @param {QuestCategory} category
     * @returns {QuestInfo}
     */
    importQuests(content = [], category = null) {

        if (category) {
            content.forEach(data => {
                const quest = new QuestData(
                    data.name,
                    data.title,
                    data.details,
                    data.icon,
                    data.type,
                );

                quest.categorize(category);
                this.importStages(data.stages || []).forEach(stage => quest.addStage(stage));
                this._questData[quest.name()] = quest;
            });
        }

        return this;
    };
    /**
     * @param {Object[]} content 
     * @returns {QuestStage[]}
     */
    importStages(content = []) {
        return content.map(data => {
            const stage = new QuestStage(
                data.name,
                data.title || '',
                data.details || '',
                data.objective || 0,
                data.changeStatus || '',
                data.bindItems || [],
            );
            //add extra attributes here
            stage._location = data.location || [];
            //stage._actions = (data.actions || []).map( action => new QuestAction(
            stage._items
            //stage._rewards = (data.rewards || []).map( reward => new QuestReward(

            return stage;
        });
    }



    /**
     * @returns {Number}
     */
    itemEvent() {
        return this._questItemEvent;
    }
    /**
     * @returns {Number}
     */
    detailsLength() {
        return this._detailsLength;
    };

    /**
     * @returns {String}
     */
    defaultMenuStatus() {
        return this.setting('menu');
    };
    /**
     * @param Boolean reset
     * @returns Object
     */
    importSelected(reset = false) {

        if (this._selected.length > 0) {

            var quest = this.quest(this._selected);
            if (reset) {
                this._selected = '';
            }
            return quest;
        }
        return null;
    };
    /**
     * @param {String} name 
     * @returns {QuestLog}
     */
    selectQuest(name = '') {
        this._selected = name || '';
        return this;
    };
    /**
     * @returns {Number}
     */
    layoutSize() { return this._layoutSize; };
    /**
     * @param {String} category 
     * @returns {Boolean}
     */
    hasCategory(category) {
        return this._categories.hasOwnProperty(category);
    };


    /**
     * @param {String} category 
     * @returns {Number}
     */
    categoryIcon = function (category) {
        return this.hasCategory(category) ? this.categories()[category].icon : this.icon('default');
    };
    /**
     * @param {String} category 
     * @returns {Number}
     */
    categoryColor = function (category) {
        return this.hasCategory(category) ? this.categories()[category].color : 0;
    };
    /**
     * @param {String} category 
     * @returns {String}
     */
    getCategoryTitle = function (category) {
        return this.hasCategory(category) ? this.categories()[category].title : category;
    };
    /**
     * @returns {Boolean}
     */
    muted() { return this._muted; };
    /**
     * @param {String} media 
     * @returns {String}
     */
    media(media = '') {
        return media && this._media.hasOwnProperty(media) ? this._media[media] : '';
    };
    /**
     * @param {Number} icon 
     * @returns {Number}
     */
    icon(icon) {
        return this._icons.hasOwnProperty(icon) ? this._icons[icon] : 0;
    };
    /**
     * @param {String} string 
     * @returns {String}
     */
    string(string) {
        return this._strings && this._strings.hasOwnProperty(string) ? this._strings[string] : string;
    };



    /**
     * @param {String} type 
     * @returns {QuestLog}
     */
    playMedia(type = '') {
        if (type && !this.muted()) {
            const media = this.media(type);
            AudioManager.playSe({ name: media, pan: 0, pitch: 100, volume: 100 });
        }
        return this;
    };
    /**
     * @param {Number} item_id
     * @param {Number} amount
     * @returns {QuestLog}
     */
    onQuestItem(item_id, amount) {
        if (this._questItemEvent) {
            if (this._itemVar) {
                $gameVariables.setValue(this._itemVar, item_id || 0);
                if (this._questItemAmountId) {
                    $gameVariables.setValue(this._questItemAmountId, amount || 0);
                }
            }
            $gameTemp.reserveCommonEvent(this._questItemEvent);
        }
        return this;
    };
    /**
     * @param {String} message
     * @returns {QuestLog}
     */
    notify(message = '') {

        if (!this.muted()) {
            if (typeof kun_notify === 'function') {
                kun_notify(message);
            }
            else if (this.debug()) {
                console.log(message);
            }
        }
        return this;
    };
    /**
     * @param {Boolean} mute 
     * @returns {QuestLog}
     */
    mute(mute = true) {
        this._muted = mute;
        return this;
    };
    /**
     * @param {*} content 
     */
    static DebugLog() {
        if (QuestLog.manager().debug()) {
            console.log('[ KunQuestMan ]', ...arguments);
        }
    };




    /**
     * @returns {Boolean}
     */
    static isEnabled() {
        return QuestLog.manager().setting('menu') === QuestLog.Menu.Enabled;
    }
    /**
     * @returns {Boolean}
     */
    static isVisible() {
        return QuestLog.manager().setting('menu') !== QuestLog.Menu.Hidden;
    }
    /**
     * @param {String} quest
     */
    static Show(quest = '') {
        SceneManager.push(Scene_QuestLog);
        if (SceneManager.isSceneChanging()) {
            SceneManager.prepareNextScene(quest);
        }
    }
    /**
     * @param {String} mode 
     * @returns {QuestLog}
     */
    static toggle(mode = '') {
        return QuestLog.manager().set('menu', mode).playMedia('update');
    };

    /**
     * @returns {Object}
     */
    static pluginData() {

        /**
         * @param {String} key 
         * @param {*} value 
         * @returns {Object}
         */
        function _kunPluginReaderV2(key = '', value = '') {
            if (typeof value === 'string' && value.length) {
                try {
                    if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                        return JSON.parse(value, _kunPluginReaderV2);
                    }
                } catch (e) {
                    // If parsing fails or it's not an object/array, return the original value
                }
                if (value === 'true' || value === 'false') {
                    return value === 'true';
                }
                if (!isNaN(value)) {
                    return parseInt(value);
                }
            }
            else if (typeof value === 'object') {
                //console.log(value);
                if (Array.isArray(value)) {
                    return value.map(item => _kunPluginReaderV2(key, item));
                }
                const content = {};
                Object.keys(value).forEach(key => content[key] = _kunPluginReaderV2(key, value[key]));
                //console.log(key,content);
                return content;
            }
            return value;
        };

        return _kunPluginReaderV2(PluginManager.parameters('KunQuestLog'));
    }
    /**
     * @returns {Boolean}
     */
    static command(command = '') {
        return ['kunquestman', 'questlog', 'questman'].includes(command.toLowerCase());
    };
    /**
     * @returns {QuestLog}
     */
    static manager() {
        return QuestLog.__instance || new QuestLog();
    }
}


/**
 * @type {QuestLog.Menu|String}
 */
QuestLog.Menu = {
    Enabled: 'enabled',
    Disabled: 'disabled',
    Hidden: 'hidden',
};



///////////////////////////////////////////////////////////////////////////////////////////////////
////    Quest Objects
///////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @class {QuestCategory}
 */
class QuestCategory {
    /**
     * @param {String} category 
     * @param {String} title 
     * @param {Number} color 
     * @param {Number} icon 
     */
    constructor(category = 'default', title = 'Default', color = 0, icon = 0) {
        this._name = category.toLowerCase().replace(/[\s_]+/g);
        this._title = title;
        this._color = color || 0;
        this._icon = icon || 0;
    }
    /**
     * @returns {String}
     */
    name() {
        return this._name;
    }
    /**
     * @returns {String}
     */
    title() {
        return this._title;
    }
    /**
     * @returns {Number}
     */
    color() {
        return this._color;
    }
    /**
     * @returns {Number}
     */
    icon() {
        return this._icon;
    }
}

/**
 * @param {String} name 
 * @param {String} title 
 * @param {String} category 
 * @param {String} details
 * @param {Number} icon 
 * @param {String} behaviour 
 * @param {String} next
 * @param {String} reward
 * @returns {QuestData}
 */
class QuestData {
    /**
     * @param {String} name 
     * @param {String} title 
     * @param {String} details 
     * @param {Number} icon 
     * @param {String} type 
     */
    constructor(name = 'quest', title = '', details = '', icon = 0, type = '') {

        this._category = null;

        this._name = name.toLowerCase().replace(/[\s_]+/g);
        this._title = title || '';
        this._details = details || '';
        this._icon = icon || 0;
        this._type = type || Quest.Type.Default;
        this._stages = [];
    }
    /**
     * @returns {QuestLog}
     */
    manager() {
        return QuestLog.manager();
    }
    /**
     * @param {String} string 
     * @returns {String}
     */
    getString(string = '') {
        return this.manager().string(string);
    }

    /**
     * @param {QuestCategory} category 
     * @returns {QuestData}
     */
    categorize(category = null) {
        if (category instanceof QuestCategory && !this.category()) {
            this._category = category;
        }
        return this;
    }

    //public getters
    /**
     * @returns {String}
     */
    name() { return this._name; }
    /**
     * @param {Boolean} display
     * @returns {String}
     */
    title(display = false) {
        const icon = this.icon();
        return display && icon ? `\\\I[${icon}] ${this._title}` : this._title;
    }
    /**
     * @returns {String}
     */
    type() { return this._type; }
    /**
     * @returns {Boolean}
     */
    isLinear() { return this.type() === Quest.Type.Linear; }
    /**
     * @returns {Boolean}
     */
    isOptional() { return this.type() === Quest.Type.Optional; }
    /**
     * @returns {Boolean}
     */
    autoUpdate() { return this.isLinear() || this.isOptional(); }
    /**
     * @returns {QuestCategory}
     */
    category() { return this._category; }
    /**
     * @returns {String}
     */
    categoryTitle() {
        return this.category() && this.category().title() || '';
    };
    /**
     * @param {Boolean} display
     * @returns {String}
     */
    location(display = false) {
        const active = this.current();
        const location = active ? this.current().location() : [];
        return display && location.join(', ') || location;
    }
    /**
     * @returns {Number}
     */
    icon() { return this._icon; }
    /**
     * @returns {String}
     */
    details() { return this._details; }

    /**
     * @param {Boolean} mapNames
     * @returns {QuestStage[],Strin[]}
     */
    stages(mapNames = false) { return mapNames ? this._stages.map(stage => stage.name()) : this._stages; }
    /**
     * @param {String} name
     * @returns {QuestStage}
     */
    stage(name) { return this.stages().find(stage => stage.name() === name) || null; }
    /**
     * @param {String} stage= ''
     * @returns {Boolean}
     */
    has(stage = '') { return this.stages(true).includes(stage); }
    /**
     * @param {QuestStage} stage
     * @returns {QuestData}
     */
    addStage(stage = null) {
        if (stage instanceof QuestStage && !this.has(stage.name())) {
            this._stages.push(stage);
        }
        return this;
    }
};


/**
 * 
 */
class Quest extends QuestData {
    /**
     * @param {String} name
     * @param {String} title
     * @param {String} details
     * @param {Number} icon
     * @param {String} type
     */
    constructor(name = '', title = '', details = '', icon = 0, type = '') {
        super(name, title, details, icon || 0, type);
        this._status = Quest.Status.Hidden;
        this._current = this.stages(true)[0] || '';

        //recursive quest support
        this._rounds = 0;
    }
    /**
     * @param {String} stage 
     * @returns {Boolean}
     */
    has(stage = '') {
        return this.stages().includes(stage);
    }
    /**
     * @returns {Number[]}
     */
    objectives() {
        return this.stages(true).map(stage => stage.objective()).reduce((a, b) => { a + b }, 0);
    };
    /**
     * @returns {Number[]}
     */
    amount() {
        return this.stages(true).map(stage => stage.value()).reduce((a, b) => { a + b }, 0);
    }
    /**
     * @returns {Number[]}
     */
    progress() {
        return this.amount() / parseFloat(this.objectives()) || 0;
    }
    /**
     * @param {Number} status 
     * @returns {Boolean}
     */
    isStatus(status = Quest.Status.Active) {
        return this.status() === status;
    }
    /**
     * @param {String} category 
     * @returns {Boolean}
     */
    isCategory(category = '') {
        return this.category() && this.category().name() === category || false;
    }
    /**
     * @param {Number} status 
     * @returns {Boolean}
     */
    set(status = Quest.Status.Hidden) {
        if (this.status() !== status) {
            this._status = status;
            return true;
        }
        return false;
    }
    /**
     * @param {String} stage 
     * @returns {Boolean}
     */
    moveto(stage = '') {
        if (this.has(stage) && stage !== this.current()) {
            this._current = stage;
            return true;
        }
        return false;
    }
    /**
     * @returns {String}
     */
    current() { return this._current; }
    /**
     * @returns {String}
     */
    next() { return this.stages()[this.stages().indexOf(this.current()) + 1] || ''; }
    /**
     * @returns {String}
     */
    first() { return this.stages()[0] || ''; }
    /**
     * @returns {Boolean}
     */
    hasReward() { return this.stages().some(stage => stage.reward().length > 0); }
    /**
     * @param {Boolean} display
     * @returns {Number|String}
     */
    status(display = false) {
        if (display) {
            switch (this._status) {
                case Quest.Status.Active: return 'Active';
                case Quest.Status.Completed: return 'Completed';
                case Quest.Status.Failed: return 'Failed';
                case Quest.Status.Hidden:
                default: return 'Invalid';
            }
        }
        return this._status;
    }
    /**
     * @returns {Boolean}
     */
    ready() { return this.status() === Quest.Status.Hidden; }
    /**
     * @returns {Boolean}
     */
    active() { return this.status() === Quest.Status.Active; }
    /**
     * @returns {Boolean}
     */
    completed() { return this.status() === Quest.Status.Completed; }
    /**
     * @returns {Boolean}
     */
    failed() { return this.status() === Quest.Status.Failed; }
    /**
     * @returns {Boolean}
     */
    finished() { return this.status() > Quest.Status.Active; }

    /**
     * @returns {StageData[]}
     */
    stagesCompleted() { return this.stages().filter(stage => stage.completed()); }
    /**
     * @returns {Number}
     */
    stagesLeft() { return this.stages().filter(stage => !stage.completed()); }
    /**
     * @returns {Number}
     */
    remaining() { return this.stagesCompleted().length; }

    /**
     * @param {QuestStage} stage
     * @returns {Boolean}
     */
    checkStage(stage = null) {
        if (stage instanceof QuestStage && stage.completed) {
            stage.runActions();
            switch (stage.whenCompleted()) {
                case QuestStage.CompleteStatus.Completed:
                    return this.complete();
                case QuestStage.CompleteStatus.Cancel:
                    return this.cancel();
                case QuestStage.CompleteStatus.Reset:
                    return this.reset();
            }
            if (this.isLinear()) {
                //stage completed, moving to the next stage
                this.moveto(this.next());
            }
        }
        return false;
    }
    /**
     * @returns {Boolean}
     */
    onStagesCompleted() {
        if (this.stagesCompleted()) {
            if ([Quest.Type.Linear, Quest.Type.Default].includes(this.type())) {
                return this.complete()
            }
        }
        return false;
    }

    /**
     * @param {Number} status
     * @returns {Boolean}
     */
    reset(started = false) {
        this.stages().forEach(stage => stage.set(0));
        if (this.set(started && Quest.Status.Active || Quest.Status.Hidden)) {
            this.moveto(this.first());
            return true;
        }
        return false;
    }
    /**
     * @param {Number} status
     * @returns {Boolean}
     */
    start() {
        if (this.ready()) {
            this.sedte(Quest.Status.Active).notify('started.').playMedia('start');
        }
        return this.active();
    }

    /**
     * @param {String} stage 
     * @param {Number} amount 
     * @returns {Number}
     */
    update(stage = '', amount = 0) {
        const stageData = this.stage(stage || this.autoUpdate() && this.current());
        if (stageData) {
            if (stageData.update(amount)) {
                //completed stage (check when quest status chanegs)
                if (this.checkStage(stageData) || this.onStagesCompleted()) {
                    //notifications are handled within these methods    
                    return true;
                }
            }
            this.notify('updated');
            return true;
        }
        return false;
    }
    /**
     * @returns {Boolean}
     */
    complete(fullComplete = false) {
        if (fullComplete) {
            this.stages().forEach(stage => stage.complete());
        }
        if (!this.finished()) {
            //either no stage or last stage will compelte
            if (this.set(Quest.Status.Complete)) {
                this.notify('completed', 'complete');
                return true;
            }
        }
        return false;
    }
    /**
     * @returns {Boolean}
     */
    cancel() {
        if (this.active() && this.set(Quest.Status.Failed)) {
            this.moveto(Quest.Status.Failed).notify('failed', 'fail');
        }
        return this.failed();
    }

    /**
     * @param {String} message 
     * @returns {Quest}
     */
    notify(message = '', media = 'update') {
        if (message) {
            this.manager().notify(this.title(true) + ' ' + message).media(media);
        }
        return this;
    }
    /**
     * @param {String} type 
     * @returns {Quest}
     */
    playMedia(type = '') {
        this.manager().playMedia(type);
        return this;
    }

    /**
     * @returns {Object}
     */
    content() {
        const stages = {};
        this.stages().forEach(stage => stages[stage.name()] = stage.value());
        return {
            stages: stages,
            status: this.status(),
            current: this.current(),
        };
    }
    /**
     * @returns {String}
     */
    static Status() {
        return ['invalid', 'hidden', 'active', 'completed', 'failed'];
    }
}


/**
 * @type {Quest.Status|Number}
 */
Quest.Status = {
    Invalid: 0,
    Hidden: 1,
    Active: 2,
    Completed: 3,
    Failed: 4
};
/**
 * @type {QuestData.Behavior|String}
 */
Quest.Type = {
    Default: 'default',
    Linear: 'linear',
    Optional: 'optional',
};

/**
 * @param string quest
 * @param string stage
 * @param string title
 * @param string details
 * @param number objective
 * @param {string | string[]} locations
 * @returns {QuestStage}
 */
class QuestStage {
    /**
     * @param {String} stage 
     * @param {String} title 
     * @param {String} details 
     * @param {Number} objective 
     * @param {String} onComplete 
     * @returns {QuestStage}
     */
    constructor(stage = '', title = '', details = '', objective = 0, onComplete = '') {
        this._name = stage || 'stage';
        this._title = title || '';
        this._details = (details || '').replace(/\\n/g, " ").replace(/\"/g, "");
        this._objective = objective || 1;
        this._value = 0;
        this._onComplete = onComplete || QuestStage.CompleteStatus.None;

        this._location = [];
        this._rewards = [];
        this._actions = [];
        this._items = [];

        return this;
    }
    /**
     * @returns {String}
     */
    name() { return this._name; }
    /**
     * @param {Boolean} display
     * @returns {String}
     */
    title(display = false) {
        const title = this._title || this.name();
        return display && this.objective() > 1 && `${title} ( ${this.objective()} / ${this.objective()} )` || title;
    };
    /**
     * @returns {Boolean}
     */
    visible() { return !!this._title; }
    /**
     * @returns {String[]}
     */
    location() { return this._location; }
    /**
     * @returns {QuestReward}
     */
    reward() { return this._rewards; }
    /**
     * @returns {String}
     */
    details() { return this._details; }
    /**
     * @returns {Number}
     */
    objective() { return this._objective; }
    /**
     * @returns {Number}
     */
    value() { return this._value; }
    /**
     * @returns {Number}
     */
    progress() { return this.value() / parseFloat(this.objective()); }
    /**
     * @param {Number} amount 
     * @returns {Boolean}
     */
    update(amount = 0) { return this.set(this.value() + amount).completed() }
    /**
     * @param {Number} value 
     * @returns {QuestStage}
     */
    set(value = 0) {
        this._value = Math.min(Math.max(value, 0), this.objective());
        return this;
    }
    /**
     * @returns {QuestStage.CompleteStatus|String}
     */
    whenCompleted() { return this._onComplete; }
    /**
     * @returns {QuestStage}
     */
    compelete() {
        this._value = this.objective();
        return this;
    }
    /**
     * @returns {Number}
     */
    completed() { return this.value() >= this.objective(); }
    /**
     * @returns {Number}
     */
    status() {
        return this.completed() ? Quest.Status.Completed : Quest.Status.Active;
    }
    /**
     * @returns {Number[]}
     */
    bindItems() { return this._items; }


    /**
     * @returns {QuestAction[]}
     */
    actions() {
        return this._actions;
    }
    /**
     * @returns {QuestStage}
     */
    runActions() {
        this.actions().forEach(action => action.run());
        return this;
    }
    /**
     * @param {QuestAction} action 
     * @returns {QuestStage}
     */
    addAction(action = null) {
        if (action instanceof QuestAction) {
            this.actions().push(action);
        }
        return this;
    }
    /**
     * @returns {QuestStage}
     */
    clone() {
        const stage = new QuestStage(
            this.name(),
            this.title(),
            this.details(),
            this.objective(),
            this._onComplete
        );
        stage._location = [...this.location()];
        stage._actions = [...this._actions];
        stage._rewards = [...this._rewards];
        stage._items = [...this._items];
        return stage;
    }
};
/**
 * @type {QuestStage.CompleteStatus|String}
 */
QuestStage.CompleteStatus = {
    None: 'none',
    Completed: 'completed',
    Cancel: 'cancel',
    Reset: 'reset',
}

/**
 * 
 */
class QuestAction {
    /**
     * @param {Number} gameVar 
     * @param {String} operator 
     * @param {Number} amount 
     * @param {Number[]} on 
     * @param {Number[]} off 
     */
    constructor(gameVar = 0, operator = '', amount = 0, on = [], off = []) {
        this._gameVar = gameVar || 0;
        this._operator = operator || QuestAction.Operator.Set;
        this._amount = amount || 0;
        this._on = on || [];
        this._off = off || [];
    }
    /**
     * @returns {QuestAction}
     */
    run() { return this.update().on().off(); }
    /**
     * @returns {QuestAction}
     */
    on() {
        this._on.forEach(gs => gs && $gameSwitches.setValue(gs, true));
        return this;
    }
    /**
     * @returns {QuestAction}
     */
    off() {
        this._off.forEach(gs => gs && $gameSwitches.setValue(gs, false));
        return this;
    }
    /**
     * @param {Boolean} asValue 
     * @returns {Number}
     */
    gameVar(asValue = false) {
        return asValue ? this._gameVar && $gameVariables.value(this._gameVar) || 0 : this._gameVar;
    }
    /**
     * @returns {String}
     */
    operator() { return this._operator; }
    /**
     * @returns {Number}
     */
    amount() { return this._amount; }
    /**
     * @returns {QuestAction}
     */
    update() {
        const gameVar = this.gameVar();
        if (gameVar) {
            switch (this.operator()) {
                case QuestAction.Operator.Set:
                    $gameVariables.setValue(gameVar, this.amount());
                    break;
                case QuestAction.Operator.Add:
                    $gameVariables.setValue(gameVar, this.gameVar(true) + this.amount());
                    break;
                case QuestAction.Operator.Substract:
                    $gameVariables.setValue(gameVar, Math.max(this.gameVar(true) + this.amount(), 0));
                    break;
            }
        }
        return this;
    }
}
/**
 * 
 */
class QuestReward {
    constructor(reward = '', icon = 0, coins = 0, items = []) {
        this._reward = reward || '';
        this._icon = icon || 0;
        this._coins = coins || 0;
        this._items = items.map(item => new RewardItem(
            item.item,
            item.type,
            item.amount
        )) || [];
    }
}
/**
 * 
 */
class RewardItem {
    /**
     * @param {Number} item 
     * @param {String} type 
     * @param {Number} amount 
     */
    constructor(item = 0, type = '', amount = 1) {
        this._item = item || 0;
        this._type = type || '';
        this._amount = amount || 1;
    }
}

/**
 * @type {QuestStage.VariableMethod|String}
 */
QuestAction.Operator = {
    Add: 'add',
    Substract: 'sub',
    Set: 'set',
};





/**
 * Hook the quest item common event
 */
function QuestManager_registerQuestItemEvent() {
    var _kunQuestMan_GainItem = Game_Party.prototype.gainItem;
    Game_Party.prototype.gainItem = function (item, amount, includeEquip) {
        _kunQuestMan_GainItem.call(this, item, amount, includeEquip);

        if (item !== null && amount > 0) {
            //console.log( `${item.name}: ${amount}` );
            QuestLog.manager().onQuestItem(item.id, amount);
        }
    }
};

/**
 * Register quest Manager Menu
 */
function QuestLog_RegisterMenu() {

    var _kunQuestMan_OriginalMenuCommands = Window_MenuCommand.prototype.addOriginalCommands;
    Window_MenuCommand.prototype.addOriginalCommands = function () {
        _kunQuestMan_OriginalMenuCommands.call(this);
        if (QuestLog.isVisible()) {
            this.addCommand(QuestLog.manager().string('command', 'Quests'), 'quest', QuestLog.isEnabled());
        }
    };
    var _kunQuestMan_CreateCommands = Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow = function () {
        _kunQuestMan_CreateCommands.call(this);
        if (QuestLog.isEnabled()) {
            this._commandWindow.setHandler('quest', this.commandQuestLog.bind(this));
        }
    };
    Scene_Menu.prototype.commandQuestLog = function () {
        QuestLog.Show();
    };
};

/**
 * DataManager to handle actor's attributes
 */
function KunQuestMan_SetupDataManager() {
    //CREATE NEW
    const _KunQuestMan_DataManager_Create = DataManager.createGameObjects;
    DataManager.createGameObjects = function () {
        _KunQuestMan_DataManager_Create.call(this);
        QuestLog.manager().load();
    };
    const _KunQuestMan_DataManager_Save = DataManager.makeSaveContents;
    DataManager.makeSaveContents = function () {
        const contents = _KunQuestMan_DataManager_Save.call(this);
        contents.questData = QuestLog.manager().content();
        return contents;
    };
    //LOAD
    const _KunQuestMan_DataManager_Load = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function (contents) {
        _KunQuestMan_DataManager_Load.call(this, contents);
        QuestLog.manager().load(contents.questData);
    };
}



/**
 * Setup text dialogs
 */
function KunQuestLog_registerEscapeCharacters() {
    //Window_Base.prototype.JayaKSetup_escapeCharacters = Window_Base.prototype.convertEscapeCharacters;
    const _KunQuestLog_EscapeCharacters = Window_Base.prototype.convertEscapeCharacters;
    Window_Base.prototype.convertEscapeCharacters = function (text) {
        const parsed = _KunQuestLog_EscapeCharacters.call(this, text);
        //include the quest names and stages here
        return parsed.replace(/\x1bQUEST\[(\s+)\]/gi, function () {
            //get quest Id
            return this.displayQuestData(parseInt(arguments[1]));
        }.bind(this));
    };

    Window_Base.prototype.displayQuestData = function (input) {
        const name = input.split('.');
        const quest = QuestLog.manager().quest(name[0]);
        if (quest) {
            const stage = name[1] && quest.stage(name[1]) || null;
            if (stage) {
                return stage && stage.title() && '[stage]';
            }
            return quest.title();
        }
        return '[quest]';
    };
};


/**
 * @class {KunQuestCommand}
 */
class KunQuestCommand {
    /**
     * @param {String[]} input 
     * @param {Game_Interpreter} context
     */
    constructor(input = [], context = null) {
        const command = this.initialize(input);
        this._command = command.length && command[0] || '';
        this._args = command.length > 1 && command.slice(1) || [];
        this._context = context instanceof Game_Interpreter && context || null;
        QuestLog.DebugLog(this);
    }
    /**
     * @param {Game_Interpreter} context 
     * @param {String[]} input 
     * @returns {KunQuestCommand}
     */
    static create(context = null, input = []) {
        return context instanceof Game_Interpreter && new KunQuestCommand(input, context) || null;
    }
    /**
     * @param {String[]} input 
     * @returns {String[]}
     */
    initialize(input = '') {
        this._flags = [];
        //prepare input string
        const content = input.join(' ');
        //extract flags
        const regex = /\[([^\]]+)\]/g;
        let match;
        while ((match = regex.exec(content)) !== null) {
            match[1].split("|").forEach(flag => this._flags.push(flag.toLowerCase()));
        }
        //return clean args array without flags
        return content.replace(regex, '').split(' ').filter(arg => arg.length);
    }
    /**
     * @returns {String}
     */
    toString() {
        return `${this.command()} ${this.arguments().join(' ')} (${this._flags.join('|')})`;
    }
    /**
     * @returns {QuestLog}
     */
    manager() {
        return QuestLog.manager();
    }
    /**
     * @returns {Game_Interpreter}
     */
    context() {
        return this._context;
    }
    /**
     * @returns {Game_Event}
     */
    event() {
        return this.context().character() || null;
    }
    /**
     * @param {String} flag 
     * @returns {Boolean}
     */
    has(flag = '') {
        return flag && this._flags.includes(flag) || false;
    }
    /**
     * @param {String} mode 
     * @returns {KunCommandManager}
     */
    setWaitMode(mode = '') {
        if (this.context()) {
            //set this to wait for a response
            //this.context()._index++;
            this.context().setWaitMode(mode);
        }
        //this._waitMode = mode;
        return this;
    }
    /**
     * @param {Number} fps
     * @returns {KunCommandManager}
     */
    wait(fps = 0) {
        if (this.context() && fps) {
            this.context().wait(fps);
        }
        //return this._wait;
        return this;
    }
    /**
     * @param {String} tags
     * @returns {Boolean} 
     */
    jumpToLabel(tags = '') {
        const labels = tags.split(':').map(tag => tag.trim()).filter(l => l.length);
        if (this.context() && labels.length) {
            return this.context().jumpToLabel( labels[Math.floor(Math.random()* labels.length) ].toUpperCase() );
        }   
        return false;
    }
    /**
     * @returns {String[]}
     */
    arguments() {
        return this._args;
    }
    /**
     * @returns {String}
     */
    command() {
        return this._command;
    }
    /**
     * @returns {Boolean}
     */
    run() {
        const commandName = `${this.command()}Command`;
        if (typeof this[commandName] === 'function') {
            this[commandName](this.arguments());
            return true;
        }
        this.defaultCommand(this.arguments());
        return false;
    }
    /**
     * @param {String} args 
     */
    defaultCommand(args = []) {
        KunCommands.DebugLog(`Invalid command ${this.toString()}`);
    }
    /**
     * @param {String[]} args 
     */
    startCommand(args = []) {
        if (args.length) {
            const quests = args[0].split(':');
            const reset = this.has('reset');
            quests.forEach(q => quest_start(q, reset));
        }
    }
    /**
     * @param {String[]} args 
     */
    restartCommand(args = []) {
        if (args.length) {
            const quests = args[0].split(':');
            quests.forEach(q => quest_restart(q));

        }

    }
    /**
     * @param {String[]} args 
     */
    resetCommand(args = []) {
        if (args.length) {
            const quests = args[0].split(':');
            quests.forEach(q => quest_reset(q));
        }
    }
    /**
     * @param {String[]} args 
     */
    updateCommand(args = []) {
        if (args.length) {
            let amount = args.length > 2 ? parseInt(args[2]) : 1;
            const quest = this.manager().quest(args[0]);
            if (quest) {
                quest.update(args[1] || '', amount)
            }
        }
    }
    /**
     * @param {String[]} args 
     */
    completeCommand(args = []) {
        if (args.length) {
            const stage = args[2] || '';
            args[0].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && !quest.finished())
                .forEach(quest => {
                    if (stage) {
                        const _stage = quest.stage(stage);
                        _stage && _stage.compelete();
                    }
                    else {
                        //quest.complete( !quest.isLinear );
                        quest.complete();
                    }
                });
            //quest_complete(args[1], args.length > 2 ? args[2] : '');
        }
    }
    /**
     * @param {String[]} args 
     */
    completeallCommand(args = []) {
        if (args.length) {
            const quest = this.manager().quest(args[0]);
            quest && quest.complete(true)
        }
    }
    /**
     * @param {String[]} args 
     */
    failCommand(args = []) {
        this.cancelCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    cancelCommand(args = []) {
        if (args.length) {
            const silent = this.has('silent') || this.has('silenced') || this.has('mute');
            this.manager().mute(silent);
            args[1].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && quest.active())
                .forEach(quest => quest.cancel());
            if (silent) { this.manager().mute(false); }
        }
    }
    /**
     * @param {String[]} args 
     */
    checkCommand(args = []) {
        if (args.length > 2) {
            const quest = this.manager().quest(args[1]);
            const status = args[2] && parseInt(args[2]) || Quest.Status.Active;
            $gameSwitches.setValue(parseInt(args[2]), quest && quest.status() === status || false);
        }
    }
    /**
     * @param {String[]} args 
     */
    mapstagesCommand(args = []) {

    }
    /**
     * @param {String[]} args 
     */
    tostageCommand(args = []) {
        this.jumptoCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    jumptoCommand(args = []) {

    }
    /**
     * @param {String[]} args 
     */
    jumptoquestCommand(args = []) {

    }
    /**
     * @param {String[]} args 
     */
    statusCommand(args = []) {
        if (args.length > 2) {
            const status = args[2];
            const quests = args[1].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && quest.isStatus(status));
            $gameVariables.setValue(parseInt(args[0]), quests.length);
        }
    }
    /**
     * @param {String[]} args 
     */
    finishedCommand(args = []) {
        if (args.length > 1) {
            const quests = args[1].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && quest.finished());
            $gameVariables.setValue(parseInt(args[0]), quests.length);
        }
    }
    /**
     * @param {String[]} args 
     */
    unfinishedCommand(args = []) {
        if (args.length > 1) {
            var quests = args[1].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && !quest.finished());
            $gameVariables.setValue(parseInt(args[0]), quests.length);
        }
    }
    /**
     * @param {String[]} args 
     */
    activeCommand(args = []) {
        if (args.length > 1) {
            const quests = args[0].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && quest.active());
            $gameVariables.setValue(parseInt(args[1]), quests.length);
        }
    }
    /**
     * @param {String[]} args 
     */
    runningCommand(args = []) {
        this.activeCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    readyCommand(args = []) {
        if (args.length > 1) {
            const quests = args[0].split(':')
                .map(quest => this.manager().quest(quest))
                .filter(quest => quest && quest.ready());
            $gameVariables.setValue(parseInt(args[1]), quests.length);
        }
    }
    /**
     * @param {String[]} args 
     */
    progressCommand(args = []) {
        if (args.length > 1) {
            const name = args[1].split('.');
            const quest = this.manager().quest(name[0]);
            const gameVar = parseInt(args[0]);
            if (quest) {
                if (name.length > 1 && name[1]) {
                    const stage = quest.stage(name[1]);
                    $gameVariables.setValue(gameVar, stage ? stage.progress() : 0);
                }
                else {
                    $gameVariables.setValue(gameVar, quest.progress());
                }
                return;
            }
            $gameVariables.setValue(gameVar, 0);
        }
    }
    /**
     * @param {String[]} args 
     */
    remainingCommand(args = []) {
        if (args.length > 1) {
            const quest = this.manager().quest(args[1]);
            const remaining = quest && quest.remaining() || 0;
            $gameVariables.setValue(parseInt(args[1]), remaining);
        }
    }
    inventoryCommand(args = []) {
        if (args.length > 2) {
            const item = this.has('import') ? $gameVariables.value(parseInt(args[2])) : parseInt(args[2]);
            quest_inventory(args[0], args[1], item);
        }
    }
    /**
     * @param {String[]} args 
     */
    menuCommand(args = []) {
        QuestLog.toggle(args[0] || QuestLog.Menu.Enabled);
    }
    /**
     * @param {String[]} args 
     */
    showCommand(args = []) {
        QuestLog.Show(args[0] || '');
    }
    /**
     * @param {String[]} args 
     */
    displayCommand(args = []) {
        this.showCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    muteCommand(args = []) {
        this.manager().mute(['mute', 'silenced'].includes(this.command()));
    }
    /**
     * @param {String[]} args 
     */
    silencedCommand(args = []) {
        this.muteCommand(args);
    }
    /**
     * @param {String[]} args 
     */
    notifyCommand(args = []) {
        this.muteCommand(args);
    }
    /**
     * Update if any of the quest stages are completed
     * Jump to label if updated
     * {quest:stage:stage:...} {label:label:label:...}
     * @param {String[]} args 
     * @returns {Boolean}
     */
    updateifCommand(args = []) {
        if( args.length ){
            const manager = this.manager();
            const tags = args[0].split('.');
            const quest = manager.quest(tags[0]);
            if( quest && quest.active()){
                const stage = quest.stage( tags[1] || '');
                if( stage && !stage.completed()){
                    stage.update()
                    this.jumpToLabel(args[1] || '');
                    return true;
                }
                //quest update using current stage
                if( quest.update() ){
                    this.jumpToLabel(args[1] || '');
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Update if any of the quest stages are completed
     * Jump to label if updated
     * {quest:stage:stage:...} {label}
     * @param {String[]} args 
     */
    completeifCommand(args = []) {
        if( args.length ){
            const manager = this.manager();
            const tags = args[0].split('.');
            const quest = manager.quest(tags[0]);
            if( quest && quest.active()){
                const stage = quest.stage( tags[1] || '');
                if( stage && !stage.completed()){
                    stage.compelete()
                    this.jumpToLabel(args[1] || '');
                    return true;
                }
                if( quest.complete() ){
                    //quest complete using current stage
                    this.jumpToLabel(args[1] || '');
                    return true;
                }
            }
        }
        return false;
    }
    /**
     * Jumps to the named label of the current active quest or stage
     * Jumps to a default label if no active quest or stage found
     * @param {String[]} args {quest.stage, defalt}
     * @returns {Boolean}
     */
    jumptoCommand(args = []) {
        if( args.length){
            const manager = this.manager();
            const tags = args[0].split('.');
            const quest = manager.quest(tags[0]);
            if( quest && quest.active()){
                const stage = quest.stage( tags[1] || '');
                if( stage && !stage.completed()){
                    //jump to the stage if valid
                    return this.jumpToLabel(stage.name());
                }
                //jump to quest or quest stage given the active quest
                return this.jumpToLabel( quest.name() );
            }
            this.jumpToLabel(args[1] || '');
        }
        return false;
    }
    /**
     * Jumps to a quest's defined stage or current stage
     * @param {String[]} args 
     * @returns {Boolean}
     */
    tostageCommand(args = []) {
        if( args.length ){
            const manager = this.manager();
            const tags = args[0].split('.');
            const quest = manager.quest(tags[0]);
            if( quest && quest.active()){
                const stage = quest.stage( tags[1] || '') || quest.current();
                if( stage ){
                    //jump to the stage if valid
                    return this.jumpToLabel(stage.name());
                }
            }
            this.jumpToLabel(args[1] || '');
        }
        return false;
    }
};


/**
 * Hook the commands
 */
function QuestManager_registerCommands() {
    //override vanilla
    const _kunQuestMan_Interpreter_Command = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _kunQuestMan_Interpreter_Command.call(this, command, args);
        if (QuestLog.command(command)) {
            KunQuestCommand.create(this, args).run();
        }
    };

    // Jump to Label (avoid issues with KunCommands!!!)
    if ( QuestLog.manager().enableJumpTo() && typeof Game_Interpreter.prototype.jumpToLabel !== 'function') {
        /**
         * @param {String} labelName 
         * @returns {Boolean}
         */
        Game_Interpreter.prototype.jumpToLabel = function (labelName) {
            for (var i = 0; i < this._list.length; i++) {
                var command = this._list[i];
                if (command.code === 118 && command.parameters[0] === labelName) {
                    this.jumpTo(i);
                    return true;
                }
            }
            return false;
        };
    }
};





///////////////////////////////////////////////////////////////////////////////////////////////////
////    Functions
///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @param {String} quest 
 * @param {String} status 
 * @returns {Number}
 */
function quest_check(quest, status) {
    if (typeof quest === 'string' && quest.length) {
        var name = quest.split('.');
        return QuestData.CheckStatus(quest_status(name[0], name.length > 1 ? name[1] : '')).includes(status);
    }
    return false;
};
/**
 * @returns {String}[]
 */
function quest_categories() {
    return QuestLog.manager().categories();
}
/**
 * @param {String} status
 * @param {String} category
 * @returns {String}[]
 */
function quest_list(status, category) {
    const list = QuestLog.manager().quests();

    if (typeof status === 'string' && status.length) {
        list = list.filter(function (quest) {
            return QuestData.CheckStatus(quest.status()).includes(status);
        });
    }
    if (typeof category === 'string' && category.length) {
        list = list.filter(function (quest) {
            return quest.category() === category;
        });
    }

    return list.map(quest => quest.name());
};
/**
 * @param {String} quest
 * @param {String} stage
 * @returns {Number}
 */
function quest_status(quest, stage = '') {
    const manager = QuestLog.manager();
    const q = manager.quest(quest);
    if (q && stage) {
        const s = q.stage(stage);
        return s && s.status() || Quest.Status.Active;
    }
    return q && q.status() || Quest.Status.Invalid;
}
/**
 * @param {String} quest 
 * @param {String} stage 
 * @returns {Number}
 */
function quest_progress(quest, stage = '') {
    const manager = QuestLog.manager();
    const q = manager.quest(quest);
    if (q && stage) {
        var s = q.stage(stage);
        return s && s.value() || 0;
    }
    return q && q.progress() * 100 || 0;
};
/**
 * @param {String|String[]} quest
 * @param {String} stage
 * @returns {Boolean}
 */
function quest_active(quest, stage = '') {
    const _quest = QuestLog.manager().quest(quest);
    //console.log(q);
    if (_quest !== null) {
        if (_quest.active()) {
            if (stage.length) {
                //stages
                const _stage = _quest.stage(stage);
                if (_quest.behaviour() === Quest.Type.Linear) {
                    return _stage !== null && !_stage.completed() && _stage.name() === _quest.current().name();
                }
                return _stage !== null && !_stage.completed();
            }
            return true;
        }
    }
    else {
        QuestLog.DebugLog('Invalid quest ID ' + quest);
    }

    return false;
}
/**
 * @param {String} quest
 * @param {String} stage
 * @returns {Boolean}
 */
function quest_completed(quest, stage) {
    var q = QuestLog.manager().quest(quest);
    if (q !== null) {
        if (typeof stage === 'string' && stage.length) {
            var s = q.stage(stage);
            return s !== null && s.completed();
        }
        return q.completed();
    }
    return false;
}
/**
 * @param {String} quest 
 * @returns {Boolean}
 */
function quest_ready(quest) {
    return quest_status(quest) === Quest.Status.Hidden;
}
/**
 * @param {String} quest 
 * @returns {Boolean}
 */
function quest_failed(quest) {
    return quest_status(quest) === Quest.Status.Failed;
}
/**
 * Start a quest
 * @param {String} name 
 * @param {Boolean} reset 
 * @returns {Boolean}
 */
function quest_start(name = '', reset = false) {
    const quest = QuestLog.manager().quest(name);
    if (quest !== null) {
        return typeof reset === 'boolean' && reset ? q.reset().start() : q.start();
    }
    else {
        QuestLog.DebugLog('Invalid quest ID ' + name);
    }
    return false;
}
/**
 * @param {String} quest 
 * @param {String} stage
 * @param {Number} progress
 * @returns {Boolean}
 */
function quest_update(quest, stage = '', progress = 1) {
    var qd = QuestLog.manager().quest(quest);
    if (qd) {
        return qd.update(stage, progress);
    }
    QuestLog.DebugLog('Invalid quest ID ' + quest);
    return false;
}
/**
 * Return the list of QuestStages left to complete. Will return 0 if the quest doesn't exist.
 * @param {String} quest 
 * @returns {Number}
 */
function quest_remaining(quest) {
    var q = QuestLog.manager().quest(quest);
    return q !== null ? q.stagesLeft() : 0;
}
/**
 * Complete a quest or quest stage
 * @param {String} name Quest or Quest.Stage ID
 * @param {String} stage
 * @returns {Boolean}
 */
function quest_complete(quest = '', stage = '') {

    var q = QuestLog.manager().quest(quest);
    if (q !== null) {
        return stage.length > 0 ?
            q.complete(quest) :
            q.complete();
    }

    QuestLog.DebugLog('Invalid quest ID ' + quest);

    return false;
}
/**
 * Complete a quest or quest stage
 * @param {String} name Quest ID
 * @returns {Boolean}
 */
function quest_complete_all(quest) {
    var q = QuestLog.manager().quest(quest);
    return q && q.complete(true) || false;
}
/**
 * Cancel a quest
 * @param {String} quest
 * @param {Boolean} silent
 */
function quest_cancel(quest, silent) {
    var q = QuestLog.manager().quest(quest);
    if (q !== null) {
        q.cancel(silent);
    }
    else {
        QuestLog.DebugLog('Invalid quest ID ' + quest);
    }
}
/**
 * Reset a quest/Stage
 * @param {String} quest 
 * @returns {Boolean}
 */
function quest_reset(quest) {

    var q = QuestLog.manager().quest(quest);
    if (q !== null) {
        q.reset();
        return true;
    }

    QuestLog.DebugLog('Invalid quest ID ' + quest);

    return false;
}

/**
 * Restart a quest/Stage
 * @param {String} quest 
 * @returns {Boolean}
 */
function quest_restart(quest) { return quest_reset(quest) ? quest_start(quest) : false; }
/**
 * check the inventory for quest items by item_id
 * @param {String} quest
 * @param {String} stage
 * @param {Number} item_id 
 * @returns {Boolean}
 */
function quest_inventory(quest = '', stage = '', item_id = 0) {
    const items = Object.keys($gameParty._items).map(id => parseInt(id)).filter(item => item === item_id);
    //sum all amounts of the selected item
    const amount = items.map(item => $gameParty._items[item]).reduce((a, b) => a + b, 0);
    if (quest && stage && amount) {
        quest_update(quest, stage, amount);
        //QuestLog.manager().onGetQuestItem(item_id, amount);
        QuestLog.DebugLog(`${quest}.${stage}: ${item_id}(${amount})`);
    }
    return amount > 0;
}



/**
 * Register quest Manager Menu
 */
function QuestLog_RegisterMenu() {

    const _kunQuestLog_WindowCommand_Commands = Window_MenuCommand.prototype.addOriginalCommands;
    Window_MenuCommand.prototype.addOriginalCommands = function () {
        _kunQuestLog_WindowCommand_Commands.call(this);
        if (QuestLog.manager().isMenuVisible()) {
            this.addCommand(QuestLog.manager().string('command', 'Quests'), 'quest', QuestLog.manager().isMenuEnabled());
        }
    };
    const _kunQuestLog_SceneMenu_createCommand = Scene_Menu.prototype.createCommandWindow;
    Scene_Menu.prototype.createCommandWindow = function () {
        _kunQuestLog_SceneMenu_createCommand.call(this);
        if (QuestLog.manager().isMenuEnabled()) {
            this._commandWindow.setHandler('quest', this.commandQuestLog.bind(this));
        }
    };
    Scene_Menu.prototype.commandQuestLog = function () {
        QuestLog.manager().Show();
    };
};


/**
 * Setup text dialogs
 */
function KunQuestWindow_escapeCharacters() {
    //Window_Base.prototype.JayaKSetup_escapeCharacters = Window_Base.prototype.convertEscapeCharacters;
    const _kunQuestLog_WindowBase_EscapeChars = Window_Base.prototype.convertEscapeCharacters;
    Window_Base.prototype.convertEscapeCharacters = function (text) {
        var parsed = _kunQuestLog_WindowBase_EscapeChars.call(this, text);
        //include the quest names and stages here
        return parsed.replace(/\x1bQUEST\[(\s+)\]/gi, function () {
            //get quest Id
            return this.displayQuestData(parseInt(arguments[1]));
        }.bind(this));
    };

    Window_Base.prototype.displayQuestData = function (name = '') {
        const path = name.split('.');
        const quest = QuestLog.manager().quest(path[0]);
        if (quest !== null) {
            if (path.length > 1) {
                var stage = quest.stage(path[1]);
                return stage !== null ? stage.title() : '<INVALID STAGE>';
            }
            return quest.title(true);
        }
        return '<INVALID QUEST>';
    };
};




///////////////////////////////////////////////////////////////////////////////////////////////////
////    QuestLogScene : Scene_ItemBase
///////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @QuestLogScene
 */
class Scene_QuestLog extends Scene_ItemBase {

    constructor() {

        this.initialize(arguments);

        this._quest = null;
    }

    initialize() {
        super.initialize();
    }
    /**
     * 
     */
    create() {
        super.create();

        //only for selected quests from commands
        const quest = this.quest() || null;
        //allways status window first
        this.setupStatusWindow(quest && quest.status() || Quest.Status.Active);
        this.setupCategoryWindow(quest && quest.category() || null, this._statusWindow.windowHeight());
        this.setupQuestWindow(quest, this._statusWindow.y + this._statusWindow.windowHeight());
        this.setupDetailWindow(quest, this._questsWindow.y);
    }
    /**
     * @param {String} quest 
     */
    prepare(quest = '') {
        if (quest) {
            this._quest = this.manager().quest(quest);
        }
    }
    /**
     * @returns {QuestLog}
     */
    manager() { return QuestLog.manager(); }
    /**
     * @returns {Quest}
     */
    quest() { return this._quest; }
    /**
     * @param {QuestCategory} category
     * @param {Number} position
     */
    setupCategoryWindow(category = null, position = 0) {
        this._categoryWindow = new Window_QuestCategory(position, category && category.name() || '');
        this.addWindow(this._categoryWindow);
    }
    /**
     * @param {Number} status (active)
     */
    setupStatusWindow(status = Quest.Status.Active) {
        this._statusWindow = new Window_QuestStatus(status);
        this._statusWindow.setHandler('cancel', this.onQuitQuestLog.bind(this));
        this._statusWindow.setHandler('ok', this.onSelectCategory.bind(this));
        this.addWindow(this._statusWindow);
        this._statusWindow.activate();
    }
    /**
     * @param {Quest} quest
     * @param {String} category
     * @param {Number} status
     */
    setupQuestWindow(quest = null, position = 0) {

        this._questsWindow = new Window_QuestLog(quest, position);
        this._statusWindow.setQuestsWindow(this._questsWindow);
        this._categoryWindow.setQuestsWindow(this._questsWindow);
        this.addWindow(this._questsWindow);
        this._questsWindow.activate();
        this._questsWindow.reload();
    }
    /**
     * @param {Quest} quest
     * @param {Number} position
     */
    setupDetailWindow(quest, position = 0) {
        this._detailWindow = new Window_QuestDetail(quest, position);
        this._questsWindow.setHelpWindow(this._detailWindow);
        this.addWindow(this._detailWindow);
        this._detailWindow.refresh();
    }
    /**
     * 
     */
    onSelectCategory() {
        if (this._categoryWindow) {
            this._categoryWindow.next();
            if (this._statusWindow) {
                this._statusWindow.activate();
                this._statusWindow.refresh();
            }
            if (this._questsWindow) {
                this._questsWindow.activate();
                this._questsWindow.reload();
            }
        }
    }
    /**
     * 
     */
    onQuitQuestLog() {
        this._questsWindow.deselect();
        //this._statusWindow.activate();
        this.popScene();
    }
    /**
     * @returns {Number}
     */
    static LayoutSize() { return 4; }
}


///////////////////////////////////////////////////////////////////////////////////////////////////
////    QuestCatWindow : Window_Base
///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @Window_QuestCategory
 */
class Window_QuestCategory extends Window_Base {
    constructor() {
        super();
        this.initialize(arguments);
    }
    /**
     * 
     * @param {Number} height 
     * @param {String} category 
     */
    initialize(height = 0, category = '') {
        super.initialize(0, 0, this.windowWidth(), height);
        
        this._category = category || '';
        this._title = 'All';
        this._name = '';
        this._icon = 0;
        this._color = 0;

        this.refresh();
    }
    /**
     * @returns {Number}
     */
    windowWidth() { return parseInt(Graphics.boxWidth / Scene_QuestLog.LayoutSize()); }
    /**
     * @returns {QuestCategory}
     */
    category() {
        return this._category && QuestLog.manager().category(this._category) || null;
    }
    /**
     * @returns {Number}
     */
    standardFontSize() { return 20; }
    /**
     * @returns {QuestCategory}[]
     */
    categories() {
        //first category is empty, will show All quests
        return ['', ...QuestLog.manager().categories().map(cat => cat.name())];
    }
    /**
     * 
     */
    next() {
        const list = this.categories();
        const category = this._category;
        if (list.length) {
            const index = category && list.indexOf(category) || 0;
            this._category = this.categories()[++index % list.length];
        }
        this.refresh();
    }
    /**
     * 
     * @param {Window_QuestLog} questLog 
     */
    setQuestsWindow(questLog = null) {
        this._questsWindow = questLog instanceof Window_QuestLog && questLog || null;
    }
    /**
     * 
     */
    refresh() {
        this.contents.clear();
        this.renderCategory(this.category());
        if (this._questsWindow) {
            this._questsWindow.setCategory(this._category);
        }
    }
    /**
     * @param {QuestCategory} category
     */
    renderCategory( category = null) {
        if (category instanceof QuestCategory) {
            const icon = category.icon();
            const title = category.title();
            const color = category.color();
            if (icon > 0) {
                var base_line = Math.max((28 - this.standardFontSize()) / 2, 0);
                this.drawIcon(icon, 0, base_line);
            }
            this.changeTextColor(this.textColor(color));
            this.drawText(title, 0, 0, this.contentsWidth(), 'center');
            this.changeTextColor(this.normalColor());
        }
        else {
            //All quests
            this.changeTextColor(this.normalColor());
            this.drawText('All', 0, 0, this.contentsWidth(), 'center');
        }
    }

};

///////////////////////////////////////////////////////////////////////////////////////////////////
////    QuestStatusWindow : Window_HorzCommand
///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * @Window_QuestStatus
 */
class Window_QuestStatus extends Window_HorzCommand {

    constructor() {
        this.initialize(arguments);
    }
    /**
     * @param {Number} status 
     */
    initialize(status = Quest.Status.Active) {
        super.initialize(Window_QuestStatus.X(), 0);

        this._index = this.list()[status] || Quest.Status.Active;
    }
    /**
     * @returns {Number}
     */
    static X() { return parseInt(Graphics.boxWidth / Scene_QuestLog.LayoutSize()); }
    /**
     * @returns {Number}
     */
    static Y() { return 0; }
    /**
     * @returns {Number}
     */
    windowWidth() { return Window_QuestStatus.X() * (Scene_QuestLog.LayoutSize() - 1); }
    /**
     * @returns {Number}
     */
    maxCols() { return this.maxItems(); }
    /**
     * @returns {Number}
     */
    standardFontSize() { return 20; }
    /**
     * 
     */
    update() {
        Window_HorzCommand.prototype.update.call(this);
        if (this._questsWindow) {
            this._questsWindow.setStatus(this.getStatus());
        }
    }
    /**
     * @returns {Number}
     */
    getStatus() { return this.list().indexOf(this.currentSymbol()) || 0; }
    /**
     * 
     */
    makeCommandList() {
        //register all visual statuses
        if (QuestLog.manager().debug()) {
            this.addCommand('Hidden', 'hidden');
        }
        this.addCommand('Active', 'active');
        this.addCommand('Completed', 'completed');
        this.addCommand('Failed', 'failed');
    }
    /**
     * @param {Number} index 
     */
    drawItem(index = 0) {
        const rect = this.itemRectForText(index);
        const align = this.itemTextAlign();
        if (this.commandSymbol(index) === 'hidden') {
            this.changeTextColor(this.systemColor());
        }
        else {
            this.resetTextColor();
        }
        this.changePaintOpacity(this.isCommandEnabled(index));
        this.drawText(this.commandName(index), rect.x, rect.y, rect.width, align);
        this.resetTextColor();
    }
    /**
     * @param {Window_QuestLog} questLog 
     */
    setQuestsWindow(questLog = null) {
        this._questsWindow = questLog instanceof Window_QuestLog && questLog || null;
    }
    /**
     * @returns {String[]}
     */
    list() { return ['invalid', 'hidden', 'active', 'completed', 'failed',]; }
};


///////////////////////////////////////////////////////////////////////////////////////////////////
////    QuestLogWindow : Window_Selectable
///////////////////////////////////////////////////////////////////////////////////////////////////

/**
 * @class {Window_QuestLog}
 */
class Window_QuestLog extends Window_Selectable {

    constructor() {
        this.initialize(arguments);
    }

    /**
     * @param {Quest} quest 
     * @param {Number} position 
     */
    initialize(quest = null, position = 0) {
        //super.initialize( 0 , position, this.windowWidth() , this.windowHeight() );
        super.initialize(0, position, this.windowWidth(), Graphics.boxHeight - position);

        this._category = quest && quest.category() && quest.category().name() || ''; //filter none
        this._status = quest && quest.status() || Quest.Status.Active;
        this._quests = this.loadList(this._category, this._status);

        if (quest !== null && quest instanceof QuestData) {
            this._status = quest.status();
            this._category = quest.category() && quest.category().name();
        }
    }
    /**
     * @returns {String[]}
     */
    quests() { return this._quests; }
    /**
     * @param {String} category 
     * @param {Number} status 
     * @returns {Quest[]}
     */
    loadList(category = '', status = Quest.Status.Active) {
        return QuestLog.manager()
            .quests()
            .filter(quest => quest.isStatus(status) && (!category || quest.isCategory(category)))
            .map(quest => quest.name());
    }
    /**
     * 
     */
    refreshList() { this._quests = this.loadList(this._category, this._status); }
    /**
     * @param {String} category 
     */
    setCategory(category = '') {
        if (this._category !== category) {
            this._category = category;
            this.reload();
        }
    }
    /**
     * @param {Number} status 
     */
    setStatus(status = Quest.Status.Active) {
        if (this._status !== status) {
            this._status = status;
            this.reload();
        }
    }
    /**
     * 
     * @returns {Number}
     */
    windowWidth() { return Graphics.boxWidth / Scene_QuestLog.LayoutSize(); }
    /**
     * @returns {Number}
     */
    windowHeight() { return Graphics.boxHeight - this.y; }
    /**
     * @returns {Number}
     */
    maxCols() { return 1; }
    /**
     * @returns {Number}
     */
    maxItems() { return this._quests ? this._quests.length : 0; }
    /**
     * @returns {Number}
     */
    spacing() { return 32; }
    /**
     * @returns {Number}
     */
    standardFontSize() { return 20; }
    /**
     * @returns {String}
     */
    questIndex(index = 0) {
        return this.quests()[index] || '';
    }
    /**
     * @param {Number} index 
     * @returns {Quest}
     */
    getQuest(index = 0) {
        const quest = this.questIndex(index);
        return quest && QuestLog.manager().quest(quest) || null;
    }
    /**
     * @description Render Item in the list by its list order
     */
    drawItem(index) {
        const quest = this.getQuest(index);
        if (quest) {
            const rect = this.itemRect(index);
            const title = quest.title().split(' - ');
            if (this._status < Quest.Status.Active) {
                this.changeTextColor(this.systemColor());
            }
            //this.drawTextEx( title_break[ 0 ] , rect.x , rect.y, rect.width);
            this.drawText(title[0], rect.x, rect.y, rect.width, 'left');
            this.resetTextColor();
        }
    }
    /**
     * @param {Window_QuestDetail} questWindow 
     */
    setHelpWindow(questWindow = null) {
        if (questWindow instanceof Window_QuestDetail) {
            //Window_Selectable.prototype.setHelpWindow.call(this, helpWindow);
            super.setHelpWindow(questWindow);
            this.setHelpWindowItem(this.getQuest(this.questIndex()));
        }
    }
    /**
     * @param {Quest} quest 
     */
    setHelpWindowItem(quest = null) {
        if (this._helpWindow) {
            this._helpWindow.setItem(quest);
            //this._helpWindow.refresh();
        }
    }
    /**
     * 
     */
    reload() {
        this.refreshList();
        super.refresh();
        //Window_Selectable.prototype.refresh.call(this);
        this.drawAllItems();
        this.resetScroll();
        this.select(this._quests.length > 0 ? 0 : -1);
        //this.setHelpWindowItem( this.getItemId());
    }
}



///////////////////////////////////////////////////////////////////////////////////////////////////
////    Window_QuestDetail : Window_Base
///////////////////////////////////////////////////////////////////////////////////////////////////
class Window_QuestDetail extends Window_Base {

    constructor() {
        this.initialize(arguments);
    }
    /**
     * @param {Quest} quest 
     * @param {Number} position 
     */
    initialize(quest = null, position = 0) {
        super.initialize(Window_QuestDetail.X(), position, this.windowWidth(), Graphics.boxHeight + position);
        this._quest = quest instanceof Quest && quest || null;
        this.refresh();
    }
    /**
     * @returns {QuestLog}
     */
    manager() { return QuestLog.manager(); }
    /**
     * @returns {Boolean}
     */
    debugMode() {
        return this.manager().debug();
    }
    /**
     * @returns {Number}
     */
    iconQuest() { return this.manager().icon(); }
    /**
     * @returns {Number}
     */
    iconActive() { return this.manager().icon('active'); }
    /**
     * @returns {Number}
     */
    iconCompleted() { return this.manager().icon('completed'); }
    /**
     * @returns {Number}
     */
    iconFailed() { return this.manager().icon('failed'); }
    /**
     * @returns {Number}
     */
    static X() { return Graphics.boxWidth / Scene_QuestLog.LayoutSize(); }
    /**
     * @returns {Number}
     */
    windowWidth() { return Window_QuestDetail.X() * (Scene_QuestLog.LayoutSize() - 1); }
    /**
     * @returns {Number}
     */
    windowHeight() { return Graphics.boxHeight - this.y; }
    /**
     * @param {Quest} quest
     */
    setItem(quest = null) {
        //this._quest = this.manager().quest(quest);
        this._quest = quest instanceof Quest && quest || null;
        this.refresh();
    }
    /**
     * 
     */
    refresh() {
        this.contents.clear();
        if (this._quest) {
            this.renderQuestData(this._quest);
        }
        else {
            this.renderEmptyQuest();
        }
    }
    /**
     * 
     * @param {Number} position 
     */
    drawHorzLine(position) {
        this.contents.paintOpacity = 48;
        this.contents.fillRect(0,
            position + this.lineHeight() / 2 - 1,
            this.contentsWidth(), 2,
            this.normalColor());
        this.contents.paintOpacity = 255;
    }
    /**
     * @returns {Number}
     */
    standardFontSize() { return 20; }
    /**
     * @returns {Number}
     */
    lineHeight() { return 30; }
    /**
     * @returns {Number}
     */
    completedItemOpacity() { this.contents.paintOpacity = 192; }
    /**
     * @returns {Number}
     */
    baseLine() { return Math.max((28 - this.standardFontSize()) / 2, 0); }
    /**
     * 
     */
    debugItemOpacity() { this.contents.paintOpacity = 128; }
    /**
     * @param {QuestData} quest
     */
    renderQuestData(quest) {

        // quest heading
        const category = quest.category() && quest.category().title() || '';
        const line = Math.max(32, this.lineHeight());
        const width = this.contentsWidth();
        //TITLE
        this.renderTitle(quest.title(), quest.icon());
        //CATEGORY
        if (category) {
            this.renderCategory(category);
        }
        this.changeTextColor(this.textColor(24));
        this.drawHorzLine(line);
        this.renderDetail(quest.details(), line);
        //RENDER STAGES
        this.renderQuestStages(quest);
        this.renderProgress(quest.progress());

        //if active, show curretn location, if completed, show reward
        if (quest.completed() && quest.hasReward()) {
            this.renderQuestReward(quest.reward(true), !quest.completed());
        }
        else if (quest.active()) {
            this.renderLocation(quest.location(true));
        }
        //render right
        this.renderQuestStatus(quest.status());
    }
    /**
     * @param {Number} progress 
     */
    renderProgress(progress = 0) {
        this.drawGauge(0,
            this.contentsHeight() - 10 - this.lineHeight() * 2,
            this.contentsWidth(),
            progress,
            this.textColor(4),
            this.textColor(6)
        );
    }
    /**
     * @param {String} category 
     */
    renderCategory(category = '') {
        this.changeTextColor(this.textColor(23));
        this.drawText(category, 40, this.baseLine(), this.contentsWidth() - 40, 'right');
    }
    /**
     * 
     * @param {String} title 
     * @param {Number} icon 
     */
    renderTitle(title = '', icon = 0) {
        this.changeTextColor(this.normalColor());
        if (icon) {
            this.drawIcon(icon, 0, this.baseLine());
        }
        this.drawTextEx(title, icon && 40 || 0, this.baseLine(), this.contentsWidth());
    }
    /**
     * @param {String|String[]} text
     * @param {Number} position
     */
    renderDetail(text = '', position = 0) {
        const content = this.displayDetail(text, this.manager().detailsLength());
        for (var i = 0; i < content.length; i++) {
            this.drawTextEx(content[i], 0, position + (this.lineHeight() * (i + 1)), this.contentsWidth());
        }
    }
    /**
     * @param {Number} wordLimit Words per line, 50 by default
     * @returns {String[]}
     */
    displayDetail(text, wordLimit = 40) {
        const output = [];
        text.split("\\n").forEach(function (line) {
            line.split(' ').forEach(function (word) {
                if (output.length && output[output.length - 1].length + word.length + 1 < wordLimit) {
                    output[output.length - 1] += ' ' + word;
                }
                else {
                    output.push(word);
                }
            });
            //libe break
            //output.push('');
        });
        return output;
    }
    /**
     * @param {Quest} quest
     */
    renderQuestStages(quest) {

        const line_height = this.lineHeight();
        const debugHiddenItem = false;
        const debug = this.debugMode();
        const linear = quest.isLinear();
        const stages = !debug || quest.type() === Quest.Type.Linear ? quest.stagesCompleted() : quest.stages();

        let position = this.contentsHeight() - (line_height * 2) - (line_height + 8) * stages.length;

        this.changeTextColor(this.normalColor());
        stages.forEach(stage => {
            if (debugHiddenItem) {
                this.debugItemOpacity();
            }
            this.renderStage(stage.title(), stage.completed(), position, debugHiddenItem);
            position += line_height + 8;
            if (debug && !debugHiddenItem && linear && stage.active()) {
                debugHiddenItem = true;
            }
        });
    }
    /**
     * @param {String} title 
     * @param {Boolean} completed 
     * @param {Number} position 
     * @param {Boolean} showDebug 
     */
    renderStage(title = '', completed = false, position = 0, showDebug = false) {
        if (showDebug) {
            this.debugItemOpacity();
        }
        this.drawIcon(this.manager().icon(completed ? 'completed' : 'active'), 0, position + 4);
        this.drawText(title, 35, this.baseLine() + position);
        if (showDebug) {
            this.changePaintOpacity(true);
        }
    }
    /**
     * @param {String} reward
     * @param {Boolean} locked
     */
    renderQuestReward(reward = '', locked = false) {
        if (locked) {
            this.changeTextColor(this.textColor(8));
        }
        this.drawTextEx(reward, 0, this.contentsHeight() - this.lineHeight() - 4, this.contentsWidth());
    }
    /**
     * @param {String} Location
     */
    renderLocation(location) {
        if (location) {
            this.changeTextColor(this.textColor(6));
            this.drawTextEx('Location: ' + location, 0, this.contentsHeight() - this.lineHeight() - 4, this.contentsWidth());
            this.changeTextColor(this.normalColor());
        }
    }
    /**
     * @param {Number} status
     */
    renderQuestStatus(status) {
        // STATUS
        switch (status) {
            case Quest.Status.Invalid:
                return;
            case Quest.Status.Active:
                this.changeTextColor(this.textColor(6));
                break;
            case Quest.Status.Completed:
                this.changeTextColor(this.textColor(24));
                break;
            case Quest.Status.Failed:
                this.changeTextColor(this.textColor(2));
                break;
        }
        this.drawText(QuestData.DisplauStatus(status), 0, this.contentsHeight() - this.lineHeight() - 4, this.contentsWidth(), 'right');
        this.changeTextColor(this.normalColor());
    }
    /**
     * @description Empty quest window
     */
    renderEmptyQuest() {
        const position = this.contentsHeight() / 3 - this.standardFontSize() / 2 - this.standardPadding();
        this.drawText("-- Empty log --", 10, position, this.contentsWidth(), 'center');
        //this.changeTextColor(this.textColor(8));
        //this.drawText("Left and Right to filter Quest Status", 0, position + 40, this.contentsWidth(), 'center');
        //this.drawText("Up and Down to select Quest", 0, position + 80, this.contentsWidth(), 'center');
        //this.drawText("Action to switch Quest Category filter", 0, position + 120, this.contentsWidth(), 'center');
        //this.changeTextColor(this.normalColor(8));
    }
}



(function () {

    const questman = QuestLog.manager();

    //new manager for new|load|save
    KunQuestMan_SetupDataManager();

    if (questman.itemEvent() > 0) {
        QuestManager_registerQuestItemEvent();
    }

    //QuestManager_registerMenu();
    QuestManager_registerCommands();
    //QuestManager_registerEscapeCharacters();

})( /* autorun */);

