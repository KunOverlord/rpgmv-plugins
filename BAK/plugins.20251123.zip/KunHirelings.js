//=============================================================================
// KunHirelings.js
//=============================================================================
/*:
 * @filename KunHirelings.js
 * @plugindesc Add Randomly generated Hirelings by class and generic NPCs to the party. Handle the party max size in game!
 * @version 1.41
 * @author Kun
 * 
 * @help
 * 
 * KunHireling create hornet:mothgirl:hornet:hornet:mothgirl:hornet 5
 * KunHireling manager debug
 * 
 * 
 * COMMANDS
 * 
 *  KunHireling show|manager
 *  - Display the hireling manager window
 *  
 *  KunHireling count game_var [all|classId] [party|home]
 *  - Export the hireling count into the game_var
 *  - Define a classId|className to filter the hirelings to count. Leave to all or 0 to get them all.
 *  - Define where count the hirelings, from party or home hub (Hireling Manager home by default)
 *  
 *  KunHireling create|prepare actor_id hireling_name [level]
 *  - Prepares a new hireling in actor_id's actor slot
 *  - Defines the hireling type with hireling_name
 *  - Defines the hireling level optionally
 *  - Defines a hireling's specific variation
 * 
 *  KunHireling join actor_id hireling_name [level]
 *  - Joins a new hireling overriding actor_id's actor slot
 *  - Defines the hireling type with hireling_name
 *  - Defines the hireling level optionally
 *  - Defines a hireling's specific variation
 * 
 * 
 * FUNCTIONS / CONDITIONS
 * 
 * @param hirelings
 * @text Hirelings
 * @desc Hirelings are generic companions which can be duplicated from a single hireling template overriding the mapped selected characters.
 * @type struct<Hireling>[]
 * 
 * @param slots
 * @text Hireling Slots
 * @desc Available Hireling Slots (warning, reserve these actors to be oftenly overriden by this plugin)
 * @type actor[]
 * 
 * @param limit
 * @text Hireling Manager Limit
 * @type number
 * @min 0
 * @max 100
 * @default 0
 * 
 * @param maxBattleMembers
 * @text Max Battle Members
 * @desc Override the default max battle members available. LEave to 0 to deault or avoid conflict with other plugins
 * @type number
 * @min 0
 * @max 20
 * @default 0
 * 
 * @param partyHas
 * @text Game_Party has
 * @desc Enables Game_Party.has(actor_id) method. Careful with other Kun mods whith includes this one.
 * @default true
 * 
 * @param debug
 * @text Debug Mode
 * @type boolean
 * @default false
 * 
 */
/*~struct~Hireling:
 * @param name
 * @text Name
 * @type text
 * @default Hireling
 * 
 * @param class
 * @text Class
 * @type class
 * @default 0
 * 
 * @param variations
 * @text Variations
 * @detail Define a list of face-character display variations
 * @type struct<Graphics>[]
 * 
 * @param names
 * @text Names
 * @type text[]
 * 
 * @param lastNames
 * @text Last Names
 * @type text[]
 * 
 * @param armorSet
 * @text Armor Set
 * @type armor[]
 * 
 * @param weaponSet
 * @text Weapons
 * @type weapon[]
 * 
 * @param itemSet
 * @text Items
 * @type item[]
 */
/*~struct~Graphics:
 * @param characterSet
 * @text character Set
 * @type file
 * @require 1
 * @dir img/characters/
 * 
 * @param characterId
 * @text Character Set Id
 * @type number
 * @min 0
 * @max 7
 * @default 1
 * 
 * @param faceSet
 * @text FaceSet
 * @type file
 * @require 1
 * @dir img/faces/
 * 
 * @param faceId
 * @text Face
 * @type number
 * @min 0
 * @max 7
 * @default 1
 * 
 * @param svBattler
 * @text SideView Battler
 * @type file
 * @required 1
 * @dir img/sv_actors/
 * 
 */

/**
 * @type {HirelingManager}
 */
var $gameHirelings = null;

function KunHirelings() {
    throw `${this.constructor.name} is a Static Class`;
}
/**
 * 
 */
KunHirelings.Initialize = function () {

    const _parameters = KunHirelings.PluginData();
    //var _parameters = this.parameters();

    this._debug = _parameters.debug;
    this._slots = _parameters.slots || [];
    this._limit = _parameters.limit || 0;
    this._templates = [];
    this._maxBattleMembers = _parameters.maxBattleMembers || 0;
    //this._emptyClass = _parameters.emptyClassId || 0;
    this._partyHas = _parameters.partyHas || false;

    this._text = {
        'home': 'Home',
        'party': 'Party',
        'disband': 'Disband',
        'remove': 'Remove',
    };

    this.importTemplates(_parameters.hirelings || []);
};
/**
 * @param {String} string 
 * @returns String
 */
KunHirelings.text = function (string) {
    return this._text.hasOwnProperty(string) ? this._text[string] : string;
};
/**
 * @returns {Number}
 */
KunHirelings.limit = function(){
    return this._limit;
};
/**
 * @returns {Boolean}
 */
KunHirelings.partyHas = function () {
    return this._partyHas;
};
/**
 * @returns Boolean
 */
KunHirelings.debug = function () {
    return this._debug;
};
/**
 * @returns Number
 */
KunHirelings.maxBattleMembers = function () {
    return this._maxBattleMembers
};
/**
 * @param {Number} actor_id 
 * @returns KunHirelings
 */
KunHirelings.addSlot = function (actor_id) {
    if (!this._slots.includes(actor_id)) {
        this._slots.push(actor_id);
    }
    return this;
};
/**
 * @param {Boolean} available
 * @returns {Number[]}
 */
KunHirelings.slots = function ( available = false ) {
    return available ? this._slots.filter( id => !$gameParty.has(id)) : this._slots;
};
/**
 * @param {Number} actor_id 
 * @returns Boolean
 */
KunHirelings.isHireling = function (actor_id) {
    return actor_id > 0 && this.slots().includes(actor_id);
};
/**
 * @param {Boolean} list 
 * @returns {Object | KunActorTemplate[]}
 */
KunHirelings.templates = function (list = false) {
    return list ? Object.values(this._templates) : this._templates;
};
/**
 * @returns {String}
 */
KunHirelings.random = function(){
    const list = this.templates(true).map(t => t.name());
    return list[Math.floor(Math.random() * list.length)];
};
/**
 * @param {String} name 
 * @returns Boolean
 */
KunHirelings.has = function (name) {
    return typeof name === 'string' && name.length && this.templates().hasOwnProperty(name);
};
/**
 * @param {KunActorTemplate} template
 * @returns {KunHirelings}
 */
KunHirelings.add = function (template) {
    if (template instanceof KunActorTemplate) {
        if (!this.has(template.name())) {
            this._templates[template.name()] = template;
        }
    }
    return this;
};
/**
 * @param {Number} actor_id 
 * @param {String} hireling
 * @param {Number} level (optional)
 * @returns {KunHireling}
 */
KunHirelings.create = function ( hireling, level = 0) {
    return this.has(hireling) ? this.templates()[hireling].create( level ) : null;
};
/**
 * @param {String\Number} className 
 * @returns {Number}
 */
KunHirelings.getClassId = function (className) {
    if( isNaN(className)){
        var match = $dataClasses !== null ? $dataClasses.filter( cls => cls.name === className ) : [];
        return match.length ? match[0].id : 0;
    }
    return parseInt(className);
};
/**
 * @returns Object
 */
KunHirelings.PluginData = function () {
    function _parsePluginData(key, value) {
        if (typeof value === 'string' && value.length) {
            try {
                if (/^\{.*\}$|^\[.*\]$/.test(value)) {
                    return JSON.parse(value, _parsePluginData);
                }
            } catch (e) {
                // If parsing fails or it's not an object/array, return the original value
            }
            if (value === 'true' || value === 'false') {
                return value === 'true';
            }
            if (!isNaN(value)) {
                return parseInt(value);
            }
        }
        else if (typeof value === 'object' && !Array.isArray(value)) {
            var _output = {};
            Object.keys(value).forEach(function (key) {
                _output[key] = _parsePluginData(key, value[key]);
            });
            return _output;
        }
        return value;
    };

    return _parsePluginData('KunHirelings', PluginManager.parameters('KunHirelings'));
};
/**
 * 
 * @param {Object[]} content 
 * @returns {KunHirelings}
 */
KunHirelings.importTemplates = function (content) {
    content.forEach(function (template) {
        const tpl = new KunActorTemplate( template.name.toLowerCase(), template.class || 0, template.level || 0);
        if(Array.isArray(template.names)){
            template.names.forEach(name => tpl.addName(name));
        }
        if(Array.isArray(template.lastNames)){
            template.lastNames.forEach(lastName => tpl.addLastName(lastName));
        }
        if(Array.isArray(template.armorSet)){
            template.armorSet.forEach(armor_id => tpl.addArmor(armor_id));
        }
        if(Array.isArray(template.weaponSet)){
            template.weaponSet.forEach(weapon_id => tpl.addWeapon(weapon_id));
        }
        if(Array.isArray(template.variations)){
            template.variations.forEach(function (g) {
                tpl.addGraphics(
                    g.characterSet,
                    g.characterId,
                    g.faceSet,
                    g.faceId,
                    g.svBattler
                );
            });    
        }
        KunHirelings.add(tpl);
    });
    return this;
};
/**
 * @param {String} message 
 */
KunHirelings.DebugLog = function (message) {
    if (this.debug()) {
        console.log(typeof message === 'object' ? message : '[ KunHirelings ] ' + message);
    }
};

/**
 * 
 */
function HirelingManager() {
    this.clear();
}
/**
 * @type {Object}
 */
HirelingManager.Hub = {
    'Home':'home',
    'Party':'party',
};
/**
 * @type {Object}
 */
HirelingManager.Actions = {
    'Move':'move',
    'Remove':'remove',
    'Create':'create',
    'Invalid': 'invalid',
};
/**
 * @param {Boolean} debug
 */
HirelingManager.manager = function ( debug = false ) {
    SceneManager.push(Scene_Hirelings);
};
/**
 * @returns {HirelingManager}
 */
HirelingManager.prototype.clear = function () {
    this._pool = [];
    return this;
};
/**
 * @param {Number} classId
 * @returns {KunHireling[]}
 */
HirelingManager.prototype.hirelings = function ( classId = 0) {
    return classId > 0 ? this._pool.filter(h => h.class() === classId) : this._pool;
};
/**
 * @returns {KunHireling[]}
 */
HirelingManager.prototype.party = function () {
    return $gameParty.allMembers().filter(actor => actor.isHireling()).map(actor => actor.hireling());
};
/**
 * @param {Boolean} getNames
 * @returns {Number}
 */
HirelingManager.prototype.classes = function (getNames = false) {
    var list = [];
    this.hirelings().map( h => h.class() ).filter(id => id > 0).forEach( function(id){
        if( !out.includes(id)){
            out.push(id);
        }
    });
    return getNames ? list.map(id => $dataClasses[id].name) : list;
};
/**
 * @param {Number} classId filter
 * @returns {Number}
 */
HirelingManager.prototype.size = function ( classId = 0 ) {
    return this.hirelings( classId ).length;
};
/**
 * @returns {Boolean}
 */
HirelingManager.prototype.empty = function(){
    return this.size() === 0;
};
/**
 * @returns {Boolean}
 */
HirelingManager.prototype.full = function(){
    return KunHirelings.limit() > 0 && KunHirelings.limit() >= this.size();
};
/**
 * @param {Number} id 
 * @returns {Boolean}
 */
HirelingManager.prototype.has = function (id) {
    return id >= 0 && id < this.size();
};
/**
 * @param {KunHireling} hireling 
 * @returns {HirelingManager}
 */
HirelingManager.prototype.add = function (hireling) {
    if (hireling instanceof KunHireling && !this.full() ) {
        this._pool.push(hireling);
    }
    return this;
};
/**
 * @param {Number} index
 * @returns {HirelingManager}
 */
HirelingManager.prototype.drop = function (index = -1) {
    this.out(index);
    return this;
};
/**
 * @param {Number} index 
 * @returns {KunHireling}
 */
HirelingManager.prototype.out = function (index = -1) {
    return this.has(index) ? this.hirelings().splice(index, 1)[0] : null;
};
/**
 * @returns {Number[]}
 */
HirelingManager.prototype.available = function () {
    return KunHirelings.slots(true);
};
/**
 * @returns {Number}
 */
HirelingManager.prototype.slot = function () {
    return this.available().length ? this.available()[0] : 0;
};
/**
 * Join a hireling to the party
 * @param {Number} index 
 * @returns {Boolean}
 */
HirelingManager.prototype.join = function( index = 0){
    if( this.has( index ) ){
        if( this.hirelings()[index].join() ){
            KunHirelings.DebugLog(`${this.hirelings()[index].name()} has joined the party!`);
            this.out(index);
            return true;
        }
        else{
            KunHirelings.DebugLog(`Cannot join ${this.hirelings()[index].name()}`);
        }
    }
    return false;
}
/**
 * Send a hireling to the hub
 * @param {Number} index 
 * @returns {Boolean}
 */
HirelingManager.prototype.hub = function( index = 0){
    if($gameParty.has(index)){
        var actor = $gameParty.hirelings().filter( actor => actor.actorId() === index && actor.isHireling());
        if( actor.length ){
            this.add(actor[0].hireling());
            actor[0].resetHireling();
            return true;
        }
    }  
    return false;
};
/**
 * @param {String} name 
 * @param {Number|Number[]} level or random level selection
 * @param {Boolean} join 
 * @returns {Boolean}
 */
HirelingManager.prototype.create = function( name , level = 0 , join = false ){
    
    if( Array.isArray(level )){
        //cast random level selection
        level = level.length ? level[Math.floor(Math.random() * level.length)] : 1;
    }

    const hireling = KunHirelings.create(name , level );
    
    if( hireling !== null ){
        const slot = this.slot();
        if( join &&  slot > 0 ){
            const actor = $gameActors.actor(slot);
            if (hireling.export(actor ) ) {
                $gameParty.addActor(slot);
                KunHirelings.DebugLog(`Joined ${hireling}`);
                return true;
            }
        }
        else{
            this.add(hireling);
            KunHirelings.DebugLog(`Saved ${hireling}`);
            return true;
        }    
    }
    return false;
};


/**
 * @param {String} name 
 * @param {Number} actorClass 
 * @param {Number} level
 * @returns 
 */
function KunActorTemplate(name, actorClass = 0) {
    this._name = name;
    this._firstNames = [];
    this._lastNames = [];
    this._class = actorClass;
    this._graphics = [];
    this._armors = [];
    this._weapons = [];
};
/**
 * @returns {String}
 */
KunActorTemplate.prototype.toString = function () {
    return this.name();
};
/**
 * @returns {Number}
 */
KunActorTemplate.prototype.class = function () {
    return this._class;
};
/**
 * @param {Number} level 
 * @returns {KunHireling} 
 */
KunActorTemplate.prototype.create = function (level = 0) {
    const hireling = new KunHireling(this.name(true), this.class(), level ? level : 1);
    const look = this.graphics();
    if( look !== null ){
        hireling.setup(look.character, look.character_id, look.face, look.face_id, look.battler);
    }
    hireling.equip(this.armor(), this.weapon());
    //hireling.inventory(this.item());
    return hireling;
};
/**
 * @param {String} character 
 * @param {Number} character_id 
 * @param {String} face 
 * @param {Number} face_id 
 * @param {String} battler 
 * @returns {KunActorTemplate}
 */
KunActorTemplate.prototype.addGraphics = function (character, character_id, face, face_id, battler) {
    this._graphics.push({
        'character': character,
        'character_id': character_id,
        'face': face,
        'face_id': face_id,
        'battler': battler,
    });
    return this;
};
/**
* @param {String} name 
* @returns KunHireling
*/
KunActorTemplate.prototype.addName = function (name) {
    if (!this._firstNames.includes(name)) {
        this._firstNames.push(name);
    }
    return this;
};
/**
/**
* @param {String} name 
* @returns KunHireling
*/
KunActorTemplate.prototype.addLastName = function (lastname) {
    if (!this._lastNames.includes(lastname)) {
        this._lastNames.push(lastname);
    }
    return this;
};
/**
 * @param {Number} weapon_id 
 * @returns {String}
 */
KunActorTemplate.prototype.addWeapon = function(weapon_id){
    if(!this._weapons.includes(weapon_id)){
        this._weapons.push(weapon_id);
    }
    return this;
};
/**
 * @param {Number} armor_id 
 * @returns {String}
 */
KunActorTemplate.prototype.addArmor = function(armor_id){
    if(!this._armors.includes(armor_id)){
        this._armors.push(armor_id);
    }
    return this;
};
/**
 * @returns {Object}
 */
KunActorTemplate.prototype.graphics = function () {
    return this._graphics.length ? this._graphics[Math.floor(Math.random() * this._graphics.length)] : null;
};
/**
 * @param {Boolean} generate
 * @returns {String}
 */
KunActorTemplate.prototype.name = function (generate = false) {
    if (generate) {
        var firstname = this._firstNames.length ? this._firstNames[Math.floor(Math.random() * this._firstNames.length)] : this._name;
        var lastname = this._lastNames.length ? this._lastNames[Math.floor(Math.random() * this._lastNames.length)] : '';
        return lastname.length ? firstname + ' ' + lastname : firstname;
    }
    return this._name;
};
/**
 * @returns {Number}
 */
KunActorTemplate.prototype.armor = function () {
    return this._armors.length ? this._armors[Math.floor(Math.random() * this._armors.length)] : 0;
};
/**
 * @returns {Number}
 */
KunActorTemplate.prototype.weapon = function () {
    return this._weapons.length ? this._weapons[Math.floor(Math.random() * this._weapons.length)] : 0;
};
/**
 * @param {Number} count 
 * @returns {Number[]}
 */
KunActorTemplate.prototype.item = function (count = 1) {
    const items = [];
    if (this._items.length) {
        for (var i = 0; i < count; i++) {
            items.push(this._items[Math.floor(Math.random() * this._items.length)]);
        }
    }
    return items;
};





/**
 * @param {String} name 
 * @param {Number} actorClass 
 * @param {Number} level
 * @returns 
 */
function KunHireling(name, actorClass, level = 1) {
    this._name = name || 'Hero';
    this._class = actorClass || 0;
    this._level = level || 1;
    this._armors = [];
    this._weapon = 0;
    this._actorId = 0;

    this._battler = '';
    this._faceSet = '';
    this._charSet = '';
    this._faceId = 0;
    this._charId = 0;
};
/**
 * @returns {String}
 */
KunHireling.prototype.toString = function(){
    return this.className().toLowerCase();
};
/**
 * @param {Number} actor_id 
 * @returns {KunHireling} 
 */
KunHireling.prototype.setId = function( actor_id = 0){
    this._actorId = actor_id;
    return this;
};
/**
 * @returns {Number}
 */
KunHireling.prototype.id = function(){
    return this._actorId;
};
/**
 * @param {String} charSet 
 * @param {Number} char_id 
 * @param {String} faceSet 
 * @param {Number} face_id 
 * @param {String} battler 
 * @returns {KunHireling}
 */
KunHireling.prototype.setup = function (charSet = '', char_id = 0, faceSet = '', face_id = 0, battler = '') {
    this._battler = battler;
    this._faceSet = faceSet;
    this._faceId = face_id;
    this._charSet = charSet;
    this._charId = char_id;
    return this;
};
/**
 * @param {Number} armor 
 * @param {Number} weapon 
 * @returns {KunHireling}
 */
KunHireling.prototype.equip = function (armor = 0, weapon = 0) {
    if( armor ){
        this._armors.push(armor);
    }
    if( weapon ){
        this._weapon = weapon;
    }
    return this;
};
/**
 * @param {Boolean} fullName
 * @returns {String}
 */
KunHireling.prototype.name = function ( fullName = false) {
    return fullName ? `${this._name} the ${this.className()}` : this._name;
};
/**
 * @returns {Number}
 */
KunHireling.prototype.class = function () {
    return this._class;
};
/**
 * @returns {String}
 */
KunHireling.prototype.className = function(){
    return this.class() ? $dataClasses[this.class()].name : '';
};
/**
 * @returns {Number}
 */
KunHireling.prototype.level = function () {
    return this._level;
};
/**
 * @returns {Number[]}
 */
KunHireling.prototype.armors = function () {
    return this._armors;
};
/**
 * @returns {Number}
 */
KunHireling.prototype.weapon = function () {
    return this._weapon;
};
/**
 * @returns {Boolean}
 */
KunHireling.prototype.join = function () {
    var slot = $gameHirelings.slot();
    if (slot) {
        if (this.export($gameActors.actor(slot))) {
            $gameParty.addActor(slot);
            return true;
        }
    }
    return false;
};
/**
 * @param {Game_Actor} actor 
 * @returns {Boolean}
 */
KunHireling.prototype.export = function (actor, reset = false) {
    if (actor instanceof Game_Actor && actor.isHireling() ) {
        actor.changeClass(this.class(), false);
        actor._level = this.level();
        actor._name = this.name();
        if (this._charSet.length) {
            actor.setCharacterImage(this._charSet, this._charId);
        }
        if (this._faceSet.length) {
            actor.setFaceImage(this._faceSet, this._faceId);
        }
        if (this._battler.length) {
            actor.setBattlerImage(this._battler);
        }
        if( reset ){
            actor.setup();
        }
        return true;
    }
    return false;
};

/**
 * Add an armor definition to the template
 * @param {Number} armor 
 * @returns 
 */
KunHireling.prototype.addArmor = function (armor) {
    this._armors.push(armor);
    return this;
};
/**
 * Add a weapon definition to the template
 * @param {Number} weapon 
 * @returns 
 */
KunHireling.prototype.addWeapon = function (weapon) {
    this._weapons.push(weapon);
    return this;
};
/**
 * Import an alive hireling from an actor profile
 * @param {Game_Actor} actor
 * @param {Boolean} reset reset this actor's level, learning and traits
 * @returns {KunHireling}
 */
KunHireling.import = function (actor, reset = false) {
    if (actor instanceof Game_Actor && actor.isHireling()) {
        const hireling = new KunHireling(actor._name,actor._classId, reset ? 1 : actor._level);
        hireling.setId(actor.actorId());
        hireling.setup(
            actor.characterName(),
            actor.characterIndex(),
            actor.faceName(),
            actor.faceIndex(),
            actor.battlerName());
        return hireling;
    }
    return null;
};



/**
 * 
 */
function KunHirelings_SetupDataManager() {
    //CREATE NEW
    const _KunHirelings_DataManager_Create = DataManager.createGameObjects;
    DataManager.createGameObjects = function () {
        _KunHirelings_DataManager_Create.call(this);
        //add hireling manager
        $gameHirelings = new HirelingManager();
    };
    //SAVE
    const _KunHirelings_DataManager_Save = DataManager.makeSaveContents;
    DataManager.makeSaveContents = function () {
        const contents = _KunHirelings_DataManager_Save.call(this);
        //save hireling data
        contents.hirelings = $gameHirelings;
        return contents;
    };
    //LOAD
    const _KunHirelings_DataManager_Load = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function (contents) {
        _KunHirelings_DataManager_Load.call(this, contents);
        //load hireling data
        $gameHirelings = typeof contents.hirelings === 'object' ? content.hirelings : new HirelingManager();
    };
}
/**
 * 
 */
function KunHirelings_SetupGameParty() {
    /**
     * @returns Boolean
     */
    Game_Actor.prototype.isHireling = function () {
        return KunHirelings.isHireling(this.actorId());
    };
    /**
     * @param {Boolean} reset
     * @returns {KunHireling}
     */
    Game_Actor.prototype.hireling = function ( reset = false ) {
        return KunHireling.import(this,reset);
    };
    /**
     * @returns {Boolean}
     */
    Game_Actor.prototype.resetHireling = function(){
        if( this.isHireling() ){
            this.setup(this.actorId());
            if( $gameParty.has(this.actorId())){
                $gameParty.removeActor(this.actorId());
            }
            return true;
        }
        return false;
    };
    /**
     * @param {KunHireling} hireling 
     * @returns {Boolean}
     */
    Game_Actor.prototype.replaceHireling = function (hireling) {
        return hireling.export( this );
    };
    /**
     * @returns {String}
     */
    Game_Actor.prototype.className = function(){
        return $dataClasses[this._classId].name.toLowerCase();
    };

    /**
     * List of hirelings
     * @param {Number} classId
     * @returns {Game_Actor[]}
     */
    Game_Party.prototype.hirelings = function ( classId = 0) {
        var hirelings = this.allMembers().filter(actor => actor.isHireling());
        return classId > 0 ? hirelings.filter(actor._classId === classId ) : hirelings;
        //return this.allMembers().filter(actor => actor.isHireling() && ( classId === 0 || actor._classId === classId) );
    };

    if (typeof Game_Party.prototype.has !== 'function' && KunHirelings.partyHas()) {
        /**
         * Actor Id is in party?
         * @returns {Boolean}
         */
        Game_Party.prototype.has = function (actor_id) {
            return this.allMembers().map(actor => actor.actorId()).includes(actor_id);
        };
    }
    /**
     * @param {Number} classId 
     * @returns {Boolean}
     */
    Game_Party.prototype.hasHirelings = function (classId = 0) {
        return this.hirelings(classId).length > 0;
    };
    /**
     * @param {Boolean} all
     * @param {Number} classId 
     * @param {Boolean} save
     * @returns {Boolean}
     */
    Game_Party.prototype.removeHireling = function (all = false, classId = 0, save = false) {
        //const actors = this.hirelings(classId).map(actor => actor.actorId());
        const actors = this.hirelings(classId);
        if (actors.length) {
            if( all ){
                for (var i = 0; i < actors.length; i++) {
                    this.removeActor(actors[i].actorId());
                    if( save ){
                        $gameHirelings.add( actors[i].hireling(true) );
                    }
                }
            }
            else{
                this.removeActor(actors[0]);
                if( save ){
                    $gameHirelings.add( actors[0].hireling(true) );
                }
            }
            return true;
        }
        return false;
    };


    if (KunHirelings.maxBattleMembers() > 0) {
        Game_Party.prototype.maxBattleMembers = function () {
            return KunHirelings.maxBattleMembers();
        };
    }
    /**
     * @param {Boolean} stepAnime 
     */
    Game_Follower.prototype.setStepAnime = function (stepAnime) {
        this._stepAnime = this.isHireling() || stepAnime;
    };
    /**
     * @returns Boolean
     */
    Game_Follower.prototype.isHireling = function () {
        return this.isVisible()
            && $gameParty.has(this._memberIndex)
            && $gameParty.members()[this._memberIndex].isHireling();
    };
};
/**
 * 
 */
function KunHirelings_SetupCommands() {
    var _KunHirelings_Commands = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function (command, args) {
        _KunHirelings_Commands.call(this, command, args);
        if (command === 'KunHireling') {
            if (args && args.length) {
                switch (args[0]) {
                    case 'show':
                    case 'manager':
                        HirelingManager.manager( args.length > 1 && args[1] === 'debug' );
                        break;
                    case 'create':
                    case 'prepare':
                        if (args.length > 1) {
                            args[1].split(':').forEach( function(name){
                                $gameHirelings.create(
                                    name.toLowerCase(),
                                    args.length > 2 ? args[2].split(':').map( level => parseInt(level)) : 1 );
                            } );
                        }
                        break;
                    case 'add':
                    case 'join':
                        if (args.length > 1 ) {
                            $gameHirelings.create(
                                args[1].toLowerCase(),
                                args.length > 2 ? args[2].split(':').map( level => parseInt(level)) : 1,
                                true);
                        }
                        break;
                    case 'disband':
                        if (args.length > 1) {
                            var classId = args[1] !== 'all' ? KunHirelings.getClassId(args[1]) : 0;
                            if ($gameParty.removeHireling(args.includes('all'), classId)) {
                                KunHirelings.DebugLog(`Disbanded ${args[1]}`);
                            }
                        }
                        break;
                    case 'count':
                        if (args.length > 1) {
                            var classId = args.length > 2  && args[2] !== 'all' ? KunHirelings.getClassId(args[2]) : 0;
                            var party = args.includes('party');
                            var count = party ? $gameParty.hirelings(classId).length : $gameHirelings.size(classId);
                            $gameVariables.setValue(parseInt(args[1]), count);
                        }
                        break;
                }
            }
        }
    };
};

/////////////////////////////////////////////////////////////////////////////
//HIRELING MANAGER SCENE SETUP
function Scene_Hirelings() {
    this.initialize.apply(this, arguments);
}
Scene_Hirelings.prototype = Object.create(Scene_Base.prototype);
Scene_Hirelings.prototype.constructor = Scene_Hirelings;
//SETUP HIRELING MANAGER
Scene_Hirelings.prototype.initialize = function () {
    Scene_Base.prototype.initialize.call(this);
};
/**
 * 
 */
Scene_Hirelings.prototype.create = function () {
    Scene_Base.prototype.create.call(this);
    this.createWindowLayer();

    this.setupHome();
    this.setupList();
    this.setupActions();
    this.reload();  
};
/**
 * @returns {String}
 */
Scene_Hirelings.prototype.home = function(){
    return this._headerWindow.selected();
};
/**
 * @returns {Number}
 */
Scene_Hirelings.prototype.index = function(){
    return this._hirelingWindow.index();
};
/**
 * @returns {KunHireling}
 */
Scene_Hirelings.prototype.item = function(){
    var index = this.index();
    return this._hirelingWindow.maxItems() > index ? this._hirelingWindow.items()[index] : null;
};
/**
 * @returns {Number[]}
 */
Scene_Hirelings.prototype.classes = function () {
    return $gameHirelings.classes();
};

/**
 * 
 */
Scene_Hirelings.prototype.setupHome = function () {
    this._headerWindow = new Window_HirelingHeader();
    this._headerWindow.setHandler('ok', this.selectHome.bind(this));
    this._headerWindow.setHandler('cancel', this.cancelHome.bind(this));
    this._headerWindow.setHandler('change',this.reload.bind(this))
    this.addWindow(this._headerWindow);
};
Scene_Hirelings.prototype.selectHome = function(){
    if( this.count()){
        this._headerWindow.deactivate();
        this._actionWindow.activate();
    }
    else{
        //play buzzer
        this._headerWindow.activate();
    }
};
Scene_Hirelings.prototype.cancelHome = function(){
    this.popScene();
};
Scene_Hirelings.prototype.reload = function(){
    //var contents = this.home() === HirelingManager.Hub.Party ? $gameHirelings.party() : $gameHirelings.hirelings();
    //this._hirelingWindow.change(contents);
    this._hirelingWindow.change(this.home());
}
/**
 * @returns {Number}
 */
Scene_Hirelings.prototype.count = function(){
    return this._hirelingWindow.items().length;
};
/**
 * 
 */
Scene_Hirelings.prototype.setupList = function () {
    this._hirelingWindow = new Window_Hirelings();
    this.addWindow(this._hirelingWindow);
};
/**
 * 
 */
Scene_Hirelings.prototype.setupActions = function () {
    this._actionWindow = new Window_HirelingActions();
    this._actionWindow.setHandler('ok', this.actionOk.bind(this));
    this._actionWindow.setHandler('cancel', this.actionBack.bind(this));
    this.addWindow(this._actionWindow);
};
/**
 * 
 */
Scene_Hirelings.prototype.actionOk = function(){
    var action = this._actionWindow.action();
    switch(action){
        case HirelingManager.Actions.Create:
            $gameHirelings.create(KunHirelings.random(),Math.floor(Math.random() * 5 ));
            break;
        case HirelingManager.Actions.Move:
            this.transfer( );
            break;
        case HirelingManager.Actions.Remove:
            this.remove( );
            break;
    }
    this._hirelingWindow.refresh();
    if( this.count() === 0 ){
        this.actionBack();
    }
};
/**
 * @param {KunHireling} hireling 
 * @param {Boolean} remove do not save in hireling home, will be lost.
 * @returns {Boolean}
 */
Scene_Hirelings.prototype.disband = function( hireling , remove = false ){
    if( hireling !== null && $gameParty.has(hireling.id()) ){
        $gameParty.allMembers()
            .filter( actor => actor.isHireling() && actor.actorId() === hireling.id())
            .forEach( actor => actor.setup(actor.actorId()));
        $gameParty.removeActor(hireling.id());
        if( !remove ){
            $gameHirelings.add(hireling);
        }
        return true;
    }
    return false;
};
/**
 * 
 * @param {Number} index 
 * @returns {Boolean}
 */
Scene_Hirelings.prototype.rejoin = function( index ){
    if( $gameHirelings.has( index ) ){
        var hireling = $gameHirelings.hirelings()[index];
        if( hireling.join() ){
            KunHirelings.DebugLog(`${hireling.name()} has joined the party!`);
            $gameHirelings.out(index);
            return true;
        }
        else{
            KunHirelings.DebugLog(`Cannot join ${this.hirelings()[index].name()}`);
        }
    }    
    return false;
};
/**
 * @param {Number} index 
 */
Scene_Hirelings.prototype.transfer = function( ){
    switch( this.home()){
        case HirelingManager.Hub.Party:
            //Send to hub
            return this.disband(this.item());
        case HirelingManager.Hub.Home:
            //send to party
            return this.rejoin( this.index());
    }
    return false;
};
/**
 * @returns {Boolean}
 */
Scene_Hirelings.prototype.remove = function(){

    switch( this.home()){
        case HirelingManager.Hub.Party:
            return this.disband(this.item(),true);
        case HirelingManager.Hub.Home:
            return $gameHirelings.out(this.index()) !== null;
    }
    return false;
};
/**
 * @param {KunHireling} hireling
 * @returns {Boolean}
 */
Scene_Hirelings.prototype.partyRemove = function( hireling ){
    if( hireling !== null && $gameParty.has( hireling.id() )){
        //remove from party
        $gameParty.removeActor(hireling.id());
        return true;
    }
    return false;
};
Scene_Hirelings.prototype.actionBack = function(){
    this._actionWindow.deactivate();
    this._headerWindow.activate();
};
/**
 * 
 */
Scene_Hirelings.prototype.update = function() {
    Scene_Base.prototype.update.call(this);
}

/***********************************************************************************
 * @Window_Base extensions
 * HOME SELECTION
 **********************************************************************************/
/**
 * @returns {Object}
 */
Window_Base.prototype.dataSource = function( ){
    if( !this.dsReady()){
        this._dataSource = {
            'get':{},
            'set':{},
            'has':{},
        };
    }
    return this._dataSource;
};
/**
 * @param {String} method
 * @returns {Boolean}
 */
Window_Base.prototype.dsReady = function( method = ''){
    if( method.length ){
        var call = method.split('.');
        return call.length > 1 ?
            this.dataSource().hasOwnProperty(call[0]) && this.dataSource()[call[0]].hasOwnProperty(call[1]) :
            this.dataSource().hasOwnProperty(call[0]);
    }
    return this.hasOwnProperty('_dataSource');
};
/**
 * @param {String} attribute 
 * @param {Function} callback
 * @returns {Window_Base}
 */
Window_Base.prototype.bindGet = function( attribute , callback){
    if( typeof attribute === 'string' && attribute.length && typeof callback === 'function' ){
        if( !this.dsReady('get.' + attribute)){
            this.dataSource()['get'][attribute] = callback;
        }
    }
    return this;
};
/**
 * @param {String} attribute 
 * @param {Function} callback
 * @returns {Window_Base}
 */
Window_Base.prototype.bindSet = function( attribute , callback){
    if( typeof attribute === 'string' && attribute.length && typeof callback === 'function' ){
        if( !this.dsReady('set.' + attribute)){
            this.dataSource()['set'][attribute] = callback;
        }
    }
    return this;
};
/**
 * @param {String} attribute 
 * @param {Function} callback
 * @returns {Window_Base}
 */
Window_Base.prototype.bindHas = function( attribute , callback){
    if( typeof attribute === 'string' && attribute.length && typeof callback === 'function' ){
        if( !this.dsReady('has.' + attribute)){
            this.dataSource()['has'][attribute] = callback;
        }
    }
    return this;
};
/**
 * @param {String} attribute 
 * @param {Function} callback
 * @returns {Window_Base}
 */
Window_Base.prototype.bindList = function( attribute , callback){
    if( typeof attribute === 'string' && attribute.length && typeof callback === 'function' ){
        if( !this.dsReady('list.' + attribute)){
            this.dataSource()['list'][attribute] = callback;
        }
    }
    return this;
};
/**
 * @param {String} attribute 
 * @param {*} value
 * @returns {*}
 */
Window_Base.prototype.getData = function( attribute , value = ''){
    if( this.dsReady() && this.dataSource()['get'].hasOwnProperty(attribute)){
        return this.dataSource()['get'][attribute]();
    }
    return value;
};
/**
 * @param {String} attribute 
 * @param {*} value
 * @returns {Window_Base}
 */
Window_Base.prototype.setData = function( attribute , value = ''){
    if( this.dsReady() && this.dataSource()['set'].hasOwnProperty(attribute)){
        return this.dataSource()['set'][attribute](value);
    }
    return this;
};
/**
 * @param {String} attribute 
 * @param {*} value
 * @returns {Boolean}
 */
Window_Base.prototype.hasData = function( attribute ){
    if( this.dsReady() && this.dataSource()['has'].hasOwnProperty(attribute)){
        return this.dataSource()['has'][attribute]();
    }
    return false;
};
/**
 * @param {String} attribute 
 * @returns {Array}
 */
Window_Base.prototype.listData = function( attribute ){
    if( this.dsReady() && this.dataSource()['list'].hasOwnProperty(attribute)){
        return this.dataSource()['list'][attribute]();
    }
    return [];
};

/***********************************************************************************
 * @Window_HirelingHeader
 * HOME SELECTION
 **********************************************************************************/
function Window_HirelingHeader() {
    this.initialize.apply(this, arguments);
};
Window_HirelingHeader.prototype = Object.create(Window_HorzCommand.prototype);
Window_HirelingHeader.prototype.constructor = Window_HirelingHeader;
Window_HirelingHeader.prototype.initialize = function () {
    Window_HorzCommand.prototype.initialize.call(this, 0, 0);
};
Window_HirelingHeader.prototype.windowWidth = function() {
    return Graphics.boxWidth;
};
Window_HirelingHeader.prototype.windowHeight = function() {
    return 80;
};
Window_HirelingHeader.prototype.makeCommandList = function () {
    this.addCommand(KunHirelings.text('home'), HirelingManager.Hub.Home);
    this.addCommand(KunHirelings.text('party'), HirelingManager.Hub.Party);
};
/**
 * @returns {String}
 */
Window_HirelingHeader.prototype.selected = function () {
    return this.index() >= 0 ? this.commandSymbol(this.index()) : HirelingManager.Hub.Home;
};
Window_HirelingHeader.prototype.numVisibleRows = function () {
    return 1;
};
Window_HirelingHeader.prototype.maxCols = function () {
    return 2;
};
Window_HirelingHeader.prototype.itemTextAlign = function () {
    return 'center';
};
Window_HirelingHeader.prototype.select =function( index = 0){
    Window_HorzCommand.prototype.select.call(this,index);
    this.callHandler('change');
};
/***********************************************************************************
 * @Window_Hirelings
 * HIRELING SELECTION LIST
 **********************************************************************************/
function Window_Hirelings() {
    //this._items = [];
    this._source = HirelingManager.Hub.Home;
    this.loadImages();
    this.initialize.apply(this, arguments);
}
Window_Hirelings.prototype = Object.create(Window_Selectable.prototype);
Window_Hirelings.prototype.constructor = Window_Hirelings;
/**
 * @param {KunHireling[]} hirelings 
 */
Window_Hirelings.prototype.initialize = function () {
    Window_Selectable.prototype.initialize.call(this, 0, 80, this.windowWidth(), this.windowHeight());
    this.refresh();
};
/**
 * @returns {Number}
 */
Window_Hirelings.prototype.windowHeight =function(){
    return Graphics.boxHeight - 160;
};
/**
 * @returns {Number}
 */
Window_Hirelings.prototype.windowWidth =function(){
    return Graphics.boxWidth;
};
/**
 * @param {String} source
 */
Window_Hirelings.prototype.change = function( source = '' ){
    if( this._source !== source){
        this._source = source;
        //this._items = items;
        this.refresh();
    }
};
Window_Hirelings.prototype.refresh = function( ){
    this.toggle();
    Window_Selectable.prototype.refresh.call( this );
};
Window_Hirelings.prototype.toggle = function(){
    if( this.items().length === 0 ){
        this.deactivate();
    }
    else if(!this.active){
        this.activate();
    }
};


/**
 * @returns {KunHireling[]}
 */
Window_Hirelings.prototype.items = function(){
    return this._source === HirelingManager.Hub.Party ? $gameHirelings.party() : $gameHirelings.hirelings();
    return this._items;
}
/**
 * @returns {Number}
 */
Window_Hirelings.prototype.maxItems = function(){
    return this.items().length;
};
/**
 * @returns {KunHireling}
 */
Window_Hirelings.prototype.item = function () {
    var index = this.index();
    return this.maxItems() && index >= 0 ? this.items()[index] : null;
};
/**
 * @returns {KunHireling}
 */
Window_Hirelings.prototype.first = function () {
    return this.maxItems() ? this.items()[0] : null;
};
/**
 * @param {Number} index 
 */
Window_Hirelings.prototype.drawItem = function(index){
    if( this.maxItems() && index >= 0){
        this.drawItemBackground(index);
        this.drawItemImage(index);
        this.drawItemStatus(index);
    }
};
/**
 * @returns {Window_Hirelings}
 */
Window_Hirelings.prototype.loadImages = function() {
    this.items().map( hireling => hireling._charSet).forEach(function(picture) {
        //ImageManager.reserveFace(picture);
        ImageManager.reserveCharacter(picture);
    }, this);
    return this;
};

Window_Hirelings.prototype.drawItemBackground = function(index) {
    if (index === this._pendingIndex) {
        var rect = this.itemRect(index);
        var color = this.pendingColor();
        this.changePaintOpacity(false);
        this.contents.fillRect(rect.x, rect.y, rect.width, rect.height, color);
        this.changePaintOpacity(true);
    }
};
/**
 * @param {Number} index 
 */
Window_Hirelings.prototype.drawItemImage = function(index) {
    var hireling = this.items()[index];
    var rect = this.itemRect(index);
    this.drawHireling(hireling, rect.x, rect.y);
    //this.changePaintOpacity(true);
};
/**
 * @param {KunHireling} hireling 
 * @param {Number} x 
 * @param {Number} y 
 */
Window_Hirelings.prototype.drawHireling = function( hireling ,x , y) {
    //this.drawFace(hireling._faceSet, hireling._faceId, x, y, Window_Base._faceWidth / 2, Window_Base._faceHeight / 2);
    this.drawCharacter(hireling._charSet,hireling._charId,x + 24 , y + (this.itemHeight() * 3/4));
};

Window_Hirelings.prototype.drawItemStatus = function(index) {
    var hireling = this.items()[index];
    var rect = this.itemRect(index);
    var x = rect.x + 80;
    var y = rect.y + rect.height / 2 - this.lineHeight() * 1.5;
    var width = rect.width - x - this.textPadding();
    //this.drawActorSimpleStatus(actor, x, y, width);
    //var rect = this.itemRect(index);
    this.drawText(hireling.name(true), x, y, width, 'left');
    this.drawText('Level: ' + hireling.level(), x, y, width, 'right');
};
/**
 * @returns {Number}
 */
Window_Hirelings.prototype.itemHeight = function() {
    var clientHeight = this.windowHeight() - this.padding * 2;
    return Math.floor(clientHeight / this.numVisibleRows());
};
Window_Hirelings.prototype.numVisibleRows = function() {
    return 4;
};
Window_Hirelings.prototype.maxCols = function () {
    return 1;
};
Window_Hirelings.prototype.itemTextAlign = function () {
    return 'center';
};
Window_Hirelings.prototype.processOk = function() {
    return;
    if (this.isCurrentItemEnabled()) {
        this.playOkSound();
        this.updateInputData();
        this.deactivate();
        this.callOkHandler();
    } else {
        this.playBuzzerSound();
    }
};
Window_Hirelings.prototype.processCancel = function() {
    return;
    SoundManager.playCancel();
    this.updateInputData();
    this.deactivate();
    this.callCancelHandler();
};
Window_Hirelings.prototype.processCursorMove = function() {
    if (this.isCursorMovable()) {
        var lastIndex = this.index();
        if (Input.isRepeated('down') && lastIndex < this.items().length - 1) {
            this.cursorDown(Input.isTriggered('down'));
        }
        if (Input.isRepeated('up') && lastIndex > 0) {
            this.cursorUp(Input.isTriggered('up'));
        }
        if (Input.isRepeated('right')) {
            this.cursorRight(Input.isTriggered('right'));
        }
        if (Input.isRepeated('left')) {
            this.cursorLeft(Input.isTriggered('left'));
        }
        if (!this.isHandled('pagedown') && Input.isTriggered('pagedown')) {
            this.cursorPagedown();
        }
        if (!this.isHandled('pageup') && Input.isTriggered('pageup')) {
            this.cursorPageup();
        }
        if (this.index() !== lastIndex) {
            SoundManager.playCursor();
        }
    }
};
/***********************************************************************************
 * @Window_HirelingActions
 * HIRELING ACTIONS [join | disband | remove | ...]
 **********************************************************************************/
function Window_HirelingActions() {
    this.initialize.apply(this, arguments);
};
Window_HirelingActions.prototype = Object.create(Window_HorzCommand.prototype);
Window_HirelingActions.prototype.constructor = Window_HirelingActions;
Window_HirelingActions.prototype.initialize = function () {
    this.setContext();
    Window_HorzCommand.prototype.initialize.call(this, 0, Graphics.boxHeight - 80);
    this.deactivate();
};
Window_HirelingActions.prototype.windowWidth = function() {
    return Graphics.boxWidth;
};
Window_HirelingActions.prototype.windowHeight = function() {
    return 80;
};
Window_HirelingActions.prototype.makeCommandList = function () {
    this.addCommand(KunHirelings.text('move'), HirelingManager.Actions.Move);
    //this.addCommand(KunHirelings.text('create'), HirelingManager.Actions.Create);
    this.addCommand(KunHirelings.text('drop'), HirelingManager.Actions.Remove);
};
/**
 * @returns {String}
 */
Window_HirelingActions.prototype.action = function(){
    return this.index() >= 0 ? this.commandSymbol(this.index()) : HirelingManager.Actions.Invalid;
};
/**
 * @param {String} context
 * @returns {Window_HirelingActions}
 */
Window_HirelingActions.prototype.setContext = function( context = HirelingManager.Hub.Home ){
    this._context = context;
    return this;
};
/**
 * @returns {String}
 */
Window_HirelingActions.prototype.context = function(){
    return this._context;
};
/**
 * @returns {Number}
 */
Window_HirelingActions.prototype.maxCols = function() {
    return 3;
};

Window_HirelingActions.prototype.processOk = function(){
    if (this.isCurrentItemEnabled()) {
        this.playOkSound();
        this.updateInputData();
        //this.deactivate();
        this.callOkHandler();
    } else {
        this.playBuzzerSound();
    }

}
/**
 * 
 */
Window_HirelingActions.prototype.activate = function(){
    Window_HorzCommand.prototype.activate.call(this);
    this.refresh();
};
/**
 * 
 */
Window_HirelingActions.prototype.deactivate = function(){
    Window_HorzCommand.prototype.deactivate.call(this);
    this.refresh();
};
/**
 * Show or hide commands when toggled
 */
Window_HirelingActions.prototype.refresh = function() {
    if (this.contents) {
        this.contents.clear();
        this.toggle();
    }
};
Window_HirelingActions.prototype.toggle = function(){
    if( this.active){
        this.drawAllItems();
        this.reselect();
        this.select(0);
    }
    else{
        this.deselect();
    }
};

(function ( /* args */) {
    KunHirelings.Initialize();
    KunHirelings_SetupDataManager();
    KunHirelings_SetupGameParty();
    KunHirelings_SetupCommands();
})( /* initializer */);

